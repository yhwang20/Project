# ReciPlease

## Deployed site:

https://reciplease-ooseteam-02.vercel.app/

## To run locally:

1. In the client folder, run `npm install`

2. Run `npm run dev` to run the client side

   2.1 Open [http://localhost:3000](http://localhost:3000) with your browser to see the result.

## To run tests:

1. In the server folder, run "npm test"
2. If you wish to run each test file individually, run "npm test \_\_\_\_" Inside the line should be the file name. (It is better to run each test file individually)

## About

ReciPlease is a website that allows users to search for specific recipes based on their inputted preferences. We are a group of college students who took inspiration from our own struggles figuring out what to eat for dinner each night, and wanted to fix this problem in a meaningful way.

### Tech stack:

We are using a modified version of the MERN stack, fondly referred to as the PERN stack; we replaced MongoDB with a PostgreSQL database, with Prisma as our ORM, as we felt a relational database would better suit our recipe-storing needs. This is similar to the T3 stack, but we are not using TRPC.

This project also uses NextJS, Tailwind and Material UI (front-end), and Typescript.

### Functionality:

Features include:

-Searching for existing recipes. We also have an advanced search button if you wish to search with specific filters

-Favoriting recipes ("/user/me/favorites")

-Searching for recipes using the chatbot -- a user can tell the chatbot what they generally want, and the chatbot will generate names of foods that match what the user requested, and then those names are compared with the titles of recipes in our database.

-Adding recipes ("/add_recipe")

-Viewing recipes (accessed via the landing page or after searching!)

-Viewing any recipes that you've added ("user/me/recipes")

-Reviewing recipes via a recipe's page -- a user can give a number rating from 1-5, and also provide a written review if they want to go in detail.

-User pages ("/user/createaccount", "/user/login", "/user/confirmemail",
"/user/setdiet", "/user/setexperience", "/user/profile", "/user/me/favorites")
