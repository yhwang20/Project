import jsonWebToken from "jsonwebtoken";
import dotenv from "dotenv";

dotenv.config();

export const createToken = (user: any, expiresIn?: string) => {
  const secretKey = process.env.JWT_SECRET;
  if (!secretKey) {
    throw new Error("No secret key found");
  }
  return jsonWebToken.sign(user, secretKey, {
    algorithm: "HS256",
    expiresIn: expiresIn || "2d",
  });
};
export const decodeToken = (token: string) => {
  const secretKey = process.env.JWT_SECRET;
  if (!secretKey) {
    throw new Error("No secret key found");
  }
  return jsonWebToken.verify(token, secretKey, {
    algorithms: ["HS256"],
    ignoreNotBefore: true,
  });
};
