const express = require("express");
const cors = require("cors");
const helmet = require("helmet");
require("dotenv").config();
const recipes = require("./routes/recipes");
const tags = require("./routes/tags");
const users = require("./routes/users");
const auth = require("./routes/auth");
const app = express();
const userPref = require("./routes/userPref");
const port = process.env.PORT || 4000;

app.use(cors());
app.use(helmet());
app.use(express.json());

app.get("/", async (req: any, res: any) => {
  res.send("Welcome to the Reciplease API!");
});

app.use(recipes);
app.use(tags);
app.use(users);
app.use(auth);
app.use(userPref);

module.exports = app;
