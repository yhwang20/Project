import ApiError from "../model/ApiError";
import { v4 as uuidv4 } from "uuid";

import {
  PrismaClient,
  Prisma,
  Review,
  Role,
  User,
  userPreferences,
  Tag,
  Recipe,
} from "@prisma/client";


const prisma = new PrismaClient();


interface tagInput {
  name: string;
}

class RecipeDAO {
  // Add new recipe to database, ensuring that required fields are given
  create = async (data: Prisma.RecipeCreateInput): Promise<Recipe> => {
    try {
      if (data.name === undefined || data.name === "") {
        throw new ApiError(400, "Every recipe must have a non-empty name!");
      }
      if (
        data.ingredients === undefined ||
        (data.ingredients as string[]).length === 0
      ) {
        throw new ApiError(400, "Every recipe must have some ingredients!");
      }
      if (data.difficulty === undefined || data.difficulty === 0) {
        throw new ApiError(
          400,
          "Every recipe must tell us how difficult it is!"
        );
      }
      if (
        data.procedure === undefined ||
        (data.procedure as string[]).length == 0
      ) {
        throw new ApiError(400, "Every recipe must have a procedure!");
      }
      if (data.tools === undefined || (data.tools as string[]).length === 0) {
        throw new ApiError(400, "Every recipe must have the necessary tools!");
      }
      if (data.prepTimeInMins === undefined || data.prepTimeInMins === 0) {
        throw new ApiError(400, "Every recipe must have a prep time!");
      }
      if (data.cookTimeInMins === undefined || data.cookTimeInMins == null) {
        data.cookTimeInMins = 0;
      }
      if (data.reviews === undefined || data.reviews === null) {
        data.reviews = {};
      }
      if(data.tags) {
        if (Array.isArray(data.tags)) {
          const tagNames = data.tags.map((tag)=> tag.name.toLowerCase().replace(/\s+/g, ''));
          data.tags = {
            connectOrCreate: tagNames.map((tagName) => ({
              where: { name: tagName},
              create: { name: tagName },
            })),
          };
          data.tagString = (tagNames.map((name)=> name.trim().replace(/\s+/g, ''))).join(",");
        }
      }




      const ingredients = data.ingredients as string[];
      const ingredientNames = ingredients.map((ingredient: string) => {
        return ingredient.split(":")[0].toLowerCase();
      });

      data.ingredientString = (ingredientNames.map((name)=> name.trim().replace(/\s+/g, ''))).join(",");



      let recipe = await prisma.recipe.create({

        data: data,
        include: {tags: true}
      });
      if(recipe.tags && recipe.tagString === "") {
        const tags = recipe.tags.map((tag)=> tag.name.replace(/\s+/g, '')).join(",");
        await prisma.recipe.update({where: {id: recipe.id}, data: {tagString: tags}})
      }
      return recipe;
    } catch (err: any) {
      throw new ApiError(404, err.message);
    } finally {
      await prisma.$disconnect();
    }
  };
  // Update recipe with given new parameters
  update = async (id: string, data: Prisma.RecipeUpdateInput) => {
    if (data.difficulty && typeof data.difficulty === "string") {
      data.difficulty = parseInt(data.difficulty);
    }
    if (
      data.difficulty &&
      ((data.difficulty as number) > 5 || (data.difficulty as number) < 0)
    ) {
      throw new ApiError(404, "Invalid difficulty!");
    }
    if (
      (data.cookTimeInMins && (data.cookTimeInMins as number) < 0) ||
      (data.prepTimeInMins && (data.prepTimeInMins as number) <= 0)
    ) {
      throw new ApiError(404, "Negative time parameters are invalid!");
    }
    if (data.tags) {
      const sanitizedTags = (data.tags as tagInput[]).filter(
        (tag) => tag.name.toLowerCase() !== "unknown"
      );
      const returnedTags = await this.updateTags(sanitizedTags);
      data.tags = {
        set: returnedTags.map((tag) => ({ id: tag.id })),
      };
      data.tagString = (returnedTags.map((tag)=> tag.name.trim().replace(/\s+/g, ''))).join(",");
    }
    try {
      if (data.ingredients) {
        const ingredients = data.ingredients as string [];
        const ingredientNames = ingredients.map((ingredient: string) =>
          ingredient.split(":")[0].toLowerCase()
        );
        data.ingredientString = (ingredientNames.map((name)=> name.trim().replace(/\s+/g, ''))).join(",");
      }
      const recipe = await prisma.recipe.update({
        where: {
          id,
        },
        data,
        include: { author: true, favoritedBy: true, reviews: true, tags: true },
      });
      return recipe;
    } catch (err: any) {
      throw new ApiError(404, err.message);
    } finally {
      await prisma.$disconnect();
    }
  };

  // Update recipe's author to be different User
  updateAuthor = async (id: string, authorID: string) => {
    try {
      const recipe = await prisma.recipe.update({
        where: {
          id,
        },
        data: { author: { connect: { id: authorID } } },
        include: { author: { select: { username: true } } },
      });
      return recipe;
    } catch (err: any) {
      throw new ApiError(404, "Invalid author or recipe ID!");
    } finally {
      await prisma.$disconnect();
    }
  };

  // Update given recipe's array of tags by adding or removing given tag based on add's value
  updateTags = async (tags: tagInput[]) => {
    try {
      // Find or create the tags
      const tagNames = tags.map((tag) => tag.name.toLowerCase());
      if (new Set(tagNames).size !== tagNames.length) {
        throw new ApiError(400, "Can't add duplicate tag!");
      }
      const tagPromises = tagNames.map((tagName) =>
        prisma.tag.upsert({
          where: { name: tagName },
          update: {},
          create: { name: tagName },
        })
      );
      const createdTags = await Promise.all(tagPromises);
      // Update the tags of the recipe
      /* const updatedRecipe = await prisma.recipe.update({
        where: { id: recipeId },
        include: { tags: true },
      });

      if (recipe === null) {
        throw new ApiError(404, "Invalid recipe ID!");
      }

      if (!add && !recipe.tags.find((tag) => tag.id === tagId)) {
        throw new ApiError(404, "Invalid tag ID!");
      }

      if (add && recipe.tags.find((tag) => tag.id === tagId)) {
        throw new ApiError(404, "Cannot add duplicate tag to recipe!");
      }

      const updatedRecipe = await prisma.recipe.update({
        where: {
          id: recipeId,
        },
        data: {
          tags: add
            ? {
                connect: { id: tagId },
              }
            : { disconnect: { id: tagId } },
        },
        include: {
          tags: true,
        },
      });
      return updatedRecipe;

        data: { tags: { set: createdTags.map((tag) => ({ id: tag.id })) } },
      }); */
      return createdTags;
    } catch (err: any) {
      throw new ApiError(404, "Invalid tag or recipe ID!");
    } finally {
      await prisma.$disconnect();
    }
  };

  getFavorite = async (recipeId: string) => {
    try {
      const recipe = await prisma.recipe.findUnique({
        where: { id: recipeId },
        include: { favoritedBy: true },
      });

      if (!recipe) {
        throw new ApiError(404, "Invalid recipe ID!");
      }
      return recipe;
    } catch (err: any) {
      throw new ApiError(404, "Invalid recipe ID!");
    } finally {
      await prisma.$disconnect();
    }
  };

  updateFavorite = async (recipeId: string, userId: string, add: boolean) => {
    try {
      const recipe = await prisma.recipe.findUnique({
        where: { id: recipeId },
        include: { favoritedBy: true },
      });

      if (!recipe) {
        throw new ApiError(404, "Invalid recipe ID!");
      }

      if (!add && !recipe.favoritedBy.find((user) => user.id === userId)) {
        throw new ApiError(404, "Invalid user ID!");
      }

      const updatedRecipe = await prisma.recipe.update({
        where: {
          id: recipeId,
        },
        data: {
          favoritedBy: add
            ? {
                connect: { id: userId },
              }
            : { disconnect: { id: userId } },
        },
        include: {
          favoritedBy: { select: { username: true } },
        },
      });
      return updatedRecipe;
    } catch (err: any) {
      throw new ApiError(404, "Invalid user or recipe ID!");
    } finally {
      await prisma.$disconnect();
    }
  };

  // Delete given recipe
  async delete(id: string) {
    try {
      console.log("in recipeDAO delete");
      await prisma.review.deleteMany({
        where: {
          recipeId: id,
        },
      });
      const recipe = await prisma.recipe.delete({
        where: {
          id: id,
        },
      });
      return recipe;
    } catch (err: any) {
      throw new ApiError(404, "There is no recipe with the given ID!");
    } finally {
      await prisma.$disconnect();
    }
  }

  // Read given recipe, including related fields
  async read(id: string) {
    try {
      const recipe = await prisma.recipe.findUnique({
        where: {
          id: id,
        },
        include: {
          author: { select: { username: true, image: true } },
          favoritedBy: { select: { username: true } },
          reviews: {
            select: {
              id: true,
              userId: true,
              score: true,
              comment: true,
              user: true,
            },
          },
          tags: true,
        },
      });
      if (!recipe) {
        throw new ApiError(404, "There is no recipe with the given ID!");
      }
      return recipe;
    } catch (err: any) {
      throw new ApiError(err.status, err.message);
    } finally {
      await prisma.$disconnect();
    }
  }

  // Read all recipes
  async readAll() {
    try {
      const recipes = await prisma.recipe.findMany({
        include: {
          author: { select: { username: true } },
          favoritedBy: { select: { username: true } },
          tags: true,
          reviews: { select: { id: true, score: true, comment: true } },
        },
      });
      return recipes;
    } catch (err: any) {
      throw new ApiError(404, `${err.message}`);
    } finally {
      await prisma.$disconnect();
    }
  }

  async search(
    UserId?: string,
    includedTags?: string[],
    includedIngredients?: string[],
    excludedIngredients?: string[],
    excludedTags?: string[],
    prepTime?: number,
    cookingTime?: number,
    rating?: number,
    maxDifficulty?: number,
    currQuery?: string
  ) {
    try {
    let user, userPreferencesId, userPreferences;
    let query = {};
    if (UserId) {
      user = await prisma.user.findUnique({
        where: {
          id: UserId,
        },
      })
    }
        if (user) {
          userPreferencesId = user.userPreferencesId;

          if (userPreferencesId) {
            userPreferences = await prisma.userPreferences.findUnique({
              where: {
                id: userPreferencesId,
              },
              include: {
                cuisineTags: true
              },
            });
          }
        }



      if (includedIngredients) {
        const trimmed = includedIngredients.map((ingred)=> ingred.trim().replace(/\s+/g, ''));
        const searchString = trimmed.join(' & ')
        query = Object.assign(
          {},
            {ingredientString: {search: searchString}},
          query,
        );
      }
      if (excludedIngredients) {
        const trimmed = excludedIngredients.map((ingred)=> ("!" +ingred).trim().replace(/\s+/g, ''));
        const searchString = trimmed.join(' & ')
        query = Object.assign(
          {},
            {ingredientString: {search: searchString}},
          query
        );
      }

      if (userPreferences && userPreferences.ingredientsExcluded) {
        const trimmed = userPreferences.ingredientsExcluded.map((ingred)=> ("!" +ingred).trim().replace(/\s+/g, ''));
        const searchString = trimmed.join(' & ');
        query = Object.assign(
          {},
            {ingredientString: {search: searchString}},
          query
        );
      }
      const upIncludedTags = [];
      if (userPreferences?.vegan) {
        upIncludedTags.push("vegan");
      }

      if (userPreferences?.vegetarian) {
        upIncludedTags.push("vegetarian");
      }

      if (userPreferences?.halal) {
        upIncludedTags.push("halal");
      }

      if (userPreferences?.kosher) {
        upIncludedTags.push("kosher");
      }

      if (userPreferences?.keto) {
        upIncludedTags.push("keto");
      }

      if (userPreferences?.nonDairy) {
        upIncludedTags.push("Dairy-Free");
      }

      if (userPreferences?.glutenFree) {
        upIncludedTags.push("Gluten-Free");
      }

      if(userPreferences?.cuisineTags && userPreferences.cuisineTags.length > 0) {
        const cuisineNames = userPreferences.cuisineTags.map((tag)=> tag.name.replace(/\s+/g, ''));
        upIncludedTags.concat(cuisineNames);
      }
      if (upIncludedTags && upIncludedTags.length > 0) {
        const searchString = upIncludedTags.map((tag)=> tag.trim().replace(/\s+/g, '')).join(' & ');
        query = Object.assign(
          {},
            {tagString: {search: searchString}},
            query
        );
      }

      if (includedTags && includedTags.length > 0) {
        const searchString = includedTags.map((tag)=> tag.trim().replace(/\s+/g, '')).join(' & ');
        query = Object.assign(
          {},
            {tagString: {search: searchString}},
          query
        );
      }

      // Exclude all excluded tags
      if (excludedTags && excludedTags?.length > 0) {
        query = {
          tags: {
            none: {
              name: { in: excludedTags },
            },
          },
          ...query,
        };
      }
      if (!cookingTime && !prepTime && userPreferences?.timeInMins) {
        query = {
          ...query,
          prepTimeInMins: {
            lte: userPreferences.timeInMins,
          },
        };
      }

      if (maxDifficulty) {
        query = {
          ...query,
          difficulty: {
            lte: maxDifficulty,
          },
        };
      } else if (userPreferences && userPreferences.difficulty){
        query = {
          ...query,
          difficulty: {
            lte: userPreferences?.difficulty,
          },
        };
      }

      console.log(query);
      const recipes = await prisma.recipe.findMany({
        where: {
          name: { contains: currQuery, mode: "insensitive" },
          prepTimeInMins: {
            lte: prepTime,
          },
          cookTimeInMins: {
            lte: cookingTime,
          },
          avgRating: {
            gte: rating,
          },
          AND: [query],
        },
        include: {
          author: { select: { username: true } },
          favoritedBy: { select: { username: true } },
          tags: true,
          reviews: true,
        },
      });

      return recipes;
    } catch (err: any) {
      throw new ApiError(404, `${err.message}`);
    } finally {
      await prisma.$disconnect();
    }
  }

  /*async searchGPT(UserId?: string, gptQuery?: string) {
    if (!gptQuery) {
      return;
    }
    let user, userPreferencesId, userId, userPreferences;
    if (UserId) {
      user = await prisma.user.findUnique({
        where: {
          id: UserId,
        },
      });
      if (user) {
        userPreferencesId = user.userPreferencesId;
        userId = user.id;
      }
      if (userPreferencesId) {
        userPreferences = await prisma.userPreferences.findUnique({
          where: {
            id: userPreferencesId,
          },
          include: {
            cuisineTags: true,
          },
        });
      }
    }

    try {
      let query = {};

      if (userPreferences && userPreferences.ingredientsExcluded) {
        const trimmed = userPreferences.ingredientsExcluded.map((ingred)=> ("!" +ingred).trim().replace(/\s+/g, ''));
        const searchString = trimmed.join(' & ');
        query = Object.assign(
            {},
            {ingredientString: {search: searchString}},
            query
        );
      }
      const upIncludedTags = [];
      if (userPreferences?.vegan) {
        upIncludedTags.push("vegan");
      }

      if (userPreferences?.vegetarian) {
        upIncludedTags.push("vegetarian");
      }

      if (userPreferences?.halal) {
        upIncludedTags.push("halal");
      }

      if (userPreferences?.kosher) {
        upIncludedTags.push("kosher");
      }

      if (userPreferences?.keto) {
        upIncludedTags.push("keto");
      }

      if (userPreferences?.nonDairy) {
        upIncludedTags.push("Dairy-Free");
        upIncludedTags.push("Dairy Free");
        upIncludedTags.push("No dairy");
      }

      if (userPreferences?.glutenFree) {
        upIncludedTags.push("Gluten-Free");
        upIncludedTags.push("Gluten Free");
        upIncludedTags.push("No gluten");
      }
      if(userPreferences?.cuisineTags && userPreferences.cuisineTags.length > 0) {
        const cuisineNames = userPreferences.cuisineTags.map((tag)=> tag.name.replace(/\s+/g, ''));
        upIncludedTags.concat(cuisineNames);
      }
      if (upIncludedTags && upIncludedTags.length > 0) {
        const searchString = upIncludedTags.map((tag)=> tag.trim().replace(/\s+/g, '')).join(' & ');
        query = Object.assign(
            {},
            {tagString: {search: searchString}},
            query
        );
      }



      if (userPreferences?.timeInMins) {
        query = {
          ...query,
          prepTimeInMins: {
            lte: userPreferences.timeInMins,
          },
        };
      }
      let searchTerms = gptQuery.split(" ").filter(Boolean);
      const excludeSearchTerms = ["and", "with", "the", "or"];
      searchTerms = searchTerms.filter(
        (word) => !excludeSearchTerms.includes(word)
      );
      const recipesOnTags = await prisma.recipe.findMany({
        where: {
          OR: [
            ...searchTerms.map(() => ({
              tags: { some: { name: { in: gptQuery } } },
            })),
          ],
          AND: [query, { difficulty: { lte: userPreferences?.difficulty } }],
        },
        include: {
          author: { select: { username: true } },
          favoritedBy: {
            where: {
              id: userId,
            },
          },
          tags: true,
          reviews: true,
        },
      });

      const recipesOnNames = await prisma.recipe.findMany({
        where: {
          OR: searchTerms.map((term) => ({
            name: { contains: term, mode: "insensitive" },
            // ingredients: { some: { in: searchTerms } },
          })),
          AND: [query, { difficulty: { lte: userPreferences?.difficulty } }],
        },
        include: {
          author: { select: { username: true } },
          favoritedBy: {
            where: {
              id: userId,
            },
          },
          tags: true,
        },
      });
      const recipesOnIngredients = await prisma.recipe.findMany({
        where: {
          OR: searchTerms.map((term) => ({
            name: { contains: term, mode: "insensitive" },
          })),
          AND: [query, { difficulty: { lte: userPreferences?.difficulty } }],
        },
        include: {
          author: { select: { username: true } },
          favoritedBy: {
            where: {
              id: userId,
            },
          },
          tags: true,
          reviews: true,
        },
      });

      const commonRecipes = recipesOnNames.filter((nameRecipe) =>
        recipesOnIngredients.some((ingRecipe) =>
          recipesOnTags.some(
            (tagRecipe) =>
              tagRecipe.id === ingRecipe.id && tagRecipe.id === nameRecipe.id
          )
        )
      );

      if (commonRecipes.length > 0) {
        return {
          success: true,
          message: "Recipes found!",
          data: commonRecipes,
        };
      }

      const partialMatches = recipesOnNames
        .concat(recipesOnIngredients)
        .concat(recipesOnTags)
        .filter(
          (recipe, index, self) =>
            self.findIndex((r) => r.id === recipe.id) === index &&
            !commonRecipes.includes(recipe)
        );

      if (partialMatches.length > 0) {
        return {
          success: true,
          message: "Partial matches found!",
          data: partialMatches,
        };
      }

      const allRecipes = recipesOnNames
        .concat(recipesOnIngredients)
        .concat(recipesOnTags);
      return { success: false, message: "No matches found.", data: allRecipes };
    } catch (err: any) {
      throw new ApiError(404, `${err.message}`);
    } finally {
      await prisma.$disconnect();
    }
  }*/
  
  async addReview(
    recipeId: string,
    userId: string,
    score: number,
    comment: string
  ) {
    try {
      const recipe = await prisma.recipe.findUnique({
        where: {
          id: recipeId,
        },
        include: { reviews: true },
      });

      const user = await prisma.user.findUnique({
        where: {
          id: userId,
        },
      });
      if (!recipe || !user) {
        throw new ApiError(404, "Invalid recipe or user!");
      }
      if (score > 5 || score < 0) {
        throw new ApiError(404, "Invalid score!");
      }
      if (comment.length > 3000) {
        throw new ApiError(404, "Comment is too long!");
      }

      const newReview = await prisma.review.create({
        data: {
          score: score,
          comment: comment,
          recipe: { connect: { id: recipeId } },
          user: { connect: { id: userId } },
        },
      });

      const reviews = recipe.reviews;
      const sum =
        reviews.reduce(
          (total: number, review: Review) => total + review.score,
          0
        ) + score;
      const newAvgRating = sum / (reviews.length + 1);

      const updatedRecipe = await prisma.recipe.update({
        where: {
          id: recipeId,
        },
        data: {
          reviews: {
            connect: {
              id: newReview.id,
            },
          },
          avgRating: newAvgRating,
        },
        include: {
          reviews: { select: { id: true, score: true, comment: true } },
        },
      });

      await prisma.user.update({
        where: {
          id: userId,
        },
        data: {
          reviews: {
            connect: {
              id: newReview.id,
            },
          },
        },
      });

      return updatedRecipe;
    } catch (err: any) {
      throw new ApiError(404, `${err.message}`);
    } finally {
      await prisma.$disconnect();
    }
  }
}

export default RecipeDAO;
