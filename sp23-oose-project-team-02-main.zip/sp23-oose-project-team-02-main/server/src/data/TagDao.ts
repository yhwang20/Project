import ApiError from "../model/ApiError";
import { PrismaClient, Prisma, Tag } from "@prisma/client";
const prisma = new PrismaClient();

class TagDAO {
  // Create new tag with given name
  create = async (data: Prisma.TagCreateInput): Promise<Tag> => {
    try {
      if (data.name === undefined || data.name.length === 0) {
        throw new ApiError(400, "Every recipe must have a non-empty name!");
      }
      const check = await prisma.tag.findUnique({
        where: {
          name: data.name,
        },
      });
      if (!check) {
        const tag = await prisma.tag.create({
          data: data,
        });
        return tag;
      } else {
        throw new ApiError(400, "This tag name already exists!");
      }
    } catch (err: any) {
      throw new ApiError(404, err.message);
    } finally {
      await prisma.$disconnect();
    }
  };

  // Update tag with given id to have new name
  update = async (id: number, data: Prisma.TagUpdateInput) => {
    try {
      if (data.name === undefined || data.name === "") {
        throw new ApiError(
          404,
          "Cannot update tag name to empty/undefined string!"
        );
      }
      const tag = await prisma.tag.update({
        where: {
          id,
        },
        data,
        include: { recipes: true },
      });
      return tag;
    } catch (err: any) {
      throw new ApiError(
        404,
        "Failed to update recipe! This is likely due to an invalid ID."
      );
    } finally {
      await prisma.$disconnect();
    }
  };

  // update tag's array of recipes to add or drop given recipe based on add's value
  updateRecipes = async (tagId: number, recipeId: string, add: boolean) => {
    try {
      const tag = await prisma.tag.findUnique({
        where: { id: tagId },
      });

      if (!tag) {
        throw new ApiError(404, "Invalid tag ID!");
      }
      const updatedTag = await prisma.tag.update({
        where: {
          id: tagId,
        },
        data: {
          recipes: add
            ? {
                connect: { id: recipeId },
              }
            : { disconnect: { id: recipeId } },
        },
        include: {
          recipes: true,
        },
      });
      return updatedTag;
    } catch (err: any) {
      throw new ApiError(404, "Invalid tag or recipe ID!");
    } finally {
      await prisma.$disconnect();
    }
  };

  // delete given tag
  // prisma default behavior handles tags in recipes' arrays
  async delete(id: number) {
    try {
      const tag = await prisma.tag.delete({
        where: {
          id: id,
        },
      });
      return tag;
    } catch (err: any) {
      throw new ApiError(404, "There is no tag with the given ID!");
    } finally {
      await prisma.$disconnect();
    }
  }

  // Find given tag and return
  async read(tagId: number) {
    try {
      const tag = await prisma.tag.findUnique({
        where: {
          id: tagId,
        },
        include: { recipes: true },
      });
      return tag;
    } catch (err: any) {
      throw new ApiError(404, err.message);
    } finally {
      await prisma.$disconnect();
    }
  }

  // Read all tags and include attached arrays of recipes
  async readAll() {
    try {
      const tags = await prisma.tag.findMany({
        include: { recipes: true },
      });
      return tags;
    } catch (err: any) {
      throw new ApiError(404, "Invalid request!");
    } finally {
      await prisma.$disconnect();
    }
  }

  // Read one tag whose name matches query
  async readOne(query: string | undefined) {
    if (query === undefined || query === "") {
      throw new ApiError(404, "Cannot pass empty query to readOne!");
    }
    try {
      const tag = await prisma.tag.findUnique({
        where: {
          name: query,
        },
        include: { recipes: true },
      });
      return tag;
    } catch (err: any) {
      throw new ApiError(404, `Invalid request! ${err.message}`);
    } finally {
      await prisma.$disconnect();
    }
  }
}

export default TagDAO;
