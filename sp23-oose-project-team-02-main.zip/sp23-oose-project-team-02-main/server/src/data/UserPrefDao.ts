import ApiError from "../model/ApiError";
import { PrismaClient, Prisma, userPreferences, Tag } from "@prisma/client";
const prisma = new PrismaClient();

class UserPrefDAO {
  create = async (
    userPrefData: Prisma.userPreferencesCreateInput
  ): Promise<userPreferences> => {
    try {
      if (!userPrefData.userId) {
        throw new ApiError(400, "User ID is required!");
      }
      const userPrefs = await prisma.userPreferences.create({
        data: userPrefData,
      });
      await prisma.user.update({
        where: {
          id: userPrefData.userId,
        },
        data: {
          userPreferences: { connect: { id: userPrefs.id } },
        },
      });

      return userPrefs;
    } catch (error: any) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002"
      ) {
        throw new ApiError(400, error.message);
      }
      throw new ApiError(400, error.message);
    } finally {
      await prisma.$disconnect();
    }
  };

  async read(id: string) {
    try {
      const userPreferenceObj = await prisma.userPreferences.findUnique({
        where: {
          id: id,
        },
      });
      return userPreferenceObj;
    } catch (err) {
      throw new ApiError(
        400,
        "Something when wrong when looking for this set of user preferences!"
      );
    } finally {
      await prisma.$disconnect();
    }
  }

  async update(id: string, data: any) {
    try {
      if (Array.isArray(data.cuisineTags)) {
        data.cuisineTags = {
          connectOrCreate: data.cuisineTags.map((tagName: Tag) => ({
            where: { name: tagName.name.toLowerCase() },
            create: { name: tagName.name.toLowerCase() },
          })),
        };
      }

      const user = await prisma.user.findUnique({
        where: {
          id: id,
        },
      });
      if (!user) {
        throw new ApiError(403, "Could not find user with the given id.");
      }
      if (user.userPreferencesId === null) {
        throw new ApiError(
          403,
          "Could not find user preferences with the given id."
        );
      }

      const updatedUserPreferences = await prisma.userPreferences.update({
        where: {
          id: user.userPreferencesId,
        },
        data: data,
      });

      return updatedUserPreferences;
    } catch (err: any) {
      throw new ApiError(403, err.message);
    } finally {
      await prisma.$disconnect();
    }
  }

  async delete(userId: string) {
    try {
      const user = await prisma.user.findUnique({
        where: {
          id: userId,
        },
      });
      if (!user) {
        throw new ApiError(404, "Could not find user with the given id.");
      }
      if (user.userPreferencesId === null) {
        throw new ApiError(
          404,
          "Could not find User Preferences for the given id."
        );
      }

      const userPreferencesObj = await prisma.userPreferences.delete({
        where: {
          id: user.userPreferencesId,
        },
      });

      return userPreferencesObj;
    } catch (err: any) {
      throw new ApiError(
        404,
        "Could not find User Preferences for the given id."
      );
    } finally {
      await prisma.$disconnect();
    }
  }
}

export default UserPrefDAO;
