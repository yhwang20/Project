import ApiError from "../model/ApiError";
import { PrismaClient, Prisma, userPreferences, User } from "@prisma/client";
import { z } from "zod";
import { hashPassword } from "../password";
const prisma = new PrismaClient();

const validEmail = z.string().email("Invalid email address");
const validPassword = z
  .string()
  .min(6, "Password must be at least 6 characters");

class UserDAO {
  create = async (userData: Prisma.UserCreateInput): Promise<User> => {
    try {
      let result = validEmail.safeParse(userData.email);
      if (!result.success) {
        throw new ApiError(400, "Invalid email address");
      }
      result = validPassword.safeParse(userData.password);
      if (!result.success) {
        throw new ApiError(400, "Password must be at least 6 characters!");
      }
      userData.password = hashPassword(userData.password);

      const userPrefs: userPreferences = await prisma.userPreferences.create({
        data: {
          ingredientsExcluded: [],
          difficulty: 0,
          timeInMins: 2147483647,
          cuisineTags: {
            create: [],
          },
          vegan: false,
          vegetarian: false,
          kosher: false,
          halal: false,
          keto: false,
          nonDairy: false,
          glutenFree: false,
        },
      });

      const user = await prisma.user.create({
        data: userData,
      });

      const updatedUser = await prisma.user.update({
        where: {
          id: user.id,
        },
        data: {
          userPreferences: { connect: { id: userPrefs.id } },
        },
      });

      const updatedUserPref: userPreferences =
        await prisma.userPreferences.update({
          where: {
            id: userPrefs.id,
          },
          data: {
            user: { connect: { id: updatedUser.id } },
            userId: updatedUser.id,
          },
        });

      return updatedUser;
    } catch (error: any) {
      if (
        error instanceof Prisma.PrismaClientKnownRequestError &&
        error.code === "P2002"
      ) {
        throw new ApiError(400, "User with this email already exists!");
      }
      throw new ApiError(400, error.message);
    } finally {
      await prisma.$disconnect();
    }
  };

  async readAll(email: string | undefined) {
    try {
      const users = await prisma.user.findMany({
        where: {
          email: { contains: email },
        },
      });
      return users;
    } catch (err: any) {
      throw new ApiError(400, "Error fetching users");
    } finally {
      await prisma.$disconnect();
    }
  }

  async read(id: string) {
    try {
      const users = await prisma.user.findUnique({
        where: {
          id: id,
        },
        include: {
          userRecipes: {
            include: {
              reviews: true,
              tags: true,
              author: {
                select: { username: true },
              },
            },
          },
          favoritedRecipes: {
            include: {
              reviews: true,
              tags: true,
              author: {
                select: { id: true, username: true },
              },
            },
          },
          userPreferences: true,
          reviews: true,
        },
      });
      return users;
    } catch (err) {
      throw new ApiError(
        400,
        "Something when wrong when looking for this user!"
      );
    } finally {
      await prisma.$disconnect();
    }
  }

  async delete(id: string) {
    try {
      await prisma.review.deleteMany({
        where: {
          userId: id,
        },
      });
      await prisma.recipe.deleteMany({
        where: {
          authorID: id,
        },
      });
      await prisma.userPreferences.delete({
        where: {
          userId: id,
        },
      });
      const user = await prisma.user.delete({
        where: {
          id: id,
        },
      });
      return user;
    } catch (err: any) {
      throw new ApiError(400, err.message);
    } finally {
      await prisma.$disconnect();
    }
  }

  async update(id: string, data: Prisma.UserUpdateInput) {
    try {
      const user = await prisma.user.update({
        where: { id },
        data,
        include: { userPreferences: true, userRecipes: true },
      });
      return user;
    } catch (err: any) {
      throw new ApiError(404, err.message);
    } finally {
      await prisma.$disconnect();
    }
  }

  async readGoogle(googleId: string) {
    try {
      const user = await prisma.user.findUnique({
        where: {
          googleId: googleId,
        },
      });
      return user;
    } catch (err) {
      throw new ApiError(
        400,
        "Something went wrong when looking for this user!"
      );
    } finally {
      await prisma.$disconnect();
    }
  }

  async updateGoogle(email: string, googleId: string, image: string) {
    try {
      const userPrefs = await prisma.userPreferences.create({
        data: {
          ingredientsExcluded: [],
          difficulty: 5,
          timeInMins: 2147483647,
          kosher: false,
          vegan: false,
          vegetarian: false,
          halal: false,
          keto: false,
          glutenFree: false,
          nonDairy: false,
          cuisineTags: {
            create: [],
          },
        },
      });
      const user = await prisma.user.upsert({
        where: { email: email },
        update: {
          googleId,
          image,
        },
        create: {
          email,
          googleId,
          password: "temp",
          username: email,
          verified: true,
          userPreferences: { connect: { id: userPrefs.id } },
          image,
        },
      });

      const updatedPrefs = await prisma.userPreferences.update({
        where: { id: userPrefs.id },
        data: {
          user: {
            connect: { id: user.id },
          },
          userId: user.id,
        },
      });
      return user;
    } catch (err: any) {
      throw new ApiError(400, err.message);
    } finally {
      await prisma.$disconnect();
    }
  }

  async deleteAll() {
    const deletedUsers = await prisma.user.deleteMany({});
  }
}

export default UserDAO;
