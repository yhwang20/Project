const myApp = require("./index");
const portNum = process.env.PORT || 4000;
myApp.listen(portNum, () => {
  console.log(`Server is running on port: ${portNum}`);
});
