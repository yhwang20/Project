import express from "express";
import ApiError from "../model/ApiError";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();

const router = express.Router();
const endpoint = "/tag";

// Get all tags
router.get(`${endpoint}`, async (req, res) => {
  try {
    const tags = await prisma.tag.findMany();
    res.json({
      status: 200,
      message: `Successfully retrieved ${tags.length} tags!`,
      data: tags,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

// Get unique tag with given tag name
router.get(`${endpoint}/:name`, async (req, res) => {
  try {
    const { name } = req.params;
    const tag = await prisma.tag.findUnique({
      where: {
        name: name,
      },
    });
    res.json({
      status: 200,
      message: `Successfully retrieved tag!`,
      data: tag,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

// Create new tag with given name
router.post(endpoint, async (req, res) => {
  try {
    const { name } = req.body;
    const tag = await prisma.tag.create({
      data: {
        name: name,
      },
    });
    res.json({
      status: 200,
      message: `Successfully created tag!`,
      data: tag,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

// Update tag with given name to have newName
router.put(`${endpoint}/:name`, async (req, res) => {
  try {
    const { name } = req.params;
    const { newName } = req.body;
    const checkTag = await prisma.tag.findUnique({
      where: {
        name: newName,
      },
    });
    if (checkTag) {
      throw new ApiError(400, "Tag name already exists!");
    }
    const tag = await prisma.tag.update({
      where: {
        name: name,
      },
      data: {
        name: newName,
      },
    });
    res.json({
      status: 200,
      message: `Successfully updated tag!`,
      data: tag,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

// Delete tag with given name
router.delete(`${endpoint}/:name`, async (req, res) => {
  try {
    const { name } = req.params;
    const tag = await prisma.tag.delete({
      where: {
        name: name,
      },
    });
    res.json({
      status: 200,
      message: `Successfully deleted tag!`,
      data: tag,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

module.exports = router;
