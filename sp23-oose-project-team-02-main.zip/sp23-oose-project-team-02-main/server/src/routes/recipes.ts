import express from "express";
import RecipeDAO from "../data/RecipeDao";
import ApiError from "../model/ApiError";
import { PrismaClient } from "@prisma/client";
const prisma = new PrismaClient();
import UserDAO from "../data/UserDao";

const router = express.Router();
export const userDao = new UserDAO();
export const recipeDao = new RecipeDAO();
const endpoint = "/recipes";

// Get all recipes
router.get(`${endpoint}`, async (req, res) => {
  try {
    const recipes = await recipeDao.readAll();
    res.json({
      status: 200,
      message: `Successfully retrieved ${recipes.length} recipes!`,
      data: recipes,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

// Search for recipes by name and filter results by searchTags
router.get(`${endpoint}/search`, async (req, res) => {
  console.log("in get recipes route handler");
  try {
    const {
      UserId,
      includedTags,
      ingredients,
      excludedIngredients,
      excludedTags,
      cookTime,
      prepTime,
      rating,
      maxDifficulty,
      userQuery,
      sort,
    }: {
      UserId?: string;
      includedTags?: string;
      ingredients?: string;
      excludedIngredients?: string;
      excludedTags?: string;
      cookTime?: string;
      prepTime?: string;
      rating?: string;
      maxDifficulty?: string;
      userQuery?: string;
      sort?: string;
    } = req.query;
    let includedTagsString,
      ingredientString,
      excludedIngredientsString,
      excludedTagsString,
      cookingTimeInt,
      prepTimeInt,
      maxDifficultyInt,
      ratingInt;
    if (includedTags?.trim() !== "") {
      includedTagsString = includedTags!.split(",").map((tag: string) => {
        return tag.trim().toLowerCase();
      });
    }
    if (ingredients?.trim() !== "") {
      ingredientString = ingredients!.split(",").map((ingredient: string) => {
        return ingredient.trim().toLowerCase();
      });
    }
    if (excludedIngredients?.trim() !== "") {
      excludedIngredientsString = excludedIngredients!
        .split(",")
        .map((ingredient: string) => {
          return ingredient.trim().toLowerCase();
        });
    }
    if (excludedTags?.trim() !== "") {
      excludedTagsString = excludedTags!.split(",").map((tag: string) => {
        return tag.trim().toLowerCase();
      });
    }

    if (cookTime !== undefined && cookTime !== "") {
      cookingTimeInt = parseInt(cookTime);
    }
    if (prepTime !== undefined && prepTime !== "") {
      prepTimeInt = parseInt(prepTime);
    }
    if (rating !== undefined && rating !== "") {
      ratingInt = parseInt(rating);
    }
    if (maxDifficulty !== undefined && maxDifficulty !== "") {
      maxDifficultyInt = parseInt(maxDifficulty);
    }
    const recipes = await recipeDao.search(
      UserId,
      includedTagsString,
      ingredientString,
      excludedIngredientsString,
      excludedTagsString,
      cookingTimeInt,
      prepTimeInt,
      ratingInt,
      maxDifficultyInt,
      userQuery
    );

    res.json({
      status: 200,
      message: `Successfully retrieved ${recipes.length} recipes!`,
      data: recipes,
    });
  } catch (err: any) {
    console.log(err.message);
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

// Search for recipes by name and filter results by searchTags
/*router.get(`${endpoint}/gptsearch`, async (req, res) => {
  console.log("in gpt get recipes route handler");
  try {
    const {
      UserId,
      gptQuery,
    }: {
      UserId?: string;
      gptQuery?: string;
    } = req.query;
    const recipes = await recipeDao.searchGPT(UserId, gptQuery);

    if (recipes === undefined) {
      throw new ApiError(404, "No recipes returned by query");
    }
    res.json({
      status: 200,
      message: `Successfully retrieved ${recipes.data.length} recipes!`,
      data: recipes,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});*/

// Returns a single recipe with the given ID
router.get(`${endpoint}/:id`, async (req, res) => {
  try {
    const { id } = req.params;
    const recipe = await recipeDao.read(id);
    res.json({
      status: 200,
      message: `Successfully retrieved the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

// Creates a new recipe
router.post(`${endpoint}`, async (req, res) => {
  try {
    const {
      name,
      ingredients,
      background,
      procedure,
      tools,
      prepTimeInMins,
      cookTimeInMins,
      difficulty,
      authorID,
      avgRating,
      photo,
      nutrition,
      tags,
      servings,
    } = req.body;
    const numDiff = parseInt(difficulty, 10);
    const author = await prisma.user.findUnique({
      where: { id: authorID },
    });
    if (!author) {
      throw new ApiError(404, "There is no user with the given ID!");
    }
    const recipe = await recipeDao.create({
      name,
      ingredients,
      procedure,
      tools,
      prepTimeInMins,
      cookTimeInMins,
      difficulty: numDiff,
      nutrition,
      photo,
      author: { connect: { id: authorID } },
      avgRating,
      favoritedBy: {
        connect: undefined,
      },
      tags,
      servings,
      reviews: {
        connect: undefined,
      },
      background: background,
    });
    res.status(201).json({
      status: 201,
      message: `Successfully created the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    console.log(err);
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

//Adds a recipe tag to a recipe
/* router.put(`${endpoint}/:id/add_tags`, async (req, res) => {
  try {
    const { id } = req.params;
    const { tagName } = req.body;
    const tag = await prisma.tag.findUnique({ where: { name: tagName } });
    if (!tag) {
      throw new ApiError(404, "There is no tag with the given name!");
    }
    const recipeTag = await recipeDao.updateTags(id, tagid);
    res.status(201).json({
      status: 201,
      message: `Successfully added the following recipe tag to ${id}!`,
      data: recipeTag,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

//Removes a recipe tag to a recipe
router.put(`${endpoint}/:id/delete_tags`, async (req, res) => {
  try {
    const { id } = req.params;
    const { tagName } = req.body;
    const tag = await prisma.tag.findUnique({ where: { name: tagName } });
    if (!tag) {
      throw new ApiError(404, "There is no tag with the given name!");
    }
    const recipeTag = await recipeDao.updateTags(id, tag.id, false);
    res.status(201).json({
      status: 201,
      message: `Successfully added the following recipe tag to ${id}!`,
      data: recipeTag,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
}); */

// Updates a recipe with the given ID
router.put(`${endpoint}/:id`, async (req, res) => {
  try {
    const { id } = req.params;
    const updatedRecipeData = req.body;
    const recipe = await recipeDao.update(id, updatedRecipeData);
    res.json({
      status: 200,
      message: `Successfully updated the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    console.log(err);
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

// Updates a recipe's author with the given ID
router.put(`${endpoint}/:id/author`, async (req, res) => {
  try {
    const { id } = req.params;
    const { authorID } = req.body;
    const recipe = await recipeDao.updateAuthor(id, authorID);
    res.json({
      status: 200,
      message: `Successfully updated the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

// Updates the favoritedBy field of a recipe with the given ID
router.put(`${endpoint}/:id/favorite/:userId`, async (req, res) => {
  try {
    const { id, userId } = req.params;
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new ApiError(404, "There is no user with the given ID!");
    }
    const recipe = await recipeDao.updateFavorite(id, userId, true);
    res.json({
      status: 200,
      message: `Successfully updated the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    res.status(404).json({
      status: err.status,
      message: err.message,
    });
  }
});

// Updates the favoritedBy field of a recipe with the given ID by un-favoriting
router.delete(`${endpoint}/:id/favorite/:userId`, async (req, res) => {
  try {
    const { id, userId } = req.params;
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new ApiError(404, "There is no user with the given ID!");
    }
    const recipe = await recipeDao.updateFavorite(id, userId, false);
    res.json({
      status: 200,
      message: `Successfully updated the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    res.status(404).json({
      status: err.status,
      message: err.message,
    });
  }
});
// Deletes a recipe with the given ID
router.delete(`${endpoint}/:id`, async (req, res) => {
  try {
    const { id } = req.params;
    const recipe = await recipeDao.delete(id);
    res.json({
      status: 200,
      message: `Successfully deleted the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.put(`${endpoint}/:id/review`, async (req, res) => {
  try {
    const { id } = req.params;
    const { userId, score, comment } = req.body;
    const user = await prisma.user.findUnique({ where: { id: userId } });
    if (!user) {
      throw new ApiError(404, "There is no user with the given ID!");
    }
    const recipe = await recipeDao.addReview(id, userId, score, comment);
    res.json({
      status: 200,
      message: `Successfully updated the following recipe!`,
      data: recipe,
    });
  } catch (err: any) {
    res.status(404).json({
      status: err.status,
      message: err.message,
    });
  }
});

module.exports = router;
