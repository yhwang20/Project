import express from "express";
import UserDAO from "../data/UserDao";
import { verifyPassword } from "../password";
import ApiError from "../model/ApiError";
import { createToken, decodeToken } from "../token";
import path from "path";

const router = express.Router();
const userDao = new UserDAO();
const endpoint = "/auth";
router.post(`${endpoint}/login`, async (req, res, next) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      throw new ApiError(
        400,
        "You must provide both email and password to login."
      );
    }

    const users = await userDao.readAll(email);
    if (users.length === 0) {
      throw new ApiError(402, "Invalid email");
    }
    console.log(users);
    // Since emails are unique, there will be only one matching user
    const user = users[0];
    // Verify the password
    const result = verifyPassword(password, user.password);
    if (!result) {
      throw new ApiError(403, "Wrong email or password!");
    }
    const token = createToken(user);
    res.json({
      status: 201,
      message: `Successfully logged in!`,
      data: {
        id: user.id,
        email: user.email,
        user: user.username,
        confirmed: user.verified,
        picture: user.image,
      },
      token,
    });
    console.log("Successfully logged in!");
  } catch (err: any) {
    res.json({
      status: 403,
      message: err.messsage,
    });
  }
});

router.get(`${endpoint}/verify-email`, async (req, res) => {
  try {
    const token = req.query.token as string;
    if (!token) {
      throw new ApiError(400, "No token provided!");
    }
    const decodedToken = decodeToken(token) as { id: string };

    if (!decodedToken.id) {
      throw new ApiError(400, "Invalid token!");
    }

    const user = await userDao.update(decodedToken.id, { verified: true });
    res.sendFile(path.join(__dirname, "../public/verified.html"));
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

module.exports = router;
