import express from "express";
import UserDAO from "../data/UserDao";
import ApiError from "../model/ApiError";
import nodemailer from "nodemailer";
import dotenv from "dotenv";
import { createToken } from "../token";

dotenv.config();

const router = express.Router();

export const userDao = new UserDAO();

let transporter = nodemailer.createTransport({
  service: "gmail",
  auth: {
    user: process.env.AUTH_EMAIL,
    pass: process.env.AUTH_APP_PASSWORD,
  },
});

transporter.verify((error) => {
  if (error) {
    console.log(error);
  } else {
    console.log("Server is ready to take messages");
  }
});

router.get("/users", async (req, res) => {
  try {
    const { email }: { email?: string } = req.body;
    const users = await userDao.readAll(email);
    const usersWithoutPasswords = users.map((user) => {
      return exclude(user, ["password"]);
    });
    res.json({
      status: 200,
      message: `Successfully retrieved ${users.length} users!`,
      data: usersWithoutPasswords,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.get("/users/:id", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const user = await userDao.read(id);
    if (!user) {
      throw new ApiError(404, "There is no such user with this id!");
    }
    const userWithoutPassword = exclude(user, ["password"]);
    res.json({
      status: 200,
      message: `Successfully retrieved the following user!`,
      data: userWithoutPassword,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.post("/users/google", async (req, res) => {
  let { email, googleId, image } = req.body;
  try {
    const user = await userDao.updateGoogle(email, googleId, image);
    const userWithoutPassword = exclude(user, ["password"]);
    res.json({
      status: 200,
      message: `Successfully updated the following user!`,
      data: userWithoutPassword,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.get("/users/google/:id", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const user = await userDao.readGoogle(id);
    if (!user) {
      throw new ApiError(404, "There is no such user with this id!");
    }
    const userWithoutPassword = exclude(user, ["password"]);
    res.json({
      status: 200,
      message: `Successfully retrieved the following user!`,
      data: userWithoutPassword,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.post("/users/signup", async (req, res) => {
  try {
    let { username, email, password } = req.body;

    const user = await userDao.create({
      username: username,
      password: password,
      email: email,
    });
    const userWithoutPassword = exclude(user, ["password"]);
    const token = createToken(user, "15m");
    const message = {
      from: process.env.AUTH_EMAIL,
      to: user.email,
      subject: "Please verify your email",
      html: `
      <p>Dear ${user.username},</p>

      <p>Thank you for signing up for our service!</p>
      <p>Please click the following link to verify your email:</p>
      <a href="${process.env.BASE_URL}/auth/verify-email?token=${token}">Verify Email</a>
    `,
    };

    transporter.sendMail(message, (error, info) => {
      if (error) {
        console.log(error);
      } else {
        console.log("Verification email sent: " + info.response);
      }
    });
    res.status(201).json({
      status: 201,
      message: `Successfully created the following user and sent a verification email to ${user.email}`,
      data: userWithoutPassword,
    });
  } catch (err: any) {
    console.log(err);
    res.status(404).json({
      status: 404,
      message: err.message,
    });
  }
});

router.put("/users/:id", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const updatedUserData = req.body;
    const updatedUser = await userDao.update(id, updatedUserData);
    const userWithoutPassword = exclude(updatedUser, ["password"]);
    res.json({
      status: 200,
      message: `Successfully updated the following user!`,
      data: userWithoutPassword,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.delete("/users/:id", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const user = await userDao.delete(id);
    const userWithoutPassword = exclude(user, ["password"]);
    res.json({
      status: 200,
      message: `Successfully deleted the following user!`,
      data: userWithoutPassword,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

function exclude<User, Key extends keyof User>(
  user: User,
  keys: Key[]
): Omit<User, Key> {
  for (let key of keys) {
    delete user[key];
  }
  return user;
}
module.exports = router;
