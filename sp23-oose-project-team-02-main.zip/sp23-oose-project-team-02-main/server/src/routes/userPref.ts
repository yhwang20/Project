import express from "express";
import UserDAO from "../data/UserDao";
import ApiError from "../model/ApiError";
import { PrismaClient } from "@prisma/client";
import UserPrefDAO from "../data/UserPrefDao";
const prisma = new PrismaClient();

const router = express.Router();

export const userPreferences = new UserPrefDAO();
export const user = new UserDAO();

router.get("/user/:id/preferences", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const userPreference = await userPreferences.read(id);
    if (!userPreference) {
      throw new ApiError(404, "There is no such user with this id!");
    }
    res.json({
      status: 200,
      message: `Successfully retrieved the following userPreference!`,
      data: userPreference,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.post("/user/:id/preferences", async (req, res) => {
  try {
    let {
      ingredientsExcluded,
      vegan,
      vegetarian,
      kosher,
      halal,
      keto,
      nonDairy,
      glutenFree,
      timeInMins,
      difficulty,
      cuisineTags,
    } = req.body;
    const { id }: { id?: string } = req.params;
    const userPreference = await userPreferences.create({
      ingredientsExcluded: ingredientsExcluded,
      vegan: vegan,
      vegetarian: vegetarian,
      kosher: kosher,
      halal: halal,
      keto: keto,
      glutenFree: glutenFree,
      nonDairy: nonDairy,
      timeInMins: timeInMins,
      difficulty: difficulty,
      userId: id,
      cuisineTags: cuisineTags,
    });
    res.json({
      status: 201,
      message: `Successfully created the following userPreferences!`,
      data: userPreference,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

router.put("/user/:id/preferences", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const updatedPreferenceData = req.body;
    const updatedUserPreference = await userPreferences.update(
      id,
      updatedPreferenceData
    );
    res.json({
      status: 200,
      message: `Successfully updated the following user preferences!`,
      data: updatedUserPreference,
    });
  } catch (err: any) {
    res.json({
      status: err.status,
      message: err.message,
    });
  }
});

router.delete("/user/:id/preferences", async (req, res) => {
  try {
    const { id }: { id?: string } = req.params;
    const deletedUserPreference = await userPreferences.delete(id);
    res.json({
      status: 200,
      message: `Sucessfully deleted user preferences`,
      data: deletedUserPreference,
    });
  } catch (err: any) {
    res.status(err.status).json({
      status: err.status,
      message: err.message,
    });
  }
});

module.exports = router;
