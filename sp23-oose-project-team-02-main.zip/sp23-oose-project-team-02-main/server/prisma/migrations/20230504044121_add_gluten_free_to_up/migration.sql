-- AlterTable
ALTER TABLE "userPreferences" ADD COLUMN     "glutenFree" BOOLEAN NOT NULL DEFAULT false;
