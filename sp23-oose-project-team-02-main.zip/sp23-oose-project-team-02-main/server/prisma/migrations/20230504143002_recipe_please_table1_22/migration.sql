-- DropIndex
DROP INDEX "User_username_key";
