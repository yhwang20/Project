-- AlterTable
ALTER TABLE "Recipe" ALTER COLUMN "avgRating" SET DEFAULT 5;
