-- AlterTable
ALTER TABLE "userPreferences" ADD COLUMN     "nonDairy" BOOLEAN NOT NULL DEFAULT false;
