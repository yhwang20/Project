-- DropIndex
DROP INDEX "Recipe_avgRating_servings_difficulty_cookTimeInMins_prepTim_idx";

-- CreateIndex
CREATE INDEX "Recipe_avgRating_servings_difficulty_cookTimeInMins_prepTim_idx" ON "Recipe"("avgRating", "servings", "difficulty", "cookTimeInMins", "prepTimeInMins", "ingredientString");
