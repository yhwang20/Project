-- AlterTable
ALTER TABLE "Recipe" ADD COLUMN     "tagString" TEXT DEFAULT '';
