import request from "supertest";
import { User, userPreferences } from "@prisma/client";
import prisma from "../prisma/client";
import { v4 as uuidv4 } from "uuid";
import UserDAO from "../src/data/UserDao";
export const userDao = new UserDAO();
const app = require("../src/index");
jest.setTimeout(30000);
describe("UserPreference API endpoints", () => {
  let id3: string;
  let id: string;
  let id2: string;
  let defaultUserPreferences: userPreferences;
  beforeEach(async () => {

    await prisma.user.deleteMany({ where: { email: "yusoo0722@gmail.com" } });
    defaultUserPreferences = {
      id: uuidv4(),
      ingredientsExcluded: [],
      difficulty: 5,
      timeInMins: 2147483647,
      vegan: false,
      vegetarian: false,
      kosher: false,
      halal: false,
      keto: false,
      nonDairy: false,
      glutenFree: false,
      userId: null,
    };
    const ourUser = await prisma.user.upsert(
        {where: {email: "yhwang20@jh.edu"},
      update: {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      },
          create: {
            email: "yhwang20@jh.edu",
            username: "yuso500",
            password: "yuso100",
            image: "google.come",
            googleId: "yusoo0722",
            verified: true,
          }
    });
    id3 = ourUser.id;
    const secondUser = await prisma.user.upsert({
      where: {email: "yusoo0722@gmail.com"},
      update: {
        email: "yusoo0722@gmail.com",
        username: "yunggnome",
        password: "yusoo2002",
        image: "dog",
        googleId: "yungmoney",
        verified: true,
      },
      create: {
        email: "yusoo0722@gmail.com",
        username: "yunggnome",
        password: "yusoo2002",
        image: "dog",
        googleId: "yungmoney",
        verified: true,
      },
    });
    id2 = secondUser.id;
    const userWithPreference = await userDao.updateGoogle(
      "yhwang20@jh.edu",
      "yusoo0722",
      "cat"
    );
    if(userWithPreference.userPreferencesId) {
      id = userWithPreference.userPreferencesId;
    }

  }, 25000);
  afterEach(async () => {
    await prisma.user.deleteMany({ where: { email: "yhwang20@jh.edu" } });
    await prisma.user.deleteMany({ where: { email: "yusoo0722@gmail.com" } });

    await prisma.userPreferences.deleteMany({ where: { userId: id } });
    await prisma.userPreferences.deleteMany({ where: { userId: id2 } });
  }, 20000);

  describe("GET /user/:id/preferences", () => {
    it("should return the given user's preferences", async () => {
      const response = await request(app).get(`/user/${id}/preferences`);
      expect(response.status).toBe(200);
      expect(response.body.data.difficulty).toEqual(
        defaultUserPreferences.difficulty
      );
      expect(response.body.data.timeInMins).toEqual(
        defaultUserPreferences.timeInMins
      );
      expect(response.body.data.vegan).toEqual(defaultUserPreferences.vegan);
    });
  });

  describe("POST /user/:id/preferences", () => {
    it("should return created user's preferences", async () => {
      const body = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 180,
        difficulty: 4,
        cuisineTags: {
          create: [],
        },
        nonDairy: false,
        glutenFree: false,
      };

      const response = await request(app)
        .post(`/user/${id2}/preferences`)
        .send(body);
      expect(response.body.data.vegan).toEqual(body.vegan);
      expect(response.body.data.timeInMins).toEqual(body.timeInMins);
      expect(response.body.data.difficulty).toEqual(body.difficulty);
    });
  });

  describe("PUT /user/:id/preferences", () => {
    it("should update user's preferences", async () => {
      const updatedPreferenceData = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 180,
        difficulty: 4,
        cuisineTags: {
          create: [],
        },
      };
      const response = await request(app)
        .put(`/user/${id3}/preferences`)
        .send(updatedPreferenceData);
      expect(response.status).toBe(200);
      expect(response.body.data.difficulty).toEqual(
        updatedPreferenceData.difficulty
      );
      expect(response.body.data.timeInMins).toEqual(
        updatedPreferenceData.timeInMins
      );
      expect(response.body.data.vegan).toEqual(updatedPreferenceData.vegan);
    });
  });

  describe("Delete /user/:id/preferences", () => {
    it("should delete user's userPreference", async () => {
      const response = await request(app).delete(`/user/${id3}/preferences`);
      expect(response.status).toBe(200);
      expect(response.body.data.difficulty).toEqual(5);
      expect(response.body.data.timeInMins).toEqual(2147483647);
      expect(response.body.data.vegan).toEqual(false);
    });
  });
});
