import TagDAO from "../src/data/TagDao";
import RecipeDAO from "../src/data/RecipeDao";
import UserDAO from "../src/data/UserDao";
import UserPrefDAO from "../src/data/UserPrefDao";
import ApiError from "../src/model/ApiError";
import { User, Role, userPreferences, Tag, Recipe } from "@prisma/client";
import prisma from "../prisma/client";


const userDAO = new UserDAO();
const tagDAO = new TagDAO();
const recipeDAO = new RecipeDAO();
const userPrefDAO = new UserPrefDAO();
let id: string;
let id2: string;
let id3: string;
describe("Test UserPrefDAO", () => {
  beforeEach(async () => {
    await prisma.user.deleteMany({ where: { email: "yhwang20@jh.edu" } });
    const ourUser = await prisma.user.create({
      data: {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      },
    });
    id = ourUser.id;
    const secondUser = await prisma.user.create({
      data: {
        email: "yusoo0722@gmail.com",
        username: "yunggnome",
        password: "yusoo2002",
        image: "dog",
        googleId: "yungmoney",
        verified: true,
      },
    });
    id2 = secondUser.id;
    const userWithPreference = await userDAO.updateGoogle(
      "yusoo0722@gmail.com",
      "yunggnome",
      "cat"
    );
    if(userWithPreference.userPreferencesId) {
      id3 = userWithPreference.userPreferencesId;
    }

  }, 25000);
  afterEach(async () => {
    await prisma.user.deleteMany({ where: { email: "yhwang20@jh.edu" } });
    await prisma.user.deleteMany({ where: { email: "yusoo0722@gmail.com" } });
    await prisma.userPreferences.deleteMany({ where: { userId: id } });
    await prisma.userPreferences.deleteMany({ where: { userId: id2 } });
  }, 20000);
  describe("Creating User Preferences", () => {
    it("test create() with valid userId", async () => {
      const userPrefData = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 180,
        difficulty: 4,
        cuisineTags: {
          create: [],
        },
        nonDairy: false,
        glutenFree: false,
        halal: false,
        userId: id,
      };
      const userPref = await userPrefDAO.create(userPrefData);
      expect(userPref.vegan).toEqual(false);
      expect(userPref.timeInMins).toEqual(180);
      expect(userPref.nonDairy).toEqual(false);
    });
    it("test create() with no userId", async () => {
      const userPrefData = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 180,
        difficulty: 4,
        cuisineTags: {
          create: [],
        },
        nonDairy: false,
        glutenFree: false,
        halal: false,
      };
      await expect(userPrefDAO.create(userPrefData)).rejects.toThrow(
        new ApiError(400, "User ID is required!")
      );
    });
    it("test create() with invalid userId", async () => {
      try {
        const userPrefData = {
          ingredientsExcluded: "mushroom",
          vegan: false,
          vegetarian: false,
          kosher: false,
          keto: false,
          timeInMins: 180,
          difficulty: 4,
          cuisineTags: {
            create: [],
          },
          nonDairy: false,
          glutenFree: false,
          halal: false,
          userId: "pickle",
        };
        const userPref = await userPrefDAO.create(userPrefData);
      } catch (err) {
        expect(err).toBeDefined();
      }
    });
  });
  describe("Reading User Preferences", () => {
    it("test read() with valid id", async () => {
      const userPref = await userPrefDAO.read(
        "e6168b12-413c-47c0-a4a4-1c681a22ea66"
      );
      expect(userPref?.nonDairy).toEqual(false);
      expect(userPref?.timeInMins).toEqual(3000);
      expect(userPref?.difficulty).toEqual(5);
    });
    it("test read() given invalid id", async () => {
      try {
        const userPref = userPrefDAO.read("johnny");
      } catch (err) {
        expect(err).toBeDefined();
      }
      // await expect(userPrefDAO.read("johnny")).rejects.toThrow(
      //   new ApiError(400, "Something when wrong when looking for this set of user preferences!")
      // )
    });
  });
  describe("Updating User Preferences", () => {
    it("test update() with valid id", async () => {
      const userPrefData = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 300,
        difficulty: 2,
        cuisineTags: {
          create: [],
        },
        nonDairy: false,
        glutenFree: true,
        halal: true,
      };
      const updatedUserPref = await userPrefDAO.update(id2, userPrefData);
      expect(updatedUserPref.difficulty).toEqual(userPrefData.difficulty);
      expect(updatedUserPref.timeInMins).toEqual(userPrefData.timeInMins);
      expect(updatedUserPref.halal).toEqual(userPrefData.halal);
    });
    it("test update() with non-existing userId", async () => {
      const userPrefData = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 300,
        difficulty: 2,
        cuisineTags: {
          create: [],
        },
        nonDairy: false,
        glutenFree: true,
        halal: true,
      };
      await expect(userPrefDAO.update("johnny", userPrefData)).rejects.toThrow(
        new ApiError(403, "Could not find user with the given id.")
      );
    });
    it("test update() with user that has no userPreference", async () => {
      const userPrefData = {
        ingredientsExcluded: "mushroom",
        vegan: false,
        vegetarian: false,
        kosher: false,
        keto: false,
        timeInMins: 300,
        difficulty: 2,
        cuisineTags: {
          create: [],
        },
        nonDairy: false,
        glutenFree: true,
        halal: true,
      };
      await expect(
        userPrefDAO.update("640bdcf1-25b3-4f51-99af-a2ecbb5f978a", userPrefData)
      ).rejects.toThrow(
        new ApiError(403, "Could not find user preferences with the given id.")
      );
    });
  });
  describe("Deleting UserPreferences", () => {
    it("test delete() with a valid userId", async () => {
      const deletedUserPref = await userPrefDAO.delete(id2);
      expect(deletedUserPref.difficulty).toEqual(5);
      expect(deletedUserPref.timeInMins).toEqual(2147483647);
      expect(deletedUserPref.vegan).toEqual(false);
    });
    it("test delete() with invalid userId", async () => {
      await expect(userPrefDAO.delete("baby")).rejects.toThrow(
        new ApiError(404, "Could not find User Preferences for the given id.")
      );
    });
    it("test delete() with user with no userPreference", async () => {
      await expect(
        userPrefDAO.delete("640bdcf1-25b3-4f51-99af-a2ecbb5f978a")
      ).rejects.toThrow(
        new ApiError(404, "Could not find User Preferences for the given id.")
      );
    });
  });
});
