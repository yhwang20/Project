import request from "supertest";
import { User, Role, userPreferences, Tag, Recipe } from "@prisma/client";
import prisma from "../prisma/client";
import { v4 as uuidv4 } from "uuid";
const app = require("../src/index");
let testUser: User;
let id: string;
describe("User API endpoints", () => {
  beforeEach(async () => {
    await prisma.user.deleteMany({ where: { email: "newuser@example.com" } });
    await prisma.userPreferences.deleteMany({ where: { userId: "yusoo" } });
    const defaultUserPreferences: userPreferences = {
      id: uuidv4(),
      ingredientsExcluded: [],
      difficulty: 5,
      timeInMins: 100,
      vegan: false,
      vegetarian: false,
      kosher: false,
      halal: false,
      nonDairy: false,
      glutenFree: false,
      keto: false,
      userId: null,
    };

    testUser = {
      id: "234",
      email: "yhwang20@jh.edu",
      username: "yuso500",
      password: "yuso100",
      image: "google.come",
      googleId: "yusoo0722",
      verified: true,
      role: Role.BASIC,
      userPreferencesId: defaultUserPreferences.id,
      setupComplete: true,
    };
    const ourUser = await prisma.user.upsert({
      where: {email: "yhwang20@jh.edu"},
      update: {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      },
      create: {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      },
    });
    id = ourUser.id;
  });

  afterEach(async () => {
    await prisma.user.deleteMany({ where: { email: "yhwang20@jh.edu" } });
    await prisma.user.deleteMany({ where: { email: "newuser@example.com" } });
    await prisma.userPreferences.deleteMany({ where: { userId: "yusoo" } });
    await prisma.user.deleteMany({ where: { email: "treeLover@gmail.com" } });
  });

  describe("GET /users", () => {
    it("should return all users when no email is provided", async () => {
      const response = await request(app).get("/users");
      expect(response.status).toBe(200);
      expect(response.body.data.length).toBeGreaterThan(1);
    });

    it("should return users matching the provided email", async () => {
      const body = {
        email: "yhwang20@jh.edu",
      };
      const response = await request(app).get("/users").send(body);
      expect(response.status).toBe(200);
      expect(response.body.data[0].email).toEqual(testUser.email);
      expect(response.body.data[0].googleId).toEqual(testUser.googleId);
      expect(response.body.data[0].username).toEqual(testUser.username);
    });
  });

  describe("GET /users/:id", () => {
    it("should return user given id", async () => {
      const response = await request(app).get(`/users/${id}`);
      expect(response.status).toBe(200);
      expect(response.body.data.email).toEqual(testUser.email);
      expect(response.body.data.googleId).toEqual(testUser.googleId);
      expect(response.body.data.username).toEqual(testUser.username);
    });
  });

  describe("GET /users/google/:id", () => {
    it("should return a user with the provided email", async () => {
      const response = await request(app).get(
        `/users/google/${testUser.googleId}`
      );
      expect(response.status).toBe(200);
      expect(response.body.data.username).toEqual(testUser.username);
      expect(response.body.data.email).toEqual(testUser.email);
      expect(response.body.data.googleId).toEqual(testUser.googleId);
    });

    it("should return a 404 error when there is no user with the provided id", async () => {
      const response = await request(app).get(
        "/users/google/nonexistent@example.com"
      );
      expect(response.status).toBe(404);
      expect(response.body.message).toBe("There is no such user with this id!");
    });
  });

  describe("POST /users/google", () => {
    it("should create/update user given email", async () => {
      const body = {
        email: "yhwang20@jh.edu",
        googleId: "johnnyAppleSeed",
        image: "yahoo.com",
      };
      const response = await request(app).post("/users/google").send(body);
      expect(response.status).toBe(200);
      expect(response.body.data.googleId).toEqual(body.googleId);
      expect(response.body.data.image).toEqual(body.image);
    });
  });

  describe("POST /users/signup", () => {
    it("should create a user after user has signed up", async () => {
      const body = {
        username: "treeLover",
        password: "treeLover123",
        email: "treeLover@gmail.com",
      };
      const response = await request(app).post("/users/signup").send(body);
      expect(response.body.status).toBe(201);
      expect(response.body.message).toEqual(
        `Successfully created the following user and sent a verification email to ${body.email}`
      );
      expect(response.body.data.username).toEqual(body.username);
    });
  });

  describe("PUT /users/:id", () => {
    it("should update a user with the provided id", async () => {
      const updatedUser = {
        username: "Andy",
      };
      console.log(id);
      const response = await request(app).put(`/users/${id}`).send(updatedUser);
      expect(response.status).toBe(200);
      expect(response.body.data.username).toBe(updatedUser.username);
      expect(response.body.data.email).toEqual(testUser.email);
      expect(response.body.data.googleId).toEqual(testUser.googleId);
    });
  });

  describe("DELETE /users/:id", () => {
    it("should delete a user with the provided id", async () => {
      const response = await request(app).delete(`/users/${id}`);
      expect(response.status).toBe(200);
      expect(response.body.data).toBeDefined();
      expect(response.body.data.username).toEqual(testUser.username);
      expect(response.body.data.email).toEqual(testUser.email);
      expect(response.body.data.googleId).toEqual(testUser.googleId);
    });
  });
});
