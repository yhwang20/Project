import RecipeDAO from "../src/data/RecipeDao";
import UserDAO from "../src/data/UserDao";
import UserPrefDAO from "../src/data/UserPrefDao";
const { getType } = require("jest-get-type");
const recipeDAO = new RecipeDAO();
const userDAO = new UserDAO();
const userPrefDAO = new UserPrefDAO();
import ApiError from "../src/model/ApiError";
import {
  Prisma,
  PrismaClient,
  Tag,
  User,
  userPreferences,
} from "@prisma/client";
const prisma = new PrismaClient();
let testUser1: void | User;
let recipe1ID: String;
let recipe2ID: String;
let data1: Prisma.RecipeCreateInput;
let data2: Prisma.RecipeCreateInput;
let tag1: Tag;
let tag2: Tag;
describe("Test recipeDAO search_gpt method", () => {
  beforeAll(async () => {
    const test_email = "search_test_gpt_email@jh.edu";
    const tag1_name = "search_testgpt_tag_1";
    const tag2_name = "search_testgpt_tag_2";
    tag1 = await prisma.tag.upsert({
      where: { name: tag1_name },
      update: {},
      create: {
        name: tag1_name,
      },
    });
    tag2 = await prisma.tag.upsert({
      where: {
        name: tag2_name,
      },
      update: {},
      create: {
        name: tag2_name,
      },
    });
    testUser1 = await prisma.user
      .upsert({
        where: {
          email: test_email,
        },
        update: {},
        create: {
          email: test_email,
          username: "search_testgpt_user",
          password: "search_test",
          image: "google.come",
          googleId: "gptt1111",
          verified: true,
        },
      })
      .then(async (user) => {
        if (user) {
          data1 = {
            name: "Search Test Recipe 1: Chicken, Spinach, Parmesan Recipe",
            ingredients: [
              "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
              "extra-virgin olive oil: 2 tablespoons",
              "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
              "salt: ½ teaspoon",
              "ground pepper: ¼ teaspoon",
              "garlic, minced: 4 cloves",
              "dry white wine: ½ cup",
              "Juice and zest of lemon: 1",
              "chopped fresh spinach: 10 cups ",
              "grated Parmesan cheese, divided: 4 tablespoons",
            ],
            procedure: [
              "Cook pasta according to package directions. Drain and set aside.",
              "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
              "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
            ],
            tools: ["drainer", "pot", "large high sided skillet"],
            prepTimeInMins: 10,
            cookTimeInMins: 25,
            nutrition: undefined,
            author: {
              connect: {
                id: user.id,
              },
            },
            servings: 4,
            difficulty: 2,
            tags: {
              connect: [{ id: tag1.id }, { id: tag2.id }],
            },
          };
        }
        data2 = {
          name: "Search Test Recipe 2: Eggs and other things quiche",
          ingredients: [
            "extra-virgin olive oil: 2 tablespoons",
            "sliced fresh mixed wild mushrooms such as cremini, shiitake, button and/or oyster mushrooms: 8 ounces",
            "thinly sliced sweet onion: 1.5 cups",
            "thinly sliced garlic: 1 tablespoon",
            "fresh baby spinach (about 8 cups), coarsely chopped: 5 ounces",
            "large eggs: 6",
            "whole milk:  ¼ cup",
            "half-and-half:  ¼ cup",
            "Dijon mustard: 1 tablespoon",
            "fresh thyme leaves, plus more for garnish: 1 tablespoon",
            "salt: ¼ teaspoon",
            "ground pepper :¼ teaspoon",
            "shredded Gruyère cheese: 1.5 cups",
          ],

          procedure: [
            "Preheat oven to 375 degrees F. Coat a 9-inch pie pan with cooking spray; set aside.",
            "Heat oil in a large nonstick skillet over medium-high heat; swirl to coat the pan. Add mushrooms; cook, stirring occasionally, until browned and tender, about 8 minutes. Add onion and garlic; cook, stirring often, until softened and tender, about 5 minutes. Add spinach; cook, tossing constantly, until wilted, 1 to 2 minutes. Remove from heat.",

            "Whisk eggs, milk, half-and-half, mustard, thyme, salt and pepper in a medium bowl. Fold in the mushroom mixture and cheese. Spoon into the prepared pie pan. Bake until set and golden brown, about 30 minutes. Let stand for 10 minutes; slice. Garnish with thyme and serve.",
          ],

          tools: ["oven", "pie pan", "skillet"],
          prepTimeInMins: 20,
          cookTimeInMins: 45,
          difficulty: 5,
          author: {
            connect: {
              id: user.id,
            },
          },
          servings: 6,
          tags: {
            connect: [{ id: tag1.id }, { id: tag2.id }],
          },
        };
        const recipe1 = await recipeDAO
          .create(data1)
          .then((res) => (recipe1ID = res.id));
        const recipe2 = await recipeDAO
          .create(data2)
          .then((res) => (recipe2ID = res.id));
      });
  }, 30000);

  afterAll(async () => {
    await prisma.recipe.delete({
      where: {
        id: recipe1ID.valueOf(),
      },
    });
    await prisma.recipe.delete({
      where: {
        id: recipe2ID.valueOf(),
      },
    });
    await prisma.tag.delete({
      where: {
        id: tag1.id,
      },
    });
    await prisma.tag.delete({
      where: {
        id: tag2.id,
      },
    });
    if (testUser1) {
      await userDAO.delete(testUser1.id);
    }

    await prisma.$disconnect();
  });

  test("test search_gpt with no parameters", async () => {
    const result = await recipeDAO.searchGPT(undefined, undefined);
    expect(result).toBeUndefined();
  });

  test("test search with query only", async () => {
    const result = await recipeDAO.searchGPT(undefined, "chicken dinner dish");
    if (result) {
      expect(result.data.length).toBeGreaterThanOrEqual(1);
    }
  });

  test("test case insensitive search with query only", async () => {
    const query = "chICKEN for DinnER";
    const result = await recipeDAO.searchGPT(undefined, query);
    if (result) {
      expect(result.data.length).toBeGreaterThanOrEqual(1);
    }
  });

  test("test all characters query", async () => {
    const query = "#@($&#@(*$&(";
    const result = await recipeDAO.searchGPT(undefined, query);
    if (result) {
      expect(result.data.length).toEqual(0);
    }
  });

  test("test query longer than 20 characters", async () => {
    const query = "#@($&#@(*$&(";
    const result = await recipeDAO.searchGPT(undefined, query);
    if (result) {
      expect(result.data.length).toEqual(0);
    }
  });

  describe("Test search with UP", () => {
    let userPref: userPreferences;
    let testUser: User;
    beforeAll(async () => {
      const testEmail = "searchgpt_test_email@jhu.edu";
      testUser = await prisma.user.upsert({
        where: { email: testEmail },
        update: {},
        create: {
          email: testEmail,
          username: "search_gpt_testing_username",
          password: "search_test",
          image: "google.come",
          googleId: "gptt1112",
          verified: true,
        },
      });
      userPref = await userPrefDAO.create({
        difficulty: 3,
        ingredientsExcluded: ["pepper", "flour"],
        timeInMins: 30,
        userId: testUser.id,
      });
    });
    afterAll(async () => {
      await userDAO.delete(testUser.id);
    });

    test("test search with query and UP ingredientsExcluded, timeInMins, difficulty", async () => {
      const query = "Recipe";
      const result = await recipeDAO.searchGPT(testUser.id, query);
      if (result) {
        result.data.forEach((recipe) => {
          expect(recipe.prepTimeInMins).toBeLessThanOrEqual(
            userPref.timeInMins
          );
          expect(recipe.difficulty).toBeLessThanOrEqual(userPref.difficulty);
          expect(recipe.ingredientString).not.toContain(
            userPref.ingredientsExcluded[0]
          );
          expect(recipe.ingredientString).not.toContain(
            userPref.ingredientsExcluded[1]
          );
        });
      }
    });

    test("test search with query and UP cuisine tags", async () => {
      const query = "Recipe";
      userPref = await userPrefDAO.update(testUser.id, {
        userId: testUser.id,
        difficulty: 5,
        ingredientsExcluded: [],
        timeInMins: 2222222,
        cuisineTags: [tag1, tag2],
      });
      const result = await recipeDAO.searchGPT(testUser.id, query);
      if (result) {
        result.data.forEach((recipe) => {
          const tagNames = recipe.tags.map((tag) => tag.name);
          expect(tagNames).toContain(tag1.name);
          expect(tagNames).toContain(tag2.name);
        });
      }
    });

    test("test search with query and keto, halal, and kosher", async () => {
      const query = "Recipe";
      userPref = await userPrefDAO.update(testUser.id, {
        userId: testUser.id,
        cuisineTags: [],
        vegan: false,
        vegetarian: false,
        keto: true,
        halal: true,
        kosher: true,
      });
      const result = await recipeDAO.searchGPT(testUser.id, query);
      if (result) {
        result.data.forEach((recipe) => {
          const tagNames = recipe.tags.map((tag) => tag.name);
          expect(tagNames).toContain("kosher");
          expect(tagNames).toContain("halal");
          expect(tagNames).toContain("keto");
        });
      }
    });

    test("test search with query and vegetarian and vegan", async () => {
      const query = "Recipe";
      userPref = await userPrefDAO.update(testUser.id, {
        userId: testUser.id,
        cuisineTags: [],
        vegan: true,
        vegetarian: true,
        keto: false,
        halal: false,
        kosher: false,
      });
      const result = await recipeDAO.searchGPT(testUser.id, query);
      if (result) {
        result.data.forEach((recipe) => {
          expect(recipe.name).toContain(query);
          const tagNames = recipe.tags.map((tag) => tag.name);
          expect(tagNames).toContain("vegetarian");
          expect(tagNames).toContain("vegan");
        });
      }
    });

    test("test search with query and nonDairy and glutenFree", async () => {
      const query = "Recipe";
      userPref = await userPrefDAO.update(testUser.id, {
        userId: testUser.id,
        cuisineTags: [],
        vegan: false,
        vegetarian: false,
        keto: false,
        halal: false,
        kosher: false,
        nonDairy: true,
        glutenFree: true,
      });
      const result = await recipeDAO.searchGPT(testUser.id, query);
      if (result) {
        result.data.forEach((recipe) => {
          expect(recipe.name).toContain(query);
          const tagNames = recipe.tags.map((tag) => tag.name);
          expect(tagNames).toContain(
            "Gluten-Free" || "Gluten Free" || "No Gluten"
          );
          expect(tagNames).toContain(
            "Dairy-Free" || "Dairy Free" || "No dairy" || "non-dairy"
          );
        });
      }
    }, 20000);
  });
});
