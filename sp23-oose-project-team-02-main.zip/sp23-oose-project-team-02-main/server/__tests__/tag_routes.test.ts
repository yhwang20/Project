import request from "supertest";
const app = require("../src/index");
import ApiError from "../src/model/ApiError";
import TagDAO from "../src/data/TagDao";
import { prismaMock } from "../singleton";
import { PrismaClient, Tag } from "@prisma/client";
const prisma = new PrismaClient();
const tagDAO = new TagDAO();

describe("Tag routes", () => {
  let testTag: Tag;
  beforeAll(async () => {
    const testTagName = "testing_tag_routes_tag";
    testTag = await prisma.tag.upsert({
      where: { name: testTagName },
      update: {},
      create: { name: testTagName },
    });
  });

  afterAll(async () => {
    jest.resetAllMocks();
    await tagDAO.delete(testTag.id);
    await prismaMock.$disconnect();
  });

  describe("POST /tag", () => {
    test("Create tag route", async () => {
      try {
        const newTagName = "test_create_tag_route";

        const response = await request(app)
          .post("/tag")
          .send({ name: newTagName })
          .expect(200);

        expect(response.body.data.name).toEqual(newTagName);
        expect(response.body.data.id).toBeDefined();
        await tagDAO.delete(response.body.data.id);
      } catch (err) {
        console.log(err);
        return false;
      }
    });

    test("Create tag route error handling", async () => {
      expect(
        request(app).post("./tag").send({ name: testTag.name })
      ).rejects.toThrow(new ApiError(400, "Tag name already exists!"));
    });
  });

  describe("GET /tag", () => {
    test("Get tag by name route", async () => {
      const response = await request(app)
        .get(`/tag/${testTag.name}`)
        .expect(200);
      expect(response.body.data.name).toEqual(testTag.name);
    });

    test("Test GET /name error handling", async () => {
      const invalidName = "43985743098570394857@#(*$&(#*$&(#*@";
      const response = await request(app).get(`tag/${invalidName}`).expect(404);

      expect(response.body.message).toEqual("No such tag name exists!");
    });

    test("Get all tag route", async () => {
      const response = await request(app).get("/tag").expect(200);
      expect(response.body.message).toEqual(
        `Successfully retrieved ${response.body.data.length} tags!`
      );
    });

    test("Test GET / error handling", async () => {
      const mockError = new ApiError(500, "Test Error");

      jest.spyOn(prisma.tag, "findMany").mockRejectedValueOnce(mockError);

      const response = await request(app).get("/tag").expect(500);

      expect(response.body.message).toEqual(mockError.message);
    });
  });

  describe("PUT /tag", () => {
    test("Update tag name route", async () => {
      const updatedName = "updatedTestTagForTagRouteTesting";
      const response = await request(app)
        .put(`/tag/${testTag.name}`)
        .send({ newName: updatedName })
        .expect(200);
      expect(response.body.data.name).toEqual(updatedName);
    });

    test("Try to update tag name with existing tag name", async () => {
      const toBeExistingName = "update_tag_with_existing_name_test_tag";
      const toUpdateName = "to_be_updated_test_tag_293487";
      const toBeUpdatedTag = await prisma.tag.upsert({
        where: { name: toUpdateName },
        update: {},
        create: { name: toUpdateName },
      });
      await prisma.tag
        .upsert({
          where: { name: toBeExistingName },
          update: {},
          create: { name: toBeExistingName },
        })
        .then(async (res) => {
          expect(
            request(app)
              .put(`/tag/${toBeUpdatedTag.name}`)
              .send({ newName: res.name })
          ).rejects.toThrow(new ApiError(400, "Tag name already exists!"));
        });
    });
  });

  describe("DELETE /tag", () => {
    test("Delete tag route", async () => {
      const deleteTagName = "test_delete_tag_route";
      const deleteTag = await prisma.tag.upsert({
        where: { name: deleteTagName },
        update: {},
        create: { name: deleteTagName },
      });
      const response = await request(app)
        .delete(`/tag/${deleteTagName}`)
        .expect(200);
      expect(response.body.message).toEqual(`Successfully deleted tag!`);
      const foundTag = await tagDAO.readOne(deleteTagName);
      expect(foundTag).toBeNull();
    });

    test("Try to delete non-existent tag", async () => {
      expect(
        request(app).delete(`/tag/@#_$)(*#@_)($#)40*$)#_$Fdsjlfjsf#$(@`)
      ).rejects.toThrow(new ApiError(400, "No tag with given ID!"));
    });
  });
});
