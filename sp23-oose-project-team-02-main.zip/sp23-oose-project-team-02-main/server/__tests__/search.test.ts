import RecipeDAO from "../src/data/RecipeDao";
import UserDAO from "../src/data/UserDao";
import TagDAO from "../src/data/TagDao";

const recipeDAO = new RecipeDAO();
const userDAO = new UserDAO();
const tagDAO = new TagDAO();
import ApiError from "../src/model/ApiError";
import { Prisma, PrismaClient, Tag, User, userPreferences} from "@prisma/client";
const prisma = new PrismaClient();
let testUser1: void | User;
let recipe1ID: String;
let recipe2ID: String;
let data1: Prisma.RecipeCreateInput;
let data2: Prisma.RecipeCreateInput;
let tag1: Tag;
let tag2: Tag;
let kosher_tag: Tag;
let dairy_tag: Tag;
describe("Test recipeDAO search method", () => {

    beforeAll(async()=> {
        kosher_tag = await prisma.tag.upsert({
            where: {
                name: "kosher"
            }, update: {},
            create: {
                name: "kosher"
            }
        });
        dairy_tag = await prisma.tag.upsert({
            where: {
                name: "dairy"
            }, update: {},
            create: {
                name: "dairy"
            }
        })
      const test_email = "search_testing_email@jh.edu";
      const tag1_name = "search_testing_tag_1"
      const tag2_name = "search_testing_tag_2"
      tag1 = await prisma.tag.upsert({
        where: {
            name: tag1_name
        }, update: {},
        create: {
          name: tag1_name
        }
      })
      tag2 = await prisma.tag.upsert({
        where: {
            name: tag2_name
        }, update: {},
        create: {
          name: tag2_name
        }
      });
      testUser1 = await prisma.user.upsert({
        where: {
          email: test_email
        },update: {},
        create: {
            email: test_email,
            username: "search_testing_user",
            password: "search_test",
            image: "google.come",
            googleId: "tests4452",
            verified: true,
        }
      }).then(async(user)=> {
       if (user) {
         data1 =  {
           name: "Search Test Recipe 1: Chicken, Spinach, Parmesan Recipe",
           ingredients: [
             "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
             "extra-virgin olive oil: 2 tablespoons",
             "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
             "salt: ½ teaspoon",
             "ground pepper: ¼ teaspoon",
             "garlic, minced: 4 cloves",
             "dry white wine: ½ cup",
             "Juice and zest of lemon: 1",
             "chopped fresh spinach: 10 cups ",
             "grated Parmesan cheese, divided: 4 tablespoons",
           ],
           procedure: ["Cook pasta according to package directions. Drain and set aside.", "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer."
             ,"Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan."
           ],
           tools:          ["drainer", "pot", "large high sided skillet"],
           prepTimeInMins: 10, 
           cookTimeInMins: 25,
           nutrition: undefined,
           author: {
             connect: {
               id: user.id,
             },
           },
           servings: 4,
           difficulty: 2,   
           tags: {
            connect: {
              id: tag1.id
            }
           }
           
         };
         data2 = {
          name: "Search Test Recipe 2: Eggs and other things quiche",
          ingredients: [
              "extra-virgin olive oil: 2 tablespoons",
              "sliced fresh mixed wild mushrooms such as cremini, shiitake, button and/or oyster mushrooms: 8 ounces",
              "thinly sliced sweet onion: 1.5 cups",
              "thinly sliced garlic: 1 tablespoon",
              "fresh baby spinach (about 8 cups), coarsely chopped: 5 ounces",
              "large eggs: 6",
              "whole milk:  ¼ cup",
              "half-and-half:  ¼ cup",
               "Dijon mustard: 1 tablespoon",
               "fresh thyme leaves, plus more for garnish: 1 tablespoon",
               "salt: ¼ teaspoon",
               "ground pepper :¼ teaspoon",
               "shredded Gruyère cheese: 1.5 cups"]
              
      
        ,
          procedure:  ["Preheat oven to 375 degrees F. Coat a 9-inch pie pan with cooking spray; set aside.",
          "Heat oil in a large nonstick skillet over medium-high heat; swirl to coat the pan. Add mushrooms; cook, stirring occasionally, until browned and tender, about 8 minutes. Add onion and garlic; cook, stirring often, until softened and tender, about 5 minutes. Add spinach; cook, tossing constantly, until wilted, 1 to 2 minutes. Remove from heat.",
          
           "Whisk eggs, milk, half-and-half, mustard, thyme, salt and pepper in a medium bowl. Fold in the mushroom mixture and cheese. Spoon into the prepared pie pan. Bake until set and golden brown, about 30 minutes. Let stand for 10 minutes; slice. Garnish with thyme and serve."],
          
          tools:          ["oven", "pie pan", "skillet"],
          prepTimeInMins: 20, 
          cookTimeInMins: 45,
          difficulty: 5,   
          author: {
            connect: {
              id: user.id,
            },
          },  
          servings: 6,
          tags: {
              connect: [  {id: tag2.id}]
           }
        }
           await prisma.recipe.deleteMany({where: {name: data1.name}});
           await prisma.recipe.deleteMany({where: {name: data2.name}});
           const recipe1 = await recipeDAO.create(data1).then((res)=> recipe1ID = res.id);
           await recipeDAO.create(data2).then((res)=> recipe2ID = res.id);
          
        }
       })
      },  30000);


  afterAll(async () => {
    await recipeDAO.delete(recipe1ID.valueOf());
    await recipeDAO.delete(recipe2ID.valueOf());



      await prisma.tag.delete({
      where: {
        id: tag1.id
      }
    });
    await prisma.tag.delete({
      where: {
        id: tag2.id
      }
    })
    if (testUser1) {
      await userDAO.delete(testUser1.id);
    }
    
   
    await prisma.$disconnect()
  });

  test('test search with no parameters', async () => {
    const all = await recipeDAO.readAll();
    const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);

    expect(result.length).toBe(all.length);
    

  });

   
    test('test search by query only', async () => {
      const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, data1.name);

      expect(result.length).toBeGreaterThanOrEqual(1);
      result.forEach((recipe)=> {
        expect(recipe.name).toContain(data1.name);
      })

    });

    test('test case insensitive search by query only', async () => {
      const query  = 'Search Test RECIPE 1: ChICken, Spinach, ParMESan rECipe';
      const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, query);

      expect(result.length).toBeGreaterThanOrEqual(1);
      result.forEach((recipe)=> {
        expect(recipe.name).toEqual(data1.name);
      })

    });

    test('test nonexistent query', async () => {
      const query = "zzzzzzzzzzzzzzzzzzz29874389237498710";
      
      const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, query);
      expect(result.length).toBe(0);
     

    });

    test('test that empty query returns all', async () => {
      const query = "";  
      const all = await recipeDAO.readAll();
      const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined,  undefined, query);
      expect(result.length).toEqual(all.length);
    }, 10000);

   
    test('test search with inclusionary tag', async () => {
        const query = "Spinach";
        
        const result = await recipeDAO.search(undefined, [tag1.name], undefined, undefined, undefined, undefined, undefined, undefined, undefined, query);
       
      
        expect(result.length).toBeGreaterThanOrEqual(1);
        result.forEach((recipe)=> {
          expect(recipe.name).toContain(query);
          expect(recipe.tags).toContainEqual(tag1);
        })
        
  
      });

    test('test search with multiple inclusionary tags', async () => {
        // @ts-ignore
        await recipeDAO.update(recipe2ID.valueOf(), {tags: [tag2, dairy_tag, kosher_tag]})
        const includedTagsList = ["dairy", tag2.name, "kosher"];
        const result = await recipeDAO.search(undefined, includedTagsList, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
        expect(result.length).toBeGreaterThanOrEqual(1);
        result.forEach((recipe)=> {
            const tagNames = recipe.tags.map((tag)=> tag.name);
            expect(tagNames).toContain(tag2.name);
            expect(tagNames).toContain("dairy");
            expect(tagNames).toContain("kosher");
        })
    });

      test('test search with tag but no query', async () => {
       
        const result = await recipeDAO.search(undefined, [tag1.name], undefined, undefined, undefined, undefined, undefined, undefined, undefined);

        expect(result.length).toBe(1);
        expect(result[0].name).toEqual(data1.name);
        expect(result[0].tags).toContainEqual(tag1);
  
      });

      test('test search when recipe doesnt have tag', async () => {
        const query = "Spinach";
        const result = await recipeDAO.search(undefined, ["alsdkjfaeijfs2432432"], undefined, undefined, undefined, undefined, undefined, undefined, undefined, query);

        expect(result.length).toBe(0);
  
      });

      

    test('test search with exclusionary tag', async () => {
        const query = data1.name;
        
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, [tag1.name], undefined, undefined, undefined, undefined, query);
      
        result.forEach((recipe)=> {
          expect(recipe.tags).not.toContainEqual(tag1);
        })
  
      });

    test('test search with multiple exclusionary tags', async () => {
        const query = data1.name;

        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, [tag1.name, tag2.name, "kosher"], undefined, undefined, undefined, undefined, query);

        result.forEach((recipe)=> {
            const tagNames = recipe.tags.map((tag)=> tag.name);
            expect(tagNames).not.toContain(tag1.name);
            expect(tagNames).not.toContain(tag2.name);
            expect(tagNames).not.toContain("kosher");
        })
    });

      test('test search with exclusionary tag but no query', async () => {
        const allRecipes = await recipeDAO.readAll();
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, [tag2.name], undefined, undefined, undefined, undefined);

        expect(result.length).toBe(allRecipes.length - 1);
        result.forEach((recipe)=> {
              const tagNames = recipe.tags.map((tag)=> tag.name);
              expect(tagNames).not.toContain(tag2.name);
        })
       
  
      });

 
      test('test search with ingredients', async () => {
        const ingreds = ["boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces"];
        const result = await recipeDAO.search(undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, undefined);
       
      
        expect(result.length).toBeGreaterThanOrEqual(1);
        result.forEach((recipe)=> {
          expect(recipe.ingredientString).toContain(ingreds[0].trim().replace(/\s+/g, ''));
        })
        
       

      });

      test('test search with substrings of ingredients', async () => {
       
        const ingreds = ["salt", "pepper"]
        const result = await recipeDAO.search(undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, undefined);
       
        result.forEach((recipe)=> {
          expect(recipe.ingredientString).toContain(ingreds[0]);
          expect(recipe.ingredientString).toContain(ingreds[1]);
  
        })
      
        
      });

    test('test search with multi word ingredients', async () => {

        const ingreds = ["salt", "pepper"]
        const result = await recipeDAO.search(undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, undefined);

        result.forEach((recipe)=> {
            expect(recipe.ingredientString).toContain(ingreds[0]);
            expect(recipe.ingredientString).toContain(ingreds[1]);

        })


    });

      test('test search with ingredients that returns multiple', async () => {
       
        const ingreds = ["ground pepper"]
        const result = await recipeDAO.search(undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, undefined);

        expect(result.length).toBeGreaterThanOrEqual(2);
       

      });

      test('test search with ingredients that no recipe has returns nothing', async () => {
       
        const ingreds = ["magic sprinkles made of alsajf;lasjfljweofj;lsaj"]
        const result = await recipeDAO.search(undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, undefined);
        
      
        expect(result.length).toBe(0);
       

      });

    

      test('test search with excluded ingredients preventing return', async () => {
        const query = data1.name;
        const ingreds = ["chopped fresh spinach"]
        const result = await recipeDAO.search(undefined, undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, query);
       
      
        expect(result.length).toBe(0);
      

      });

      test('test search with excluding substrings of ingredients', async () => {

        const ingreds = ["salt", "pepper"]
        const result = await recipeDAO.search(undefined, undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined, undefined);
       
      
        expect(result.length).toBeGreaterThan(0);

          result.forEach((recipe)=> {
              expect(recipe.ingredientString).not.toContain(ingreds[0]);
              expect(recipe.ingredientString).not.toContain(ingreds[1]);

          })
      });


      test('test search with excluding ingredients that no recipe has returns everything', async () => {
        const allRecipes = await recipeDAO.readAll();
        const ingreds = ["magic sprinkles made of alsajf;lasjfljweofj;lsaj"]
        const result = await recipeDAO.search(undefined, undefined, undefined, ingreds, undefined, undefined, undefined, undefined, undefined);
        
      
        expect(result.length).toEqual(allRecipes.length);
       

      });
      

      test('test search with 0 prep time returns nothing', async () => {
        const prepTime = 0;
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, prepTime, undefined, undefined, undefined);
        expect(result.length).toEqual(0);
      });

      test('test search with prep time', async () => {
        const prepTime = 35;
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, prepTime, undefined, undefined, undefined);
        result.forEach((recipe)=> {
          expect(recipe.prepTimeInMins).toBeLessThanOrEqual(prepTime);
        })
      });

      test('test search with very high prep time returns all recipes', async () => {
        const prepTime = 214748364;
        const allRecipes = await recipeDAO.readAll();
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, prepTime, undefined, undefined, undefined);
        expect(result.length).toEqual(allRecipes.length);
      }, 10000);

      // Cook time tests
      test('test search with cook time', async () => {
        const cookTime = 35;
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, cookTime, undefined, undefined);
        result.forEach((recipe)=> {
          expect(recipe.cookTimeInMins).toBeLessThanOrEqual(cookTime);
        })
      });

      test('test search with very high cook time returns all recipes', async () => {
        const cookTime = 214748364;
        const allRecipes = await recipeDAO.readAll();
        const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, cookTime, undefined, undefined);
        expect(result.length).toEqual(allRecipes.length);
      }, 10000);


      describe("Test rating filtering", ()=> {
          test('test search with 0 rating returns all recipes', async () => {
              const rating = 0;
              const allRecipes = await recipeDAO.readAll();
              const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, rating, undefined);
              expect(result.length).toEqual(allRecipes.length);
          });

          test('test search with rating', async () => {
              const rating = 4;
              const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, rating, undefined);
              result.forEach((recipe)=> {
                  expect(recipe.avgRating).toBeGreaterThanOrEqual(rating);
              })
          });

          test('test search with rating higher than 5 returns nothing', async () => {
              const rating = 6;

              const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, rating, undefined);
              expect(result.length).toEqual(0);
          });
      });


     describe("Test maxDifficulty filtering", ()=> {
         test('test search with difficulty < 0 returns nothing', async () => {
             const difficulty = -1;
             const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, difficulty,undefined);
             expect(result.length).toEqual(0);
         });

         test('test search with difficulty', async () => {
             const difficulty = 3;
             const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, difficulty, undefined);
             result.forEach((recipe)=> {
                 expect(recipe.difficulty).toBeLessThanOrEqual(difficulty);
             })
         });

         test('test search with difficulty of 5 returns everything', async () => {
             const difficulty = 5;
             const allRecipes = await recipeDAO.readAll();
             const result = await recipeDAO.search(undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined, difficulty, undefined);
             expect(result.length).toEqual(allRecipes.length);
         });

     })




    describe("Testing search incoroporating userPreferences", ()=> {

       let testUser2: User;
       let prefData: Prisma.userPreferencesCreateInput;
       let userPref: userPreferences;
       beforeAll(async () => {
           const test_email = "user_pref_search_email@jh.edu";
           testUser2 = await prisma.user.upsert({
               where: {
                  email: test_email
               }, update: {},
               create: {
                   email: test_email,
                   username: "userpreferences_search_testing",
                   password: "search_test",
                   image: "google.come",
                   googleId: "prefs103",
                   verified: true,
               }
           })

           prefData = {
               difficulty: 2,
               ingredientsExcluded: undefined,
               timeInMins: 100,
               user: {
                   connect: {
                       id: testUser2.id
                   }
               },
               cuisineTags: undefined,
           }
           userPref = await prisma.userPreferences.create({
               data: prefData
           });
           testUser2 = await prisma.user.update({
               where: {
                   id: testUser2.id
               },

               data: {
                   userPreferences: {
                       connect: {id: userPref.id}
                   }
               }
           });
       }, 30000);

       afterAll(async () => {
           await prisma.user.delete({
               where: {
                   id: testUser2.id
               }
           })
       });

       test("Test user pref with ingredients excluded", async () => {

           userPref = await prisma.userPreferences.update({
               where: { id: userPref.id },
               data: {
                   difficulty: 5,
                   ingredientsExcluded: ["Dijon mustard"]
               }
           });
           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined);
           expect(result.length).toBeGreaterThanOrEqual(1);
           result.forEach((res) => {
               expect(res.ingredientString).toEqual(expect.not.stringContaining(userPref.ingredientsExcluded[0]));
           });

       });

       test("Test user pref with timeInMins", async () => {

           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   timeInMins: 40,
                   ingredientsExcluded: []
               }
           });


           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
           expect(result.length).toBeGreaterThanOrEqual(1);
           result.forEach((res) => {
               expect(res.prepTimeInMins).toBeLessThanOrEqual(userPref.timeInMins);

           });

       });

       test("Test user pref with vegan", async () => {
           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   timeInMins: 3000,
                   vegan: true
               }
           });
           const vegan_tag = await tagDAO.readOne("vegan");
           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
           if(!vegan_tag) {
               expect(result.length).toEqual(0);
           } else {
               result.forEach((recipe) => {
                   const tagNames = (recipe.tags).map((tag)=> tag.name);
                   expect(tagNames).toContain("vegan")

               });
           }
       });

       test("Test user pref with vegetarian", async () => {
           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   vegetarian: true,
                   vegan: false
               }
           });
           const vegetarian_tag = await tagDAO.readOne("vegetarian");
           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
           if(!vegetarian_tag) {
               expect(result.length).toEqual(0);
           } else {
               result.forEach((recipe) => {
                   const tagNames = (recipe.tags).map((tag)=> tag.name);
                   expect(tagNames).toContain("vegetarian")

               });
           }
       });

       test("Test user pref with kosher", async () => {
           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   kosher: true,
                   vegetarian: false
               }
           });
           const kosher_tag = await tagDAO.readOne("kosher");
           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
           if(!kosher_tag) {
               expect(result.length).toEqual(0);
           } else {
               result.forEach((recipe) => {
                   const tagNames = (recipe.tags).map((tag)=> tag.name);
                   expect(tagNames).toContain("kosher")

               });
           }
       });

       test("Test user pref with halal", async () => {
           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   kosher: false,
                   halal: true
               }
           });
           const halal_tag = await tagDAO.readOne("halal");
           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
           if(!halal_tag) {
               expect(result.length).toEqual(0);
           } else {
               result.forEach((recipe) => {
                   const tagNames = (recipe.tags).map((tag)=> tag.name);
                   expect(tagNames).toContain("halal")

               });
           }
       });

       test("Test user pref with keto", async () => {
           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   halal: false,
                   keto: true
               }
           });
           const keto_tag = await tagDAO.readOne("keto");
           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
           if(!keto_tag) {
               expect(result.length).toEqual(0);
           } else {
               result.forEach((recipe) => {
                   const tagNames = (recipe.tags).map((tag)=> tag.name);
                   expect(tagNames).toContain("keto")

               });
           }
       });

        test("Test user pref with nonDairy", async () => {
            userPref = await prisma.userPreferences.update({
                where: {
                    id: userPref.id
                },
                data: {
                    keto: false,
                    kosher: false,
                    halal: false,
                    nonDairy: true,
                }
            });
            const non_dairy_tag = await tagDAO.readOne("Dairy-Free");
            const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
            if(!non_dairy_tag) {
                expect(result.length).toEqual(0);
            } else {
                result.forEach((recipe) => {
                    const tagNames = (recipe.tags).map((tag)=> tag.name);
                    expect(tagNames).toContain("Dairy-Free")

                });
            }
        });

        test("Test user pref with glutenFree", async () => {
            userPref = await prisma.userPreferences.update({
                where: {
                    id: userPref.id
                },
                data: {
                    keto: false,
                    kosher: false,
                    halal: false,
                    nonDairy: false,
                    glutenFree: true
                }
            });
            const non_dairy_tag = await tagDAO.readOne("Gluten-Free");
            const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);
            if(!non_dairy_tag) {
                expect(result.length).toEqual(0);
            } else {
                result.forEach((recipe) => {
                    const tagNames = (recipe.tags).map((tag)=> tag.name);
                    expect(tagNames).toContain("Gluten-Free")

                });
            }
        });

       test("Test user pref with multiple diets", async () => {
           userPref = await prisma.userPreferences.update({
               where: {
                   id: userPref.id
               },
               data: {
                   vegetarian: true,
                   kosher: true,
                   vegan: true,
                   user: {connect: {id: testUser2.id}},
                   userId: testUser2.id
               }
           });
           await userDAO.update(testUser2.id, {userPreferences: {connect: {id: userPref.id}}})
           const vegan_tag = await prisma.tag.upsert({where: {name: "vegan"}, create: {name: "vegan"}, update: {}})
           const vegetarian_tag = await prisma.tag.upsert({where: {name: "vegetarian"}, create: {name: "vegetarian"}, update: {}})
           const kosher_tag = await prisma.tag.upsert({where: {name: "kosher"}, create: {name: "kosher"}, update: {}})

           // @ts-ignore
           await recipeDAO.update(recipe2ID.valueOf(), {tags: [vegetarian_tag, vegan_tag, kosher_tag]})


           const result = await recipeDAO.search(testUser2.id, undefined, undefined, undefined, undefined, undefined, undefined, undefined, undefined);

               expect(result.length).toBeGreaterThan(0);
               result.forEach((recipe) => {
                   const tagNames = (recipe.tags).map((tag)=> tag.name);
                   expect(tagNames).toContain("vegan");
                   expect(tagNames).toContain("dairy");
                   expect(tagNames).toContain("kosher");

               });

       });

   });
  
   
});








