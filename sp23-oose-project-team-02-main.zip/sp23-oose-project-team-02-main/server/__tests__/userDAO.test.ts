import TagDAO from "../src/data/TagDao";
import RecipeDAO from "../src/data/RecipeDao";
import UserDAO from "../src/data/UserDao";
import ApiError from "../src/model/ApiError";
import { User, Role, userPreferences, Tag, Recipe } from "@prisma/client";
import prisma from "../prisma/client";
import { v4 as uuidv4 } from "uuid";

const userDAO = new UserDAO();
const tagDAO = new TagDAO();
const recipeDAO = new RecipeDAO();
let id: User["id"];
describe("Test UserDAO", () => {
  beforeEach(async () => {
    await prisma.user.deleteMany({ where: { email: "yhwang20@jh.edu" } });
  });
  afterEach(async () => {
    await prisma.user.deleteMany({ where: { email: "yhwang20@jh.edu" } });
    await prisma.userPreferences.deleteMany({ where: { userId: id } });
  });

  describe("Creating User", () => {
    it("test create() with valid info", async () => {
      const data = {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      };
      const user = await userDAO.create(data);
      id = user.id;
      expect(user.email).toEqual(data.email);
      expect(user.username).toEqual(data.username);
      expect(user.userPreferencesId).toBeDefined();
    });
    it("test create() with invalid email", async () => {
      const data = {
        email: "yhwang20",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      };
      await expect(userDAO.create(data)).rejects.toThrow(
        new ApiError(400, "Invalid email address")
      );
    });
    it("test create() with invalid password", async () => {
      const data = {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      };
      await expect(userDAO.create(data)).rejects.toThrow(
        new ApiError(400, "Password must be at least 6 characters!")
      );
    });
    it("test create() with existing email", async () => {
      const data = {
        email: "scesar1@jhu.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      };
      await expect(userDAO.create(data)).rejects.toThrow(
        new ApiError(400, "User with this email already exists!")
      );
    });
  });
  describe("Reading Users", () => {
    it("test readAll()", async () => {
      const users = await userDAO.readAll("scesar1@jhu.edu");
      expect(users[0].username).toEqual("Shalom");
      expect(users[0].verified).toEqual(true);
      expect(users[0].role).toEqual(Role.BASIC);
    });
    it("test readAll() with no given email", async () => {
      const users = await userDAO.readAll(undefined);
      expect(users.length).toBeGreaterThan(1);
    });
    it("test read() given valid ID", async () => {
      const user = await userDAO.read("312d4457-3bfb-4276-8c3d-39e3e597597a");
      if (user) {
        expect(user.username).toEqual("irelandpikachu@gmail.com");
        expect(user.setupComplete).toEqual(true);
        expect(user.image).toEqual(
          "https://lh3.googleusercontent.com/a/AGNmyxYNpP32Jw7GBrMR1iZbhXgkoOch1vVwzgUo0FretOA=s96-c"
        );
      }
    });
    it("test read() given invalid ID", async () => {
      try {
        const user = await userDAO.read("pickle");
      } catch (err) {
        expect(err).toBeDefined();
      }
    });
    it("test readGoogle() given valid googleID", async () => {
      const user = await userDAO.readGoogle("111156757697122129693");
      if (user) {
        expect(user.username).toEqual("irelandpikachu@gmail.com");
        expect(user.setupComplete).toEqual(true);
        expect(user.image).toEqual(
          "https://lh3.googleusercontent.com/a/AGNmyxYNpP32Jw7GBrMR1iZbhXgkoOch1vVwzgUo0FretOA=s96-c"
        );
      }
    });
    it("test readGoogle() given invalid googleID", async () => {
      try {
        const user = await userDAO.readGoogle("HwangYusoo");
      } catch (err) {
        expect(err).toBeDefined();
      }
    });
  });
  describe("Deleting Users", () => {
    it("test delete() given valid id", async () => {
      const data = {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      };
      const user = await userDAO.create(data);
      id = user.id;
      const deletedUser = await userDAO.delete(user.id);
      expect(deletedUser.email).toEqual(user.email);
      expect(deletedUser.username).toEqual(user.username);
      expect(deletedUser.googleId).toEqual(user.googleId);
    });
    it("test delete() given invalid id", async () => {
      try {
        const data = {
          email: "yhwang20@jh.edu",
          username: "yuso500",
          password: "yuso100",
          image: "google.come",
          googleId: "yusoo0722",
          verified: true,
        };
        const user = await userDAO.create(data);
        id = user.id;
        const deletedUser = await userDAO.delete("pickle");
      } catch (err) {
        expect(err).toBeDefined();
      }
    });
  });
  describe("Updating Users", () => {
    it("test update() given valid id", async () => {
      const data = {
        email: "yhwang20@jh.edu",
        username: "yuso500",
        password: "yuso100",
        image: "google.come",
        googleId: "yusoo0722",
        verified: true,
      };
      const user = await userDAO.create(data);
      id = user.id;
      const newData = {
        username: "yungmoney",
        image: "yahoo.com",
        role: Role.AUTHOR,
      };
      const updatedUser = await userDAO.update(user.id, newData);
      expect(updatedUser.username).toEqual(newData.username);
      expect(updatedUser.image).toEqual(newData.image);
      expect(updatedUser.role).toEqual(newData.role);
    });
    it("test update() given invalid id", async () => {
      const newData = {
        username: "yungmoney",
        image: "yahoo.com",
        role: Role.AUTHOR,
      };
      await expect(userDAO.update("pickle", newData)).rejects.toThrowError();
    });
    it("test updateGoogle()", async () => {
      const ourUser = await prisma.user.create({
        data: {
          email: "yhwang20@jh.edu",
          username: "yuso500",
          password: "yuso100",
          image: "google.come",
          googleId: "yusoo0722",
          verified: true,
        },
      });
      id = ourUser.id;
      const updatedUser = await userDAO.updateGoogle(
        ourUser.email,
        "yungmoney",
        "doggy"
      );
      expect(updatedUser.googleId).toEqual("yungmoney");
      expect(updatedUser.image).toEqual("doggy");
    });
    it("test updateGoogle() given invalid id", async () => {
      await expect(
        userDAO.updateGoogle("hooligan", "pickle", "dog")
      ).rejects.toThrowError();
    });
  });
});
