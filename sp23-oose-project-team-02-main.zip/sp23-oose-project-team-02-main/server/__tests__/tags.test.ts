import TagDAO from "../src/data/TagDao";
import RecipeDAO from "../src/data/RecipeDao";
import ApiError from "../src/model/ApiError";
import { PrismaClient, Tag, User } from "@prisma/client";
const prisma = new PrismaClient();
const tagDAO = new TagDAO();
const recipeDAO = new RecipeDAO();

describe("Testing TagDAO", () => {
  afterAll(async () => {
    await prisma.$disconnect();
  });
  describe("Testing tag create", () => {
    afterAll(async () => {
      await prisma.tag.delete({
        where: {
          name: "toBeCreated",
        },
      });
    });
    test("should create a new tag", async () => {
      const data = { name: "toBeCreated" };
      const result = await tagDAO.create(data);
      const newTag = await prisma.tag.findUnique({
        where: {
          name: result.name,
        },
      });
      expect(newTag).toHaveProperty("name", data.name);
    });

    test("should throw ApiError when tag name already exists", async () => {
      const data = { name: "toBeCreated" };

      await expect(tagDAO.create(data)).rejects.toThrow(
        new ApiError(400, "This tag name already exists!")
      );
    });

    test("should throw ApiError when tag name is empty", async () => {
      const data = { name: "" };
      await expect(tagDAO.create(data)).rejects.toThrow(
        new ApiError(400, "Every recipe must have a non-empty name!")
      );
    });
  });

  describe("Test tag update", () => {
    let updatingTag: Tag;
    beforeAll(async () => {
      const updateTagName = "toBeUpdatedTag";
      updatingTag = await prisma.tag.upsert({
        where: { name: updateTagName },
        update: {},
        create: { name: updateTagName },
      });
    });

    afterAll(async () => {
      await prisma.tag.delete({
        where: {
          id: updatingTag.id,
        },
      });
    });
    test("should update tag with given id", async () => {
      const updatedTag = { name: "Updated" };
      const result = await tagDAO.update(updatingTag.id, updatedTag);
      expect(result.name).toEqual(updatedTag.name);
    });

    test("should throw ApiError when passed invalid id", async () => {
      const id = -29482;
      const data = { name: "Tag1" };
      await expect(tagDAO.update(id, data)).rejects.toThrow(
        new ApiError(
          404,
          "Failed to update recipe! This is likely due to an invalid ID."
        )
      );
    });

    test("should throw ApiError when empty string to update name to", async () => {
      const updatedTag = { name: "" };

      await expect(tagDAO.update(updatingTag.id, updatedTag)).rejects.toThrow(
        new ApiError(
          404,
          "Failed to update recipe! This is likely due to an invalid ID."
        )
      );
    });
  });

  describe("delete", () => {
    it("should delete a tag with a given ID", async () => {
      const createdTag = await prisma.tag.create({
        data: { name: "toBeDeleted" },
      });
      await tagDAO.delete(createdTag.id).then(async () => {
        const deletedTag = await tagDAO.read(createdTag.id);
        expect(deletedTag === null);
      });
    });

    it("should throw an error if the tag ID is invalid", async () => {
      expect(tagDAO.delete(-1)).rejects.toThrow(
        new ApiError(404, "There is no tag with the given ID!")
      );
    });
  });

  //edit to add recipes
  describe("readAll", () => {
    test("should return all tags with their recipes when there are tags in the database", async () => {
      const tag1Name = "testReadAllTag";
      const tag1 = await prisma.tag.upsert({
        where: { name: tag1Name },
        update: {},
        create: { name: tag1Name },
      });
      const compareTag = { name: tag1.name, id: tag1.id, recipes: [] };

      const tag = await prisma.tag.findUnique({ where: { name: tag1Name } });
      const result = await tagDAO.readAll();
      expect(result.length).toBeGreaterThan(0);
      expect(result).toContainEqual(compareTag);
    });
  });

  describe("test updateRecipes", () => {
    let recipe1ID: string;
    let testUser: User;
    let updateRecTag: Tag;
    beforeAll(async () => {
      const testEmail = "tag_dao_test_email@jhu.edu";
      testUser = await prisma.user.upsert({
        where: {
          email: testEmail,
        },
        update: {},
        create: {
          email: testEmail,
          username: "tag_dao_test_username",
          password: "jn101",
          image: "google.come",
          googleId: "tests0001",
          verified: true,
        },
      });
      const recipe1 = {
        name: "Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
        ingredients: [
          "8 ounces gluten-free penne pasta or whole-wheat penne pasta",
          "2 tablespoons extra-virgin olive oil",
          "1 pound boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces",
          "½ teaspoon salt",
          "¼ teaspoon ground pepper",
          "4 cloves garlic, minced",
          "½ cup dry white wine",
          "Juice and zest of 1 lemon",
          "10 cups chopped fresh spinach",
          "4 tablespoons grated Parmesan cheese, divided",
        ],
        procedure: [
          "Cook pasta according to package directions. Drain and set aside.",
          "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
          "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
        ],
        tools: ["drainer", "pot", "large high sided skillet"],
        prepTimeInMins: 10,
        cookTimeInMins: 25,
        nutrition: undefined,
        author: {
          connect: {
            id: testUser.id,
          },
        },
        servings: 4,
        difficulty: 4,
      };
      await recipeDAO.create(recipe1).then((res) => {
        recipe1ID = res.id;
      });
      const updateRecTagName = "update_rec_test_tag";
      updateRecTag = await prisma.tag.upsert({
        where: {
          name: updateRecTagName,
        },
        update: {},
        create: { name: updateRecTagName },
      });
    });
    afterAll(async () => {
      await prisma.tag.delete({ where: { name: updateRecTag.name } });
      await recipeDAO.delete(recipe1ID);
    });

    test("Add recipe to tag", async () => {
      try {
        const updated = await tagDAO.updateRecipes(
          updateRecTag.id,
          recipe1ID,
          true
        );
        expect(updated.recipes.length).toBe(1);
        expect(updated.recipes[0].id).toEqual(recipe1ID);
      } catch (e: any) {
        console.log(`${e.status}. Error: ${e.message}`);
      }
    });

    test("Remove recipe from tag", async () => {
      try {
        const updated = await tagDAO.updateRecipes(
          updateRecTag.id,
          recipe1ID,
          false
        );
        expect(updated.recipes.length).toBe(0);
      } catch (e: any) {
        console.log(`${e.status}. Error: ${e.message}`);
      }
    });

    test("Try to update recipes of non-existent tag", async () => {
      await expect(tagDAO.updateRecipes(-234, recipe1ID, true)).rejects.toThrow(
        "Invalid tag or recipe ID!"
      );
    });

    test("Try to update recipes with non-existent recipe", async () => {
      await expect(
        tagDAO.updateRecipes(updateRecTag.id, "#@(*$&#@(", true)
      ).rejects.toThrow("Invalid tag or recipe ID!");
    });
  });

  // Get tag by name
  describe("readOne", () => {
    let readOne_tag1: Tag;
    let readOne_tag2: Tag;
    beforeAll(async () => {
      const tag1_name = "readOne_test_tag1";
      const tag2_name = "readOne_test_tag2";
      readOne_tag1 = await prisma.tag.upsert({
        where: { name: tag1_name },
        update: {},
        create: { name: tag1_name },
      });
      readOne_tag2 = await prisma.tag.upsert({
        where: { name: tag2_name },
        update: {},
        create: { name: tag2_name },
      });
    });

    test("Read one existent tag by name", async () => {
      try {
        const tag = await tagDAO.readOne(readOne_tag1.name);

        if (tag) {
          expect(tag.name).toEqual(readOne_tag1.name);
          expect(tag.id).toEqual(readOne_tag1.id);
          expect(tag.recipes.length).toEqual(0);
        }
      } catch (e: any) {
        console.log(`${e.status}. Error: ${e.message}`);
      }
    });

    test("Read one nonexistent tag by name", async () => {
      try {
        const tag = await tagDAO.readOne("salfjla12sjdflkjs");
        expect(tag).toBeNull();
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Read one tag with empty name", async () => {
      await expect(tagDAO.readOne("")).rejects.toThrow(
        "Cannot pass empty query to readOne!"
      );
    });

    test("Read one tag with undefined name", async () => {
      await expect(tagDAO.readOne(undefined)).rejects.toThrow(
        "Cannot pass empty query to readOne!"
      );
    });
  });

  // Get tag by id
  describe("read", () => {
    test("Read one existent tag by id", async () => {
      try {
        const toBeReadName = "toBeReadTag";
        const toBeRead = await prisma.tag.upsert({
          where: { name: toBeReadName },
          update: {},
          create: { name: toBeReadName },
        });
        const tag = await tagDAO.read(toBeRead.id);

        if (tag) {
          expect(tag.name).toEqual(toBeRead.name);
          expect(tag.id).toEqual(toBeRead.id);
          expect(tag.recipes.length).toEqual(0);
        }
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Read one nonexistent tag by id", async () => {
      try {
        const tag = await tagDAO.read(-32);
        expect(tag).toBeNull();
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });
  });
});
