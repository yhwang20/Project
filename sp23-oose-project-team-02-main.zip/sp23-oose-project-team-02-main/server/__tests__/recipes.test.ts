import TagDAO from "../src/data/TagDao";
import RecipeDAO from "../src/data/RecipeDao";
import UserDAO from "../src/data/UserDao";
const tagDAO = new TagDAO();
const recipeDAO = new RecipeDAO();
const userDAO = new UserDAO();
import ApiError from "../src/model/ApiError";
import { Prisma, PrismaClient, Tag, User } from "@prisma/client";
const prisma = new PrismaClient();

let recipe1: Prisma.RecipeCreateInput;
let testUser: User;
describe("Test RecipeDAO", () => {
  beforeAll(async () => {
    const testEmail = "recipe_dao_test_email@jhu.edu";
    testUser = await prisma.user.upsert({
      where: {
        email: testEmail,
      },
      update: {},
      create: {
        email: testEmail,
        username: "recipe_dao_test_username",
        password: "jn101",
        image: "google.come",
        googleId: "tests0000",
        verified: true,
      },
    });
    recipe1 = {
      name: "Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
      ingredients: [
        "8 ounces gluten-free penne pasta or whole-wheat penne pasta",
        "2 tablespoons extra-virgin olive oil",
        "1 pound boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces",
        "½ teaspoon salt",
        "¼ teaspoon ground pepper",
        "4 cloves garlic, minced",
        "½ cup dry white wine",
        "Juice and zest of 1 lemon",
        "10 cups chopped fresh spinach",
        "4 tablespoons grated Parmesan cheese, divided",
      ],
      procedure: [
        "Cook pasta according to package directions. Drain and set aside.",
        "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
        "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
      ],
      tools: ["drainer", "pot", "large high sided skillet"],
      prepTimeInMins: 10,
      cookTimeInMins: 25,
      nutrition: undefined,
      author: {
        connect: {
          id: testUser.id,
        },
      },
      servings: 4,
      difficulty: 4,
    };
  });
  afterAll(async () => {
    await userDAO.delete(testUser.id);
    await prisma.$disconnect();
  }, 15000);
  describe("Creating recipes", () => {
    let newRecipeID: string;
    afterAll(async () => {
      await prisma.recipe.delete({
        where: {
          id: newRecipeID,
        },
      });
    });

    test("Creating a valid recipe", async () => {
      try {
        const data = recipe1;
        const newRecipe = await recipeDAO.create(data);
        newRecipeID = newRecipe.id.valueOf();
        await prisma.recipe.findFirstOrThrow({
          where: {
            name: newRecipe.name.valueOf(),
          },
        });
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    describe("Creating with missing required fields", () => {
      test("Creating recipe without name", async () => {
        try {
          const data = { ...recipe1 };
          data.name = "";

          await expect(recipeDAO.create(data)).rejects.toThrow(
            new ApiError(400, "Every recipe must have a non-empty name!")
          );
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });
      test("Creating recipe without ingredients", async () => {
        try {
          const data = { ...recipe1 };
          data.ingredients = [];
          await expect(recipeDAO.create(data)).rejects.toThrow(
            new ApiError(400, "Every recipe must have some ingredients!")
          );
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });
      test("Creating recipe without difficulty level", async () => {
        try {
          const data = { ...recipe1 };
          data.difficulty = 0;
          await expect(recipeDAO.create(data)).rejects.toThrow(
            new ApiError(400, "Every recipe must tell us how difficult it is!")
          );
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });
      test("Creating recipe without procedure", async () => {
        try {
          const data = { ...recipe1 };
          data.procedure = [];

          await expect(recipeDAO.create(data)).rejects.toThrow(
            new ApiError(400, "Every recipe must have a procedure!")
          );
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });
      test("Creating recipe without tools", async () => {
        try {
          const data = { ...recipe1 };
          data.tools = [];

          await expect(recipeDAO.create(data)).rejects.toThrow(
            new ApiError(400, "Every recipe must have the necessary tools!")
          );
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });
      test("Creating recipe with 0 prep time", async () => {
        try {
          const data = { ...recipe1 };
          data.prepTimeInMins = 0;

          await expect(recipeDAO.create(data)).rejects.toThrow(
            new ApiError(400, "Every recipe must have a prep time!")
          );
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });

      test("Creating recipe with undefined cook time", async () => {
        try {
          const data = { ...recipe1 };
          data.cookTimeInMins = undefined;
          const newRecipe = await recipeDAO.create(data);
          expect(newRecipe.cookTimeInMins).toEqual(0);
          await recipeDAO.delete(newRecipe.id);
        } catch (err: any) {
          console.log(`${err.status}. Error: ${err.message}`);
        }
      });
    });
    test("Creating recipe with tags", async () => {
      try {
        const tag1name = "recipe_create_test_tag1";
        const tag2name = "recipe_create_test_tag2";
        const tag1 = await prisma.tag.upsert({
          where: { name: tag1name },
          update: {},
          create: { name: tag1name },
        });
        const tag2 = await prisma.tag.upsert({
          where: { name: tag2name },
          update: {},
          create: { name: tag2name },
        });

        const recipe_data = {
          name: "Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
          ingredients: [
            "8 ounces gluten-free penne pasta or whole-wheat penne pasta",
            "2 tablespoons extra-virgin olive oil",
            "1 pound boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces",
            "½ teaspoon salt",
            "¼ teaspoon ground pepper",
            "4 cloves garlic, minced",
            "½ cup dry white wine",
            "Juice and zest of 1 lemon",
            "10 cups chopped fresh spinach",
            "4 tablespoons grated Parmesan cheese, divided",
          ],
          procedure: [
            "Cook pasta according to package directions. Drain and set aside.",
            "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
            "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
          ],
          tools: ["drainer", "pot", "large high sided skillet"],
          prepTimeInMins: 10,
          cookTimeInMins: 25,
          nutrition: undefined,
          author: {
            connect: {
              id: testUser.id,
            },
          },
          tags: [tag1, tag2] ,
          servings: 4,
          difficulty: 4,
        };

        // @ts-ignore
        const newRecipe = await recipeDAO.create(recipe_data);

        const createdRecipe = await recipeDAO.read(newRecipe.id);
        if (createdRecipe) {
          expect(createdRecipe.tags.length).toEqual(2);
          expect(createdRecipe.tags[0]).toEqual(tag1);
        } else {
          throw new ApiError(404, "Unable to find created recipe");
        }
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });
  });
  describe("Updating recipes", () => {
    let toBeUpdatedRecipeID: String;
    let updateTag1: Tag;
    let updateTag2: Tag;
    beforeAll(async () => {
      const tag1name = "recipe_dao_testing_tag1";
      const tag2name = "recipe_dao_testing_tag2";
      updateTag1 = await prisma.tag.upsert({
        where: {
          name: tag1name,
        },
        update: {},
        create: { name: tag1name },
      });
      updateTag2 = await prisma.tag.upsert({
        where: {
          name: tag2name,
        },
        update: {},
        create: { name: tag2name },
      });
      const data = {
        name: "Test Recipe: Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
        ingredients: [
          "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
          "extra-virgin olive oil: 2 tablespoons",
          "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
          "salt: ½ teaspoon",
          "ground pepper: ¼ teaspoon",
          "garlic, minced: 4 cloves",
          "dry white wine: ½ cup",
          "Juice and zest of lemon: 1",
          "chopped fresh spinach: 10 cups ",
          "grated Parmesan cheese, divided: 4 tablespoons",
        ],
        procedure: [
          "Cook pasta according to package directions. Drain and set aside.",
          "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
          "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
        ],
        tools: ["drainer", "pot", "large high sided skillet"],
        prepTimeInMins: 10,
        cookTimeInMins: 25,
        nutrition: undefined,
        author: {
          connect: {
            id: testUser.id,
          },
        },
        servings: 4,
        difficulty: 4,
      };
      const toBeUpdatedRecipe = await recipeDAO.create(data);
      toBeUpdatedRecipeID = toBeUpdatedRecipe.id;
    });
    afterAll(async () => {
      await prisma.review.deleteMany({
        where: {
          recipeId: toBeUpdatedRecipeID.valueOf(),
        },
      });
      await prisma.recipe.delete({
        where: {
          id: toBeUpdatedRecipeID.valueOf(),
        },
      });
      await prisma.tag.delete({
        where: {
          id: updateTag1.id,
        },
      });
      await prisma.tag.delete({
        where: {
          id: updateTag2.id,
        },
      });
    });
    test("Update single recipe field", async () => {
      try {
        const updated = { name: "Updated Name" };
        const updatedRecipe = await recipeDAO.update(
          toBeUpdatedRecipeID.valueOf(),
          updated
        );
        expect(updatedRecipe.name === updated.name);
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    }, 20000);
    test("Update multiple recipe fields at once", async () => {
      try {
        const updateInfo = {
          name: "Being updated",
          cookTimeInMins: 1111,
          tools: ["magic", "cauldron"],
        };

        const updatedRecipe = await recipeDAO.update(
          toBeUpdatedRecipeID.valueOf(),
          updateInfo
        );
        expect(updatedRecipe.name === updateInfo.name);
        expect(updatedRecipe.cookTimeInMins === updateInfo.cookTimeInMins);
        expect(updatedRecipe.tools === updateInfo.tools);
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Test updating difficulty with string", async () => {
      try {

        const updated = { difficulty: "4" };
        // @ts-ignore
        const updatedRecipe = await recipeDAO.update(
          toBeUpdatedRecipeID.valueOf(),
            // @ts-ignore
          updated
        );
        expect(updatedRecipe.difficulty === 4);
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Try to update recipe difficulty with invalid difficulty", async () => {
      try {
        const updated = { difficulty: 17 };
        await expect(
          recipeDAO.update(toBeUpdatedRecipeID.valueOf(), updated)
        ).rejects.toThrow(new ApiError(400, "Invalid difficulty!"));
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Try to update recipe difficulty with negative prepTime", async () => {
      try {
        const updated = { prepTimeInMins: -1 };
        await expect(
          recipeDAO.update(toBeUpdatedRecipeID.valueOf(), updated)
        ).rejects.toThrow(
          new ApiError(400, "Negative time parameters are invalid!")
        );
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Update ingredients", async () => {
      try {
        const recipe = await recipeDAO.read(toBeUpdatedRecipeID.valueOf());
        const ingreds = recipe.ingredients;
        const updatedIngredients = [...ingreds, "magic: a thimble"];
        const updatedRecipe = await recipeDAO.update(
            toBeUpdatedRecipeID.valueOf(),
            // @ts-ignore
            { ingredients: updatedIngredients }
        );
        expect(updatedRecipe.ingredients).not.toEqual(ingreds);
        expect(updatedRecipe.ingredientString).toContain("magic");
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Add existing tag to recipe", async () => {
      try {

        const updatedRecipe = await recipeDAO.update(
          toBeUpdatedRecipeID.valueOf(),
            // @ts-ignore
          { tags: [updateTag1] }
        );
        expect(updatedRecipe.tags.length == 1);
        expect(updatedRecipe.tags[0].name).toEqual(updateTag1.name);
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Remove tag from recipe", async () => {
      try {

        const updatedRecipe = await recipeDAO.update(
          toBeUpdatedRecipeID.valueOf(),
            // @ts-ignore
          { tags: [] }
        );
        expect(updatedRecipe.tags.length == 0);
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Try to update recipe with not yet existent tag", async () => {
      const tagName = "not_yet_existent";
      try {
        await prisma.tag.delete({ where: { name: tagName } });
      } catch (err: any) {}

      const updatedRecipe = await recipeDAO.update(
        toBeUpdatedRecipeID.valueOf(),
          // @ts-ignore
        { tags: [{ name: tagName }] }
      );
      const tagNames = updatedRecipe.tags.map((tag) => tag.name);
      expect(tagNames).toContain(tagName);
    });

    test("Try to update recipe with duplicate of tag it already has", async () => {
      // @ts-ignore
      expect(
        recipeDAO.update(toBeUpdatedRecipeID.valueOf(), {
          // @ts-ignore
          tags: [updateTag2, updateTag2],
        })
      ).rejects.toThrow(new ApiError(404, "Invalid tag or recipe ID!"));
    });

    describe("Testing updateAuthor method", () => {
      let newUser: User;
      beforeAll(async () => {
        const authorEmail = "test_author@jhu.edu";
        newUser = await prisma.user.upsert({
          where: {
            email: authorEmail,
          },
          update: {},
          create: {
            email: authorEmail,
            username: "update_author_test_username",
            password: "test100",
            image: "google.come",
            googleId: "authors10",
            verified: true,
          },
        });
      });
      afterAll(async () => {
        const withUpdatedAuthor = await recipeDAO.updateAuthor(
          toBeUpdatedRecipeID.valueOf(),
          testUser.id
        ); // transfer back to previous user to allow sample user to be deleted
        await prisma.user.delete({
          where: {
            email: newUser.email,
          },
        });
      });
      test("Update recipe's author to new authorID", async () => {
        const withUpdatedAuthor = await recipeDAO.updateAuthor(
          toBeUpdatedRecipeID.valueOf(),
          newUser.id
        );
        expect(withUpdatedAuthor.authorID === newUser.id);
      });

      test("Try to update recipe's author with invalid authorID", async () => {
        const invalidAuthorID = "&*#$#";

        await expect(
          recipeDAO.updateAuthor(toBeUpdatedRecipeID.valueOf(), invalidAuthorID)
        ).rejects.toThrow(new ApiError(404, "Invalid author or recipe ID!"));
      });

      test("Try to update author of recipe with invalid ID", async () => {
        const invalidRecipeID = "&*#$#";

        await expect(
          recipeDAO.updateAuthor(invalidRecipeID, newUser.id)
        ).rejects.toThrow(new ApiError(404, "Invalid author or recipe ID!"));
      });
    });

    describe("Testing updateFavorite method", () => {
      let newUser1: User;
      let newUser2: User;
      beforeAll(async () => {
        const user1Email = "update_favorite_test_email@jhu.edu";
        const user2Email = "update_favorite_test_email2@jhu.edu";
        newUser1 = await prisma.user.upsert({
          where: {
            email: user1Email,
          },
          update: {},
          create: {
            email: user1Email,
            username: "updating_favorite_test_username1",
            password: "test123",
            image: "google.come",
            googleId: "favors123",
            verified: true,
          },
        });
        newUser2 = await prisma.user.upsert({
          where: {
            email: user2Email,
          },
          update: {},
          create: {
            email: user2Email,
            username: "updating_favorite_test_username2",
            password: "test123",
            image: "google.come",
            googleId: "favors456",
            verified: true,
          },
        });
      });
      afterAll(async () => {
        await prisma.user.delete({
          where: {
            email: newUser1.email,
          },
        });
        await prisma.user.delete({
          where: {
            email: newUser2.email,
          },
        });
      });
      test("Add User to empty favoritedBy ", async () => {
        const withUpdatedFav = await recipeDAO.updateFavorite(
          toBeUpdatedRecipeID.valueOf(),
          newUser1.id,
          true
        );
        expect(withUpdatedFav.favoritedBy.length === 1);
        expect(withUpdatedFav.favoritedBy[0].username === newUser1.username);
      });

      test("Add User to non-empty favoritedBy ", async () => {
        const withUpdatedFav = await recipeDAO.updateFavorite(
          toBeUpdatedRecipeID.valueOf(),
          newUser2.id,
          true
        );
        expect(withUpdatedFav.favoritedBy.length === 2);
        expect(withUpdatedFav.favoritedBy[0].username === newUser1.username);
        expect(withUpdatedFav.favoritedBy[1].username === newUser2.username);
      });

      test("Remove User from favoritedBy ", async () => {
        const withUpdatedFav = await recipeDAO.updateFavorite(
          toBeUpdatedRecipeID.valueOf(),
          newUser1.id,
          false
        );
        expect(withUpdatedFav.favoritedBy.length === 1);
        expect(withUpdatedFav.favoritedBy[0].username === newUser2.username);
      });

      test("Try to add invalid user to FavoritedBy", async () => {
        const invalidUserID = "&*#$#";

        await expect(
          recipeDAO.updateFavorite(
            toBeUpdatedRecipeID.valueOf(),
            invalidUserID,
            true
          )
        ).rejects.toThrow(new ApiError(404, "Invalid user or recipe ID!"));
      });

      test("Try to remove invalid user from FavoritedBy", async () => {
        const invalidUserID = "&*#$#";

        await expect(
          recipeDAO.updateFavorite(
            toBeUpdatedRecipeID.valueOf(),
            invalidUserID,
            false
          )
        ).rejects.toThrow(new ApiError(404, "Invalid user or recipe ID!"));
      });

      test("Try to update favoritedBy of recipe with invalid ID", async () => {
        const invalidRecipeID = "&*#$#";

        await expect(
          recipeDAO.updateFavorite(invalidRecipeID, newUser1.id, true)
        ).rejects.toThrow(new ApiError(404, "Invalid user or recipe ID!"));
      });
    });

    describe("Test addReview method", () => {
      let reviewUser: User;
      const reviewEmail = "reviews_test_email@jhu.edu";
      beforeAll(async () => {
        reviewUser = await prisma.user.upsert({
          where: {
            email: reviewEmail,
          },
          update: {},
          create: {
            email: reviewEmail,
            username: "updating_review_test_username",
            password: "test123",
            image: "google.come",
            googleId: "testing35",
            verified: true,
          },
        });

        await prisma.review.deleteMany({
          where: {
            recipeId: toBeUpdatedRecipeID.valueOf(),
          },
        });

        await prisma.review.deleteMany({
          where: {
            userId: reviewUser.id.valueOf(),
          },
        });
      });
      afterAll(async () => {
        await userDAO.delete(reviewUser.id);
      }, 15000);

      test("Add review to recipe", async () => {
        const comment = "Great recipe!";
        const score = 4;
        const withReview = await recipeDAO.addReview(
          toBeUpdatedRecipeID.valueOf(),
          reviewUser.id,
          score,
          comment
        );
        expect(withReview.reviews.length).toBe(1);
        expect(withReview.reviews[0].comment).toEqual(comment);
        expect(withReview.reviews[0].score).toEqual(score);
        const updatedUser = await userDAO.read(reviewUser.id);
        if (updatedUser) {
          expect(updatedUser.reviews).toBeDefined();
          if (updatedUser.reviews) {
            expect(updatedUser.reviews.length).toEqual(1);
            expect(updatedUser.reviews[0].comment).toEqual(comment);
          }
        }
      }, 15000);

      test("Add multiple reviews to recipe", async () => {
        const comment = "Great recipe!";
        const score = 4;
        const withReview1 = await recipeDAO.addReview(
          toBeUpdatedRecipeID.valueOf(),
          reviewUser.id,
          score,
          comment
        );
        const withReview2 = await recipeDAO.addReview(
          toBeUpdatedRecipeID.valueOf(),
          reviewUser.id,
          score,
          "not bad"
        );
        expect(withReview2.reviews.length).toBe(3);

        const updatedUser = await userDAO.read(reviewUser.id);
        if (updatedUser) {
          expect(updatedUser.reviews).toBeDefined();
          if (updatedUser.reviews) {
            expect(updatedUser.reviews.length).toEqual(3);
          }
        }
      }, 20000);

      test("Try to add review with too long comment to recipe", async () => {
        const str = new String("x").repeat(3001);

        await expect(
          recipeDAO.addReview(
            toBeUpdatedRecipeID.valueOf(),
            reviewUser.id,
            5,
            str
          )
        ).rejects.toThrow(new ApiError(404, "Comment is too long!"));
      });

      test("Try to add review to recipe with invalid id", async () => {
        const invalidRecipeID = "@)#($*)#@*$)";

        await expect(
          recipeDAO.addReview(
            invalidRecipeID,
            reviewUser.id,
            5,
            "Invalid recipe ID"
          )
        ).rejects.toThrow(new ApiError(404, "Invalid recipe or user!"));
      }, 10000);

      test("Try to add review from user with invalid id", async () => {
        const invalidUserID = "@)#($*)#@*$)";

        await expect(
          recipeDAO.addReview(
            toBeUpdatedRecipeID.valueOf(),
            invalidUserID,
            5,
            "Invalid recipe ID"
          )
        ).rejects.toThrow(new ApiError(404, "Invalid recipe or user!"));
      }, 10000);

      test("Try to add review with negative score", async () => {
        const score = -3;

        await expect(
          recipeDAO.addReview(
            toBeUpdatedRecipeID.valueOf(),
            reviewUser.id,
            score,
            "Invalid score"
          )
        ).rejects.toThrow(new ApiError(404, "Invalid score!"));
      }, 10000);

      test("Try to add review with out of range score", async () => {
        const score = 100;

        await expect(
          recipeDAO.addReview(
            toBeUpdatedRecipeID.valueOf(),
            reviewUser.id,
            score,
            "Invalid score"
          )
        ).rejects.toThrow(new ApiError(404, "Invalid score!"));
      }, 10000);
    });
  });

  describe("Deleting recipes", () => {
    let data: Prisma.RecipeCreateInput;
    beforeAll(async () => {
      data = {
        name: "Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
        ingredients: [
          "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
          "extra-virgin olive oil: 2 tablespoons",
          "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
          "salt: ½ teaspoon",
          "ground pepper: ¼ teaspoon",
          "garlic, minced: 4 cloves",
          "dry white wine: ½ cup",
          "Juice and zest of lemon: 1",
          "chopped fresh spinach: 10 cups ",
          "grated Parmesan cheese, divided: 4 tablespoons",
        ],
        procedure: [
          "Cook pasta according to package directions. Drain and set aside.",
          "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
          "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
        ],
        tools: ["drainer", "pot", "large high sided skillet"],
        prepTimeInMins: 10,
        cookTimeInMins: 25,
        nutrition: undefined,
        author: {
          connect: {
            id: testUser.id,
          },
        },
        servings: 4,
        difficulty: 4,
      };
    });
    test("Delete recipe by id", async () => {
      try {
        const toBeDeletedRecipe = await recipeDAO.create(data);
        await recipeDAO
          .delete(toBeDeletedRecipe.id.valueOf())
          .then(async () => {
            const find = await prisma.recipe.findUnique({
              where: {
                id: toBeDeletedRecipe.id.valueOf(),
              },
            });
            if (find) {
              throw new ApiError(400, "Recipe should have been deleted");
            }
          });
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });

    test("Call delete recipe with invalid id", async () => {
      try {
        const recipeID = "^^^^^^^^^";
        await expect(recipeDAO.delete(recipeID)).rejects.toThrow(
          new ApiError(404, "There is no recipe with the given ID!")
        );
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });
  });

  describe("Reading recipes", () => {
    let data: Prisma.RecipeCreateInput;
    let toBeReadRecipeID: String;
    beforeAll(async () => {
      data = {
        name: "Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
        ingredients: [
          "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
          "extra-virgin olive oil: 2 tablespoons",
          "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
          "salt: ½ teaspoon",
          "ground pepper: ¼ teaspoon",
          "garlic, minced: 4 cloves",
          "dry white wine: ½ cup",
          "Juice and zest of lemon: 1",
          "chopped fresh spinach: 10 cups ",
          "grated Parmesan cheese, divided: 4 tablespoons",
        ],
        procedure: [
          "Cook pasta according to package directions. Drain and set aside.",
          "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
          "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
        ],
        tools: ["drainer", "pot", "large high sided skillet"],
        prepTimeInMins: 10,
        cookTimeInMins: 25,
        nutrition: undefined,
        author: {
          connect: {
            id: testUser.id,
          },
        },
        servings: 4,
        difficulty: 4,
      };
      const toBeReadRecipe = await recipeDAO.create(data);
      toBeReadRecipeID = toBeReadRecipe.id;
    });
    afterAll(async () => {
      await prisma.recipe.delete({
        where: {
          id: toBeReadRecipeID.valueOf(),
        },
      });
      await prisma.$disconnect;
    });
    describe("Test getFavorite method", () => {
      let newUser1: User;
      let newUser2: User;
      beforeAll(async () => {
        const user1Email = "getting_favorite_test_email@jhu.edu";
        const user2Email = "getting_favorite_test_email2@jhu.edu";
        newUser1 = await prisma.user.upsert({
          where: {
            email: user1Email,
          },
          update: {},
          create: {
            email: user1Email,
            username: "getting_favorite_test_username1",
            password: "test123",
            image: "google.come",
            googleId: "favors124",
            verified: true,
          },
        });
        newUser2 = await prisma.user.upsert({
          where: {
            email: user2Email,
          },
          update: {},
          create: {
            email: user2Email,
            username: "getting_favorite_test_username2",
            password: "test123",
            image: "google.come",
            googleId: "favors457",
            verified: true,
          },
        });
      });
      afterAll(async () => {
        await prisma.user.delete({
          where: {
            email: newUser1.email,
          },
        });
        await prisma.user.delete({
          where: {
            email: newUser1.email,
          },
        });
      });

      test("Get favorites", async () => {
        const withFavorites1 = await recipeDAO.updateFavorite(
          toBeReadRecipeID.valueOf(),
          newUser1.id,
          true
        );
        const withFavorites2 = await recipeDAO.updateFavorite(
          toBeReadRecipeID.valueOf(),
          newUser2.id,
          true
        );
        const getFavorites = await recipeDAO.getFavorite(
          toBeReadRecipeID.valueOf()
        );
        expect(getFavorites.favoritedBy.length).toBe(2);
        expect(getFavorites.favoritedBy[0].email).toEqual( newUser2.email || newUser1.email);
      }, 20000);

      test("Try to get favorites of recipe with invalid id", async () => {
        const invalidRecipeID = "@)#($*)#@*$)";

        await expect(recipeDAO.getFavorite(invalidRecipeID)).rejects.toThrow(
          new ApiError(404, "Invalid recipe ID!")
        );
      }, 10000);
    });
    test("Reading all recipes", async () => {
      try {
        const allRecipes = await recipeDAO.readAll();
        expect(allRecipes.length > 0);
        expect(allRecipes[allRecipes.length - 1].id === toBeReadRecipeID);
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });
    test("Read recipe with valid id", async () => {
      try {
        const readRecipe = await recipeDAO.read(toBeReadRecipeID.valueOf());
        if (readRecipe) {
          expect(readRecipe.id === toBeReadRecipeID);
        }
      } catch (err: any) {
        console.log(`${err.status}. Error: ${err.message}`);
      }
    });
    test("Call read recipe with invalid id", async () => {
      const recipeID = "^^^^^^^^^";
      await expect(recipeDAO.read(recipeID)).rejects.toThrow(
        new ApiError(404, "There is no recipe with the given ID!")
      );
    });
  });
});
