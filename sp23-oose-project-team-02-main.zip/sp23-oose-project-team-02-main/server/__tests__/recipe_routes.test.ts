import request from "supertest";
const app = require("../src/index");
import ApiError from "../src/model/ApiError";
import TagDAO from "../src/data/TagDao";
import RecipeDAO from "../src/data/RecipeDao";
import UserDAO from "../src/data/UserDao";
const tagDAO = new TagDAO();
const recipeDAO = new RecipeDAO();
const userDAO = new UserDAO();
import { PrismaClient, User, Recipe } from "@prisma/client";
const prisma = new PrismaClient();

describe("Recipe routes", () => {
  let testUser: User;
  let testRecipe: Recipe;

  beforeAll(async () => {
    const testEmail = "recipe_routes_test_email@jhu.edu";
    testUser = await prisma.user.upsert({
      where: {
        email: testEmail,
      },
      update: {},
      create: {
        email: testEmail,
        username: "recipe_routes_test_username",
        password: "jn101",
        image: "google.come",
        googleId: "tests0009",
        verified: true,
      },
    });
    const recipe1 = {
      name: "Chicken & Spinach Skillet Pasta with Lemon & Parmesan",
      ingredients: [
        "8 ounces gluten-free penne pasta or whole-wheat penne pasta",
        "2 tablespoons extra-virgin olive oil",
        "1 pound boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces",
        "½ teaspoon salt",
        "¼ teaspoon ground pepper",
        "4 cloves garlic, minced",
        "½ cup dry white wine",
        "Juice and zest of 1 lemon",
        "10 cups chopped fresh spinach",
        "4 tablespoons grated Parmesan cheese, divided",
      ],
      procedure: [
        "Cook pasta according to package directions. Drain and set aside.",
        "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
        "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
      ],
      tools: ["drainer", "pot", "large high sided skillet"],
      prepTimeInMins: 10,
      cookTimeInMins: 25,
      nutrition: undefined,
      author: {
        connect: {
          id: testUser.id,
        },
      },
      servings: 4,
      difficulty: 4,
    };
    testRecipe = await recipeDAO.create(recipe1);
  });

  afterAll(async () => {
    await recipeDAO.delete(testRecipe.id);
    await userDAO.delete(testUser.id);
    await prisma.$disconnect();
  });
  test("test GET/recipes", async () => {
    const response = await request(app).get("/recipes");
    expect(response.status).toBe(200);
    expect(response.body.message).toEqual(
      `Successfully retrieved ${response.body.data.length} recipes!`
    );
    expect(response.body.data.length).toBeGreaterThanOrEqual(0);
    const recipeIds = response.body.data.map((recipe: Recipe) => recipe.id);
    expect(recipeIds).toContain(testRecipe.id);
  });

  test("Test GET / error handling", async () => {
    //recipeDAO.readAll = jest.fn().mockReturnValueOnce(new ApiError(500, 'Database error'));

    jest.spyOn(recipeDAO, "readAll").mockImplementation(async () => {
      throw new ApiError(500, "Database error");
    });
    const response = await request(app).get("/recipes").expect(500);

    expect(response.body.message).toEqual("Database error");
  });

  test("test GET/recipes/:id", async () => {
    const response = await request(app)
      .get(`/recipes/${testRecipe.id}`)
      .expect(200);
    expect(response.body.data.name).toEqual(testRecipe.name);
    expect(response.body.data.authorID).toEqual(testRecipe.authorID);
    expect(response.body.data.ingredientString).toEqual(
      testRecipe.ingredientString
    );
  });

  test("Try to get recipe with invalid id", async () => {
    const response = await request(app).get(`/recipes/@#$)(*@$*##`).expect(404);
    expect(response.body.message).toEqual(
      "There is no recipe with the given ID!"
    );
  });

  test("test POST/recipes", async () => {
    const data = {
      name: "Test Recipe: Skillet Pasta",
      ingredients: [
        "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
        "extra-virgin olive oil: 2 tablespoons",
        "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
        "salt: ½ teaspoon",
        "ground pepper: ¼ teaspoon",
        "garlic, minced: 4 cloves",
        "dry white wine: ½ cup",
        "Juice and zest of lemon: 1",
        "chopped fresh spinach: 10 cups ",
        "grated Parmesan cheese, divided: 4 tablespoons",
      ],
      procedure: [
        "Cook pasta according to package directions. Drain and set aside.",
        "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
        "Remove from heat. Stir in spinach and the cooked pasta. Cover and let stand until the spinach is just wilted. Divide among 4 plates and top each serving with 1 tablespoon Parmesan.",
      ],
      tools: ["drainer", "pot", "large high sided skillet"],
      prepTimeInMins: 10,
      cookTimeInMins: 25,
      nutrition: undefined,
      authorID: testUser.id,
      servings: 4,
      difficulty: 4,
    };
    const response = await request(app).post(`/recipes/`).send(data);
    expect(response.status).toBe(201);
    expect(response.body.message).toEqual(
      `Successfully created the following recipe!`
    );
    expect(response.body.data.name).toEqual(data.name);
    expect(response.body.data.cookTimeInMins).toEqual(data.cookTimeInMins);
    expect(response.body.data.id).toBeDefined();
  });

  test("Try to create recipe with invalid author", async () => {
    const data = {
      name: "Test Recipe: Skillet Pasta",
      ingredients: [
        "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
        "extra-virgin olive oil: 2 tablespoons",
        "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
      ],
      procedure: [
        "Cook pasta according to package directions. Drain and set aside.",
        "Meanwhile, heat oil in a large high-sided skillet over medium-high heat. Add chicken, salt and pepper; cook, stirring occasionally, until just cooked through, 5 to 7 minutes. Add garlic and cook, stirring, until fragrant, about 1 minute. Stir in wine, lemon juice and zest; bring to a simmer.",
      ],
      tools: ["drainer", "pot", "large high sided skillet"],
      prepTimeInMins: 10,
      cookTimeInMins: 25,
      nutrition: undefined,
      authorID: "2304823dj234akdlf",
      servings: 4,
      difficulty: 4,
    };
    const response = await request(app)
      .post(`/recipes/`)
      .send(data)
      .expect(404);
    expect(response.body.message).toEqual(
      "There is no user with the given ID!"
    );
  });

  describe("Test update route", () => {
    test("test PUT/recipes/:id", async () => {
      const response = await request(app)
        .put(`/recipes/${testRecipe.id}`)
        .send({ name: "Updated Test Recipe" })
        .expect(200);
      expect(response.body.data.name).toEqual("Updated Test Recipe");
      expect(response.body.message).toEqual(
        `Successfully updated the following recipe!`
      );
    });

    test("Try to update invalid recipe", async () => {
      const response = await request(app)
        .put(`/recipes/^%$^&#*@!@***`)
        .send({ name: "Invalid Update" })
        .expect(404);
      expect(response.body.message).toContain(
        "Error while trying to update recipe!"
      );
    });
  });

  describe("Test user related recipe routes", () => {
    let newUser: User;
    beforeAll(async () => {
      const newUserEmail = "recipe_route_update_author_test@jhu.edu";
      newUser = await prisma.user.upsert({
        where: { email: newUserEmail },
        update: {},
        create: {
          email: newUserEmail,
          username: "test_user_recipe_routes_",
          password: "jn101",
          image: "google.come",
          googleId: "tests0003",
          verified: true,
        },
      });
    });
    test("test PUT/recipes/:id/author", async () => {
      const response = await request(app)
        .put(`/recipes/${testRecipe.id}/author`)
        .send({ authorID: newUser.id });
      expect(response.status).toBe(200);
      expect(response.body.data.authorID).toEqual(newUser.id);
      expect(response.body.message).toEqual(
        `Successfully updated the following recipe!`
      );
    });

    test("Try to update author to invalid user", async () => {
      const response = await request(app)
        .put(`/recipes/${testRecipe.id}/author`)
        .send({ authorID: "#@)$(*#)@(*$###" });
      expect(response.status).toEqual(404);
      expect(response.body.message).toEqual("Invalid author or recipe ID!");
    });

    test("test PUT/recipes/:id/favorite/:userID", async () => {
      const response = await request(app)
        .put(`/recipes/${testRecipe.id}/favorite/${testUser.id}`)
        .expect(200);
      expect(response.body.data.favoritedBy[0].username).toEqual(
        testUser.username
      );
      expect(response.body.message).toEqual(
        `Successfully updated the following recipe!`
      );
    });
    test("Try to add invalid user to favoritedBy", async () => {
      const response = await request(app).put(
        `/recipes/${testRecipe.id}/favorite/@#$)(*@$*##`
      );
      expect(response.body.status).toEqual(404);
      expect(response.body.message).toEqual(
        "There is no user with the given ID!"
      );
    });
    test("test DELETE/recipes/:id/favorite/:userID", async () => {
      const response = await request(app)
        .delete(`/recipes/${testRecipe.id}/favorite/${testUser.id}`)
        .expect(200);
      expect(response.body.data.favoritedBy.length).toEqual(0);
      expect(response.body.message).toEqual(
        `Successfully updated the following recipe!`
      );
    });

    test("Try to remove invalid user from favoritedBy", async () => {
      const response = await request(app).delete(
        `/recipes/${testRecipe.id}/favorite/@#$)(*@$*##`
      );
      expect(response.body.status).toEqual(404);
      expect(response.body.message).toEqual(
        "There is no user with the given ID!"
      );
    });

    test("test PUT/recipes/:id/review", async () => {
      const review_comment = "Great!!";
      const response = await request(app)
        .put(`/recipes/${testRecipe.id}/review`)
        .send({ userId: testUser.id, score: 4, comment: review_comment })
        .expect(200);
      expect(response.body.data.reviews.length).toEqual(1);
      expect(response.body.data.reviews[0].comment).toEqual(review_comment);
      expect(response.body.message).toEqual(
        `Successfully updated the following recipe!`
      );
    }, 20000);

    test("test PUT/recipes/:id/review with invalid user ID", async () => {
      const review_comment = "Great!!";

      const response = await request(app)
        .put(`/recipes/${testRecipe.id}/review`)
        .send({
          userId: "@#)$(*#@)($*@)(#*$",
          score: 4,
          comment: review_comment,
        });
      expect(response.body.status).toEqual(404);
      expect(response.body.message).toEqual(
        "There is no user with the given ID!"
      );
    }, 20000);
  });

  test("test DELETE /recipes/:id", async () => {
    const data = {
      name: "Test Recipe",
      ingredients: [
        "gluten-free penne pasta or whole-wheat penne pasta: 8 ounces",
        "extra-virgin olive oil: 2 tablespoons",
        "boneless, skinless chicken breast or thighs, trimmed, if necessary, and cut into bite-size pieces: 1 pound",
        "salt: ½ teaspoon",
      ],
      procedure: ["Mix ingredients.", "Eat."],
      tools: ["drainer", "pot", "large high sided skillet"],
      prepTimeInMins: 10,
      cookTimeInMins: 25,
      nutrition: undefined,
      author: {
        connect: {
          id: testUser.id,
        },
      },
      servings: 4,
      difficulty: 4,
    };
    const recipe = await recipeDAO.create(data).then(async (recipe) => {
      const response = await request(app)
        .delete(`/recipes/${recipe.id}`)
        .expect(200);
      expect(response.body.message).toEqual(
        `Successfully deleted the following recipe!`
      );
    });
  });
  test("test trying to delete recipe with invalid id", async () => {
    const response = await request(app).delete(`/recipes/@#$)98$###(@##`);
    expect(response.body.status).toEqual(404);
    expect(response.body.message).toEqual(
      "There is no recipe with the given ID!"
    );
  });

  describe("Test search routes", () => {
    let testRecipe: Recipe;
    beforeAll(async () => {
      const kosher_tag = await prisma.tag.upsert({
        where: { name: "kosher" },
        update: {},
        create: { name: "kosher" },
      });
      const data = {
        name: "Test Recipe",
        ingredients: ["cauliflower: 2 heads", "salt: 2 tbsp"],
        procedure: [
          "Sprinkle salt on cauliflower.",
          "Bake for 5 minutes at 450.",
        ],
        tools: ["pan"],
        prepTimeInMins: 3,
        cookTimeInMins: 5,
        nutrition: undefined,
        author: { connect: { id: testUser.id } },
        tags: { connect: { id: kosher_tag.id } },
        servings: 4,
        difficulty: 4,
      };
      testRecipe = await recipeDAO.create(data);
    });
    afterAll(async () => {
      await recipeDAO.delete(testRecipe.id);
    });
    test("Test search route with all parameters defined", async () => {
      const response = await request(app)
        .get(
          `/recipes/search?UserId=${testUser.id}&includedTags=kosher&ingredients=cauliflower,salt&excludedIngredients=magic unicorn wine&excludedTags=meat&cookTime=160&prepTime=40&rating=0&userQuery=Recipe`
        )
        .expect(200);
      expect(response.body.message).toEqual(
        `Successfully retrieved ${response.body.data.length} recipes!`
      );
    });

    test("Test searchGPT route with all parameters defined", async () => {
      const response = await request(app)
        .get(`/recipes/gptsearch?UserId=${testUser.id}&gptQuery=Recipe`)
        .expect(200)
          .then((res)=> {

            const length = res.body.data.length;
            expect(res.body.message).toEqual(
                `Successfully retrieved ${length} recipes!`
            );
          })

    });
  });
});
