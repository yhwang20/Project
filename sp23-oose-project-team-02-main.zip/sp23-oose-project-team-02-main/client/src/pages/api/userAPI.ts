import axios from "axios";
import { Tag, userPreferences } from "user-types";

interface Data {
  username?: string;
  email?: string;
  password?: string;
  verified?: boolean;
  userPreferences?: any;
  image?: string;
  setupComplete?: boolean;
  recipes?: any;
  favoritedRecipes?: any;
  googleId?: string;
}

interface preferenceData {
  ingredientsExcluded?: string[];
  difficulty?: number;
  timeInMins?: number;
  vegan?: boolean;
  vegetarian?: boolean;
  kosher?: boolean;
  halal?: boolean;
  keto?: boolean;
  glutenFree?: boolean;
  nonDairy?: boolean;
  cuisineTags?: Tag[];
}

//const BASE_URL = "http://localhost:4332";
const BASE_URL = "https://reciplease-server-r8tz.onrender.com";

export async function getUser(id: string) {
  try {
    const res = await axios.get(`${BASE_URL}/users/${id}`);
    return res.data.data;
  } catch (err) {
    return undefined;
  }
}

export async function getUsers(email: string) {
  try {
    const res = await axios.get(`${BASE_URL}/users`, {
      params: {
        email: email,
      },
    });
    return res.data;
  } catch (err) {
    return undefined;
  }
}

export async function getGoogleUser(googleId: string) {
  try {
    const res = await axios.get(`${BASE_URL}/users/google/${googleId}`);
    return res.data;
  } catch (err) {
    return undefined;
  }
}

export async function updateGoogleUser(
  email: string,
  name: string,
  googleId: string,
  image: string
) {
  try {
    const user = await axios.post(`${BASE_URL}/users/google/`, {
      email: email,
      name: name,
      googleId: googleId,
      image: image,
    });
    console.log(user.data);
    return user.data;
  } catch (err) {
    return undefined;
  }
}

export async function updateUser(id: string, data: Data) {
  try {
    const res = await axios.put(`${BASE_URL}/users/${id}`, data);
    return res.data;
  } catch (err) {
    return undefined;
  }
}

export async function createUser(
  username: string,
  email: string,
  password: string,
  dob: string
) {
  try {
    const res = await axios.post(`${BASE_URL}/users/signup`, {
      username: username,
      email: email,
      password: password,
      dob: dob,
    });
    return res.data;
  } catch (err) {
    return undefined;
  }
}

export async function createUserPreference(
  userId: string,
  userPreferences: userPreferences
) {
  try {
    const res = await axios.post(
      `${BASE_URL}/user/${userId}/preferences`,
      userPreferences
    );
    return res.data;
  } catch (err: any) {
    return err.message;
  }
}

export async function updatedUserPreference(
  userId: string,
  data: preferenceData
) {
  try {
    const res = await axios.put(`${BASE_URL}/user/${userId}/preferences`, data);
    return res.data;
  } catch (err: any) {
    return err.message;
  }
}
