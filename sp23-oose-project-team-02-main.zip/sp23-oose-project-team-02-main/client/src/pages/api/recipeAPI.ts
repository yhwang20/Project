import axios from "axios";
import { Recipe } from "recipe-types";
import { Tag } from "user-types";

const BASE_URL = "https://reciplease-server-r8tz.onrender.com";
//const BASE_URL = "http://localhost:4332";

export async function searchRecipes(
  userQuery?: string,
  includedTags?: string[],
  excludedTags?: string[],
  prepTime?: string,
  cookTime?: string,
  rating?: string,
  includedIngredients?: string[],
  excludedIngredients?: string[],
  maxDifficulty?: string,
  userId?: string
) {
  try {
    const res = await fetch(
      `${BASE_URL}/recipes/search?userQuery=${userQuery}&includedTags=${includedTags}&excludedTags=${excludedTags}
      &ingredients=${includedIngredients}&excludedIngredients=${excludedIngredients}
      &maxDifficulty=${maxDifficulty}&prepTime=${prepTime}&cookTime=${cookTime}&rating=${rating}&UserId=${userId}`
    );
    const recipes = await res.json();
    return recipes.data;
  } catch (err) {
    return undefined;
  }
}

export async function searchRecipesGPT(gptQuerry?: string, userId?: string) {
  try {
    const res = await fetch(
      `${BASE_URL}/recipes/gptsearch?gptQuery=${gptQuerry}&UserId=${userId}`
    );
    const recipes = await res.json();
    return recipes.data;
  } catch (err) {
    return undefined;
  }
}

export async function getRecipes() {
  try {
    const res = await fetch(`${BASE_URL}/recipes`, {
      method: "GET",
      mode: "cors",
      headers: {
        "Content-Type": "application/json",
      },
    });
    const recipes = await res.json();
    return recipes.data;
  } catch (err) {
    return undefined;
  }
}

export async function getRecipe(id: string) {
  try {
    const res = await fetch(`${BASE_URL}/recipes/${id}`);
    const recipe = await res.json();
    return recipe.data;
  } catch (err) {
    throw new Error("Error getting recipe");
  }
}

export async function addReview(
  recipeId: string,
  userId: string,
  score: number,
  comment: string
) {
  try {
    const res = await axios.put(`${BASE_URL}/recipes/${recipeId}/review`, {
      userId,
      score,
      comment,
    });
    return res.data.data;
  } catch (err) {
    throw new Error("Error adding review");
  }
}

export async function addRecipe(
  name: string,
  authorId: string,
  ingredients: string[],
  procedure: string[],
  tools: string[],
  prepTimeInMins: number,
  servings: number,
  difficulty: number,
  cookTimeInMins?: number,
  background?: string,
  nutrition?: {},
  tags?: Tag[],
  image?: string
) {
  try {
    return axios
      .post(`${BASE_URL}/recipes`, {
        name: name,
        authorID: authorId,
        ingredients: ingredients,
        procedure: procedure,
        tools: tools,
        prepTimeInMins: prepTimeInMins,
        cookTimeInMins: cookTimeInMins,
        difficulty: difficulty,
        nutrition: nutrition,
        background: background,
        servings: servings,
        tags: tags,
        photo: image,
      })
      .then((res) => {
        console.log(res);
      })
      .catch((err) => {
        console.log(err);
      });
  } catch (err) {
    throw new Error("Error adding recipe");
  }
}

export async function addFavorite(userId: string, recipeId: string) {
  try {
    const res = await axios.put(
      `${BASE_URL}/recipes/${recipeId}/favorite/${userId}`
    );
    return res.data.data;
  } catch (err) {
    throw new Error("Error adding favorite");
  }
}

export async function deleteRecipe(recipeId: string) {
  try {
    const res = await axios.delete(`${BASE_URL}/recipes/${recipeId}`);
    console.log(res);
    return res;
  } catch (err) {
    throw new Error("Error deleting recipe");
  }
}

export async function removeFavorite(userId: string, recipeId: string) {
  try {
    const res = await axios.delete(
      `${BASE_URL}/recipes/${recipeId}/favorite/${userId}`
    );
    return res.data.data;
  } catch (err) {
    throw new Error("Error removing favorite");
  }
}

export async function updateRecipe(
  recipeId: string,
  data: {
    name?: string;
    ingredients?: string[];
    procedure?: string[];
    tools?: string[];
    prepTimeInMins?: number;
    cookTimeInMins?: number;
    difficulty?: number;
    nutrition?: {};
    background?: string;
    servings?: number;
    tags?: Tag[];
    photo?: string;
  }
) {
  try {
    const res = await axios.put(`${BASE_URL}/recipes/${recipeId}`, data);
    return res.data.data;
  } catch (err) {
    throw new Error("Error updating recipe");
  }
}
