import NextAuth from "next-auth";
import FacebookProvider from "next-auth/providers/facebook";
import GoogleProvider from "next-auth/providers/google";
import CredentialsProvider from "next-auth/providers/credentials";
import { getGoogleUser, getUser, updateGoogleUser } from "../userAPI";

export default NextAuth({
  providers: [
    // OAuth authentication providers...
    GoogleProvider({
      clientId: process.env.GOOGLE_ID!,
      clientSecret: process.env.GOOGLE_SECRET!,
    }),
    FacebookProvider({
      clientId: process.env.FACEBOOK_ID!,
      clientSecret: process.env.FACEBOOK_SECRET!,
    }),
    CredentialsProvider({
      id: "email-login",
      name: "Email",
      credentials: {
        email: {
          label: "Email",
          type: "email",
          placeholder: "jsmith@example.com",
        },
        password: { label: "Password", type: "password" },
      },
      async authorize(credentials) {
        const authResponse = await fetch(
          `https://reciplease-server-r8tz.onrender.com/auth/login`,
          {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(credentials),
          }
        );

        if (!authResponse.ok) {
          throw new Error("User not found");
        }

        const user = await authResponse.json();
        if (!user) {
          throw new Error("Invalid email or password");
        }
        if (!user.data.confirmed) {
          throw new Error("Please confirm your email");
        }

        if (user.data.googleId) {
          throw new Error("Please sign in with Google");
        }

        return user.data;
      },
    }),
  ],
  callbacks: {
    async signIn({ user, account, profile }) {
      if (account!.provider === "email-login") {
        return true;
      }
      if (account!.provider === "google") {
        const googleUser = await getGoogleUser(user.id);
        if (googleUser !== undefined) {
          return true;
        } else {
          const newUser = await updateGoogleUser(
            user!.email!,
            user!.name!,
            user.id,
            user.image
          );
          if (newUser) {
            return true;
          }
        }
      }
      return false;
    },
    session: async ({ session, token }) => {
      if (session?.user) {
        session.user.id = token.uid;
        session.user.provider = token.provider;
        session.user.username = token.username;
        session.user.setupComplete = token.setupComplete;
        session.user.image = token.image;
      }
      return session;
    },
    jwt: async ({ user, token, account, trigger, session }) => {
      if (trigger === "update" && session) {
        if (typeof session.setupComplete === "boolean") {
          token.setupComplete = true;
        }
        if (typeof session.image === "string") {
          token.image = session.image;
        }
        if (typeof session.username === "string") {
          token.username = session.username;
        }
      }
      if (user) {
        token.provider = account?.provider;
        if (account?.provider === "google") {
          const googleUser = await getGoogleUser(user.id);
          token.uid = googleUser.data.id;
          token.username = googleUser.data.username;
          token.setupComplete = googleUser.data.setupComplete;
          token.image = googleUser.data.image;
        } else {
          const emailUser = await getUser(user.id);
          token.uid = user.id;
          token.username = user.user;
          token.setupComplete = emailUser.setupComplete;
          token.image = emailUser.image;
        }
      }
      return token;
    },
  },
  secret: process.env.AUTH_SECRET,
});
