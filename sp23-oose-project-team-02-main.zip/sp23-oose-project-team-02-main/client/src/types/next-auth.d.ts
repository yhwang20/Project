import NextAuth from "next-auth";

declare module "next-auth" {
  interface Session {
    user: {
      id: string;
      username: string;
      verified: boolean;
      setupCompelete: boolean;
      userPreferences: userPreferences;
    } & DefaultSession["user"];
  }

  interface User {
    id: string;
    user: string;
    verified: boolean;
    email: string;
    image: string;
    setupComplete: boolean;
    UserPreferences: any;
    Recipes: any;
    FavoritedRecipes: any;
  }
}
