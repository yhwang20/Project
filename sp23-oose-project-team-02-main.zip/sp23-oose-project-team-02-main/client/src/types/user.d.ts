declare module "user-types" {
  export type userPreferences = {
    ingredientsExcluded: string[];
    difficulty: number;
    timeInMins: number;
    vegan: boolean;
    vegetarian: boolean;
    kosher: boolean;
    halal: boolean;
    keto: boolean;
    glutenFree: boolean;
    nonDairy: boolean;
    cuisineTags?: Tag[];
  };

  export type Tag = {
    name: string;
  };

  export type User = {
    username: string;
    password: string;
    email: string;
    role: Role;
    verified: boolean;
    userPreferencesId: string | null;
    image: string;
    googleId: string | null;
    setupComplete: boolean;
    userPreferences: userPreferences;
  };
}
