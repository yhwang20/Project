declare module "recipe-types" {
  export type Recipe = {
    tags: Tag[];
    reviews: Review[];
    id: string;
    name: string;
    background?: string;
    ingredients: string[];
    procedure: string[];
    tools: string[];
    prepTimeInMins: number;
    cookTimeInMins: number | null;
    nutrition: Prisma.JsonValue | null;
    createdAt: Date;
    updatedAt: Date;
    photo: string;
    authorID: string;
    author: any;
    avgRating: number;
    servings: number;
    views: number;
    difficulty: number;
    favoritedBy: User[];
  };

  export type Review = {
    recipeId: string;
    userId: string;
    score: number;
    comment: string;
    recipe: Recipe;
    user: User;
    createdAt: Date;
  };
}
