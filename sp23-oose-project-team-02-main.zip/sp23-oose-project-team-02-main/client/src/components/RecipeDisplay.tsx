"use client";
import React from "react";
import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });
import { Recipe } from "recipe-types";
import styles from "@/app/page.module.css";
import Image from "next/image";
import Loading from "@/app/(WithHeader)/loading";
import AddReview from "./AddReview";
import Review from "./Review";
import HeartToggle from "./HeartToggle";

/* these are the recipe properties we want to use when displaying a recipe */
interface propType {
  recipe: Recipe | undefined;
}

/* Recipe component to display recipes */
export default function RecipeDisplay(props: propType) {
  const recipe = props.recipe;
  if (!recipe) return <Loading />;
  const nutrition = Object.keys(recipe.nutrition).reverse();
  const isEmpty = Object.values(recipe.nutrition).every(
    (x) => x === null || x === ""
  );
  const reviews = recipe.reviews;
  return (
    <main className={styles.bgcmain}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>
      <div className="flex flex-col justify-left md:justify-center md:items-center">
        <div className={inter.className}></div>
        <Image
          src={recipe.photo}
          alt="Picture of the recipe"
          width={0}
          height={0}
          sizes="100vw"
          className="md:mb-5 w-full h-auto md:rounded-lg md:w-1/2 md:h-auto"
        />
        <div className="block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
          <h1 className="font-medium text-gray-600 text-2xl md:text-4xl text-left">
            {recipe.name}
          </h1>
          <div className="flex">
            <Image
              src={recipe.author.image || "/default.png"}
              alt="Picture of the author"
              width={0}
              height={0}
              sizes="100vw"
              className="mt-2 w-10 h-10 rounded-full"
            />
            <h2 className="mt-4 text-sm md:text-md font-semibold ml-2">
              {recipe.author.username}
            </h2>
          </div>

          {recipe.background ? (
            <p className="mt-5 text-gray-700">{recipe.background}</p>
          ) : (
            <></>
          )}
        </div>
        <div className="mt-2 block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
          <div className="flex justify-between">
            <HeartToggle recipe={recipe} />
            <div className={styles.grid2}>
              <h5 className="text-[1rem] justify-center font-semibold">
                Rating: &nbsp;{" "}
              </h5>
              <h6 className="my-[1rem] text-[1rem] justify-center">
                <div className="flex items-center">
                  <svg
                    aria-hidden="true"
                    className="w-5 h-5 text-yellow-400"
                    fill="currentColor"
                    viewBox="0 0 20 20"
                    xmlns="http://www.w3.org/2000/svg"
                  >
                    <title>Rating star</title>
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                  </svg>
                  <p className="ml-2 text-sm font-bold text-gray-900 dark:text-white">
                    {Math.round(recipe.avgRating * 10) / 10}
                  </p>
                  <span className="w-1 h-1 mx-1.5 bg-gray-500 rounded-full dark:bg-gray-400"></span>
                  <a
                    href="#reviews"
                    className="text-sm font-medium text-gray-900 underline hover:no-underline dark:text-white"
                  >
                    {reviews.length} reviews
                  </a>
                </div>
              </h6>
            </div>
          </div>
        </div>
        <div className="mt-2 block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
          <h1 className="font-medium mb-5 text-gray-600 text-xl md:text-3xl text-left">
            Ingredients
          </h1>
          <ul className="divide-y text-gray-600 divide-gray-200 dark:divide-gray-700">
            {recipe.ingredients.map((ingredient, index) => (
              <li key={index} className="text-md md:text-lg text-left py-2">
                <span className="font-bold">{ingredient.split(": ")[1]}</span>{" "}
                {ingredient.split(":")[0]}
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-2 block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
          <h1 className="font-medium mb-5 text-gray-600 text-xl md:text-3xl text-left">
            Tools
          </h1>
          <ul className="divide-y text-gray-600 divide-gray-200 dark:divide-gray-700">
            {recipe.tools.map((tool, index) => (
              <li key={index} className="text-md md:text-lg text-left py-2">
                {tool}
              </li>
            ))}
          </ul>
        </div>
        <div className="mt-2 block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
          <h1 className="font-medium mb-5 text-gray-600 text-xl md:text-3xl text-left">
            Cooking Instructions
          </h1>
          <ol className="divide-y text-gray-600 divide-gray-200 dark:divide-gray-700">
            {recipe.procedure.map((step, index) => (
              <li key={index} className="text-md md:text-lg text-left py-2">
                <span className="font-bold">Step {index + 1}: </span>
                {step}
              </li>
            ))}
          </ol>
        </div>
        {!isEmpty ? (
          <div className="mt-2 block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
            <h1 className="font-medium mb-5 text-gray-600 text-xl md:text-3xl text-left">
              Nutrition Info
            </h1>
            <ol className="divide-y text-gray-600 divide-gray-200 dark:divide-gray-700">
              {nutrition.map((item, index) => (
                <li key={index} className="text-md md:text-lg text-left py-2">
                  <span className="font-bold">{item}: </span>
                  {item === "Calories"
                    ? recipe.nutrition[item]
                    : recipe.nutrition[item] + "g"}
                </li>
              ))}
            </ol>
          </div>
        ) : (
          <></>
        )}
        <div className="mt-2 block max-w-full md:w-1/2 p-6 bg-white border border-gray-200 md:rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 ">
          <h1 className="font-medium mb-5 text-gray-600 text-xl md:text-3xl text-left">
            Tags
          </h1>
          {recipe.tags.map((tag, index) => (
            <span
              key={index}
              className="bg-[#75628e] text-white text-sm font-medium mr-2 px-2.5 py-1 rounded-full dark:bg-green-900 dark:text-green-300"
            >
              {tag.name}
            </span>
          ))}
        </div>
        <div className="text-center text-xl mt-5">
          <h1>Reviews</h1>
        </div>
        <div className="block max-w-full mb-10 md:w-1/2 mt-5 h-auto rounded-2xl bg-white shadow-lg py-0.5">
          <AddReview recipe={recipe} />
        </div>
        <div id="reviews" className="w-full md:justify-center rounded-2xl">
          {reviews.map((review, index) => (
            <Review review={review} key={index} />
          ))}
        </div>
      </div>
    </main>
  );
}
