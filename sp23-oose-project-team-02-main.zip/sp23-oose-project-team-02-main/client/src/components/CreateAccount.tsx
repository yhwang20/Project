"use client";
import React, { Component, useState } from "react";
import "tailwindcss/tailwind.css";
import styles from "../app/page.module.css";
import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });
import { useRouter } from "next/navigation";
import { HiFingerPrint, HiAtSymbol, HiUserCircle } from "react-icons/hi";
import axios from "axios";
import Link from "next/link";
import Image from "next/image";
import { FormikErrors, useFormik } from "formik";
import { createUser } from "../pages/api/userAPI";

interface FormValues {
  email: string;
  username: string;
  password: string;
  confirmPassword: string;
}
// Component to allow user to create account
export default function CreateAccount() {
  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);

  const routing = useRouter();

  const formik = useFormik({
    initialValues: {
      username: "",
      email: "",
      password: "",
      confirmPassword: "",
    },
    validate: (values: FormValues) => {
      let errors = {} as FormikErrors<FormValues>;

      if (!values.username) {
        errors.username = "Required";
      } else if (values.username.length < 3 || values.username.length > 20) {
        errors.username = "Username must be between 3 and 20 characters";
      }

      if (!values.email) {
        errors.email = "Required";
      } else if (
        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
      ) {
        errors.email = "Invalid email address";
      }

      if (!values.password) {
        errors.password = "Required";
      } else if (values.password.length < 6 || values.password.length > 20) {
        errors.password = "Password must be between 6 and 20 characters";
      } else if (values.password.includes(" ")) {
        errors.password = "Password cannot contain spaces";
      }

      if (!values.confirmPassword) {
        errors.confirmPassword = "Required";
      } else if (values.password !== values.confirmPassword) {
        errors.confirmPassword = "Passwords do not match";
      }

      return errors;
    },
    onSubmit,
  });

  async function onSubmit(values: any) {

    await createUser(
      values.username,
      values.email,
      values.password,
      "1990-01-01"
    ).catch((err) => console.log(err));
    routing.push("./user/confirmemail?email=" + values.email);
  }

  return (
    <div className={styles.mainSignIn}>
      <div className={styles.squareLeft}></div>
      <div className={styles.squareRight}></div>

      <div className="w-full max-w-md mb-[-7rem] p-4 bg-white border border-gray-200 rounded-[30px] shadow sm:p-6 md:p-8 dark:bg-gray-800 dark:border-gray-700">
        <div className="title">
          <div className="flex justify-center align-items">
            <Image
              src={"/Logo.svg"}
              width="200"
              height={200}
              alt="logo"
            ></Image>
          </div>
          <h1 className="text-gray-800 text-4xl font-bold text-center py-4">
            Sign Up
          </h1>
          <p className="mx-auto text-gray-400 text-center">
            Create a free account to enjoy all the services without any ads!
          </p>
        </div>

        <form className="flex flex-col gap-5" onSubmit={formik.handleSubmit}>
          <div
            className={`flex border rounded-xl relative mt-4 ${
              formik.errors.username && formik.touched.username
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="text"
              placeholder="Username"
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
              {...formik.getFieldProps("username")}
            />
            <span className="icon flex items-center px-4 stroke-cyan-200">
              <HiUserCircle
                size={25}
                style={{
                  color: "#6366f1",
                }}
              />
            </span>
          </div>

          <div
            className={`flex border rounded-xl relative ${
              formik.errors.email && formik.touched.email
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="email"
              placeholder="Email"
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
              {...formik.getFieldProps("email")}
            />
            <span className="icon flex items-center px-4 stroke-cyan-200">
              <HiAtSymbol
                size={25}
                style={{
                  color: "#6366f1",
                }}
              />
            </span>
          </div>

          <div
            className={`flex border rounded-xl relative ${
              formik.errors.password && formik.touched.password
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type={show ? "text" : "password"}
              placeholder="Password"
              {...formik.getFieldProps("password")}
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
            />
            <span
              className="icon flex items-center px-4"
              onClick={() => setShow(!show)}
            >
              <HiFingerPrint
                size={25}
                style={{
                  color: show ? "#6366f1" : "#CBD5E1",
                }}
              />
            </span>
          </div>
          <div
            className={`flex border rounded-xl relative ${
              formik.errors.confirmPassword && formik.touched.confirmPassword
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type={show ? "text" : "password"}
              placeholder="Confirm Password"
              {...formik.getFieldProps("confirmPassword")}
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
            />
            <span
              className="icon flex items-center px-4"
              onClick={() => setShow(!show)}
            >
              <HiFingerPrint
                size={25}
                style={{
                  color: show ? "#6366f1" : "#CBD5E1",
                }}
              />
            </span>
          </div>
          {error ? (
            <span className="text-center text-rose-600 text-sm"></span>
          ) : null}

          <p className="text-center text-gray-400 text-sm">
            Passwords must be between 6 and 20 characters and cannot contain
            spaces.
          </p>

          <div className="input-button">
            <button
              type="submit"
              className="group relative flex border w-full justify-center rounded-md bg-gradient-to-l from-[#84C7AE] to-[#A7D7C5] py-2 px-3 text-lg font-semibold text-white hover:bg-gradient-to-r hover:from-blue-300 hover:to-indigo-300 hover:border-blue-500 hover:text-gray-700 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Sign Up
            </button>
          </div>
        </form>
        <p className="mt-3 text-center text-gray-400">
          Already Have an Account? &nbsp;
          <Link href="/" className="text-blue-400">
            Go to Dashboard
          </Link>
        </p>
      </div>
    </div>
  );
}
