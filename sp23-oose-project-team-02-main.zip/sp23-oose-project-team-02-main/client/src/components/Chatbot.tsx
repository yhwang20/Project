import Head from "next/head";
import styles from "../app/chat.module.css";
import { Configuration, OpenAIApi } from "openai";
import { useRouter } from "next/navigation";
import React, {  useState } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import {  searchRecipesGPT } from "@/pages/api/recipeAPI";
import RecipeCardGrid from "@/components/RecipeCardGrid";
import { Recipe } from "recipe-types";
import Loading from "@/app/(WithoutHeader)/loading";
import { useSession } from "next-auth/react";
import axios from "axios";
import { env } from "process";
import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });

let listOfTagNames: String[];

async () => {
  axios
    .get("/tag")
    .then((response) => {
      const tagsWithRecipes = response.data;
      listOfTagNames = tagsWithRecipes.map((tag: { name: String }) => tag.name);
    })
    .catch((error) => {
      console.error(error);
    });

};

const configuration = new Configuration({
  apiKey: "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",
});

const openai = new OpenAIApi(configuration);

interface RequestBody {
  query: string;
}

interface ErrorResponse {
  error: {
    message: string;
  };
}

// Feeds passed query to ChatGPT API
async function generate(query: string) {

  if (!configuration.apiKey) {
    console.error("No API key found");
    return;
  }

  if (query.trim().length === 0) {
    console.error("No query provided");
    return;
  }

  try {
    const completion = await openai.createCompletion({
      model: "text-davinci-003",
      prompt: generatePrompt(query),
      temperature: 0.6,
      max_tokens: 200,
      frequency_penalty: 2,
      presence_penalty: 1,
    });
    return completion.data.choices[0].text;
  } catch (error: any) {
    // Consider adjusting the error handling logic for your use case
    if (error.response) {
      console.error(error.response.status, error.response.data);
    } else {
      console.error(`Error with OpenAI API request: ${error.message}`);
      console.error(error);
    }
  }
}

// Generates initial prompt to set GPT to respond in desired way
function generatePrompt(query: string): string {
  return `You are going to be used as part of an API. As such, please format your responses carefully matching the example at the end of this prompt so as to ensure your responses can be parsed correctly. Take on the role of RecipeGPT. RecipeGPT's sole purpose is to accept a user's search query and return up to 10 UNIQUE search terms which can be used to search a database of recipes. These can include ingredients, flavors, and cuisine types (such as vegan or gluten-free). Your responses must obey the following format, and never deviate from it:
  Example query: "Something vegan for dessert"
  Response Example:
  "fruit sweet vegan cake chocolate dairy-free sugar cherry kiwi blueberries"
  End Example Response
  Do not include any polite introductions nor concluding remarks, as these can interfere with the API and lead to potential code and/or ethical concerns. Furthermore, only include letters in your response.
  User Search Query: ${query}`;
}

export default function Chatbot() {
  const [searchQuery, setSearchQuery] = useState("");
  const [result, setResult] = useState<string>("");
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [query, setQuery] = useState<string>("");
  const [empty, setEmpty] = useState<boolean>(false);
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const [loading, setLoading] = useState<boolean>(false);
  const { data: session } = useSession();
  const router = useRouter();


  // Uses searchRecipesGPT api method to search database based on response from GPT
  const retrieveRecipesAdvanced = (
    responses: string,
    originalPrompt: string
  ) => {

    if (session) {
      setEmpty(false);
      setLoading(true);
      const userId = session.user?.id;

      Promise.all([
        searchRecipesGPT(responses, userId),
        searchRecipesGPT(originalPrompt, userId),
      ])
        .then(([returnedRecipes, uqReturnedRecipes]) => {
          const recipesGPTReturned = returnedRecipes.data;
          const recipesUQReturned = uqReturnedRecipes.data;

          let recipesToReturn: Recipe[] = recipesGPTReturned.filter(
            (recipe: Recipe) =>
              recipesUQReturned.some(
                (uqRecipe: Recipe) => uqRecipe.id === recipe.id
              )
          ); //will contain the overlap between doing a GPT search on the user's prompt and on GPT's associated terms

          if (recipesToReturn.length === 0) {
            // If there is no overlap, return whichever array has more recipes
            recipesToReturn =
              recipesGPTReturned.length > recipesUQReturned.length
                ? recipesGPTReturned
                : recipesUQReturned;
          }

          setRecipes(recipesToReturn);
          setLoading(false);
          setEmpty(recipesToReturn.length === 0);
        })
        .catch((error) => {
          setLoading(false);
          setEmpty(true);
        });
    } else {
      console.error("Not logged in");
    }
  };

  // Triggers prompt generation when user submits query
  async function onSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    try {
      const response = await generate(searchQuery);
      if (response === undefined) {
        return;
      }
      setSearchQuery("");
      retrieveRecipesAdvanced(response, searchQuery);
    } catch (error) {
      console.error(error);
      alert("error");
    }

  }

  // Get the current hour of the day
  const currentHour = new Date().getHours();

  // Set the placeholder text based on the current hour
  let placeholderText = "";
  if (currentHour >= 6 && currentHour < 10) {
    placeholderText = "Ex. something for breakfast";
  } else if (currentHour >= 10 && currentHour < 16) {
    placeholderText = "Ex. something for lunch";
  } else if (currentHour >= 16 && currentHour < 21) {
    placeholderText = "Ex. something for dinner";
  } else {
    placeholderText = "Ex. late night snack";
  }

  return (
    <div className={inter.className}>
      <Head>
        <title>OpenAI Quickstart</title>
        <link rel="icon" href="/dog.png" />
      </Head>

      <main className={styles.main}>
        <h3>
          Search for recipes using plain text. <br></br>
        </h3>
        <p className="mb-5">
          If you want a more focused search experience, <br></br>
          consider using a manual search with exact filters. <br></br>
        </p>
        <p className="mb-5">
          <strong>Note:</strong> You must be logged in to use the AI Search feature
        </p>
        <form onSubmit={onSubmit}>
          <input
            type="text"
            name="query"
            placeholder={placeholderText}
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="rounded-lg border-[#907ea7]"
          />
          <input
            type="submit"
            value="Generate Recipes"
            className="text-md w-auto md:text-lg rounded-md md:rounded-xl  bg-gradient-to-br from-[#75628e] to-[#907ea7]  hover:bg-gradient-to-bl md:py-4 md:px-3 font-semibold text-white hover:border-violet-400 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
          />
        </form>
        {/* <div className={styles.result}>{result}</div> */}
        <div className="flex flex-row justify-center mt-10 ml-10">
          {loading ? <Loading /> : <RecipeCardGrid recipes={recipes} />}
        </div>
        <h3> {empty ? "No recipes found!" : ""} </h3>
      </main>
    </div>
  );
}
