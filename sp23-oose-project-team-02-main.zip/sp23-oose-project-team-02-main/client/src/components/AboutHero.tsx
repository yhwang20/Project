import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });


// Component to show mission portion of About page
export default function AboutHero() {
  return (
    <div className={inter.className}>
      <div className="relative isolate px-6 pt-14 lg:px-8">
        <div className="mx-auto max-w-2xl py-32 sm:py-48 lg:py-56">
          <div className="text-center">
            <h1 className="text-4xl font-extrabold tracking-tight text-gray-900 sm:text-6xl md:text-6xl lg:text-8xl">
              Recipe hunting, made easy
            </h1>
            <p className="mt-6 text-lg leading-8 text-gray-600 md:text-xl lg:text-2xl">
              Our mission at ReciPlease is to empower inexperienced cooks to
              prepare delicious and healthy meals with ease.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
