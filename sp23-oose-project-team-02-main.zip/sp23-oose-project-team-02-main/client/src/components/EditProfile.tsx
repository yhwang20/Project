"use client";
import React, { useState, useEffect } from "react";
import "tailwindcss/tailwind.css";
import { FormikErrors, useFormik } from "formik";
import { updateUser } from "../pages/api/userAPI";
import { useSession } from "next-auth/react";

interface FormValues {
  username: string;
  image: string;
}

type editProfileProps = {
  setModalState: React.Dispatch<React.SetStateAction<boolean>>;
};

export default function EditProfile(props: editProfileProps) {
  const [error, setError] = useState(false);
  const { setModalState } = props;
  const { data: session } = useSession();
  const formik = useFormik({
    initialValues: {
      username: session?.user.username,
      image: "",
    },
    onSubmit,
  });

  async function onSubmit(values: any) {
    const status = await updateUser(session?.user.id, {
      username: values.username,
      image: values.image,
    });
    console.log(status);
    if (status && status.ok) {
      setModalState(false);
    } else if (status && !status.ok) {
      setError(true);
    }
  }

  return (
    <>
      <section className="w-3/4 mx-auto flex flex-col gap-10">
        <div className="title">
          <h1 className="text-gray-800 text-4xl font-bold text-center py-4">
            Edit Profile
          </h1>
        </div>

        <form className="flex flex-col gap-5" onSubmit={formik.handleSubmit}>
          <div>
            <label
              className="block mb-2 text-md font-medium text-gray-900 dark:text-white"
              form="file_input"
            >
              New profile photo: Upload file
            </label>
            <input
              className="block w-full text-sm text-gray-900 border border-gray-300 rounded-lg cursor-pointer bg-gray-50 dark:text-gray-400 focus:outline-none dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400"
              aria-describedby="file_input_help"
              id="file_input"
              type="file"
              {...formik.getFieldProps("image")}
            ></input>
            <p
              className="mt-1 text-sm text-gray-500 dark:text-gray-300"
              id="file_input_help"
            >
              JPG or PNG.
            </p>
          </div>
          <div className="text-md font-medium">New username: </div>
          <div
            className={`flex border rounded-xl relative ${
              formik.errors.username && formik.touched.username
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="username"
              placeholder="Username"
              {...formik.getFieldProps("username")}
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
            />
          </div>
          <div className="input-button">
            <button
              type="submit"
              className="group relative flex w-full justify-center rounded-2xl bg-gradient-to-r from-emerald-400 to-emerald-500 py-2 px-3 text-lg font-semibold text-white hover:bg-gradient-to-r hover:from-blue-300 hover:to-indigo-300 hover:border-blue-500 hover:text-gray-700 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Save changes
            </button>
          </div>
        </form>
      </section>
    </>
  );
}
