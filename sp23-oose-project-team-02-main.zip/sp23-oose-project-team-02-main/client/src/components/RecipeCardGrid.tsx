import React, { Suspense } from "react";
import RecipeCard from "./RecipeCard";
import { Recipe } from "recipe-types";
import Loading from "@/app/(WithHeader)/loading";

interface CardGridProps {
  recipes: Recipe[];
}

function RecipeCardGrid(props: CardGridProps) {
  const recipes = props.recipes;

  return (
    <>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {recipes.map((recipe) => (
          <RecipeCard key={recipe.id} recipe={recipe} />
        ))}
      </div>
    </>
  );
}

export default RecipeCardGrid;
