"use client";

import React, { useEffect, useState } from "react";
import RecipesNavbar from "./RecipesNavbar";
import RecipeListItem from "./RecipeListItem";
import { Recipe } from "recipe-types";
import { useSession } from "next-auth/react";
import { getUser } from "@/pages/api/userAPI";
import Loading from "@/app/(WithHeader)/loading";

function UserFavorites() {
  const { data: session } = useSession();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  useEffect(() => {
    const retrieveUser = async () => {
      if (session) {
        setIsLoading(true);
        const user = await getUser(session.user.id);
        setIsLoading(false);
        return user;
      }
    };
    retrieveUser().then((user) => {
      if (user) {
        setRecipes(user.favoritedRecipes);
      }
    });
  }, [session]);
  return (
    <div className="flex flex-col justify-center items-center">
      <RecipesNavbar isRecipes={false} />
      <ul className="max-w-2/5 w-2/5 divide-y divide-gray-200 dark:divide-gray-700 mt-5 block min-w-1/2 p-6 bg-white border border-gray-200 rounded-lg shadow  dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
        {isLoading ? (
          <Loading />
        ) : recipes.length !== 0 ? (
          recipes.map((recipe, index) => (
            <RecipeListItem recipe={recipe} key={index} />
          ))
        ) : (
          <p className="text-center">
            You haven&apos;t favorited any recipes yet!
          </p>
        )}
      </ul>
    </div>
  );
}

export default UserFavorites;
