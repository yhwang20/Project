import React from "react";

type ToggleButtonProps = {
  children: React.ReactNode;
  onClick: () => void;
  toggled: boolean;
};

export default function ToggleButton({
  children,
  onClick,
  toggled,
}: ToggleButtonProps) {
  const backgroundColor = toggled ? "#84C7AE" : "#f2f2f2";
  const color = toggled ? "#fff" : "#000";
  return (
    <button
      style={{
        width: "auto",
        height: "auto",
        backgroundColor,
        border: "1px solid #ccc",
        color,
        padding: "5px 20px",
        borderRadius: "20px",
        marginRight: "20px",
        marginTop: "20px",
      }}
      onClick={onClick}
    >
      {children}
    </button>
  );
}
