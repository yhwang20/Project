"use client";
import React, { useEffect } from "react";
import styles from "@/app/page.module.css";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useSession } from "next-auth/react";
import axios from "axios";

function SetupComplete() {
  const { data: session, update } = useSession();
  const routing = useRouter();

  useEffect(() => {
    if (session?.user.setupComplete) {
      routing.push("/");
    }
  }, [session]);

  const onClick = async () => {
    const userID = session?.user.id;
    update({ setupComplete: true });
    await axios
      .put(`https://reciplease-server.onrender.com/users/${userID}`, {
        setupComplete: true,
      })
      .then((res) => {
        console.log(res.data);
        routing.push("/");
      });
  };

  return (
    <div className={styles.mainSignIn}>
      <div className={styles.squareLeft}></div>
      <div className={styles.squareRight}></div>

      <div className="w-full max-w-xl p-6 bg-white border border-gray-200 rounded-xl shadow dark:bg-gray-800 dark:border-gray-700">
        <div className="title">
          <div className="flex justify-center align-items">
            <Image
              src={"/Logo.svg"}
              width="200"
              height={200}
              alt="logo"
            ></Image>
          </div>
          <h1 className="text-gray-800 text-4xl text-center py-4 font-bold">
            Congratulations!
          </h1>
        </div>
        <div>
          <h2 className="text-gray-500 text-center my-5 text-lg">
            Your account has been set up!
          </h2>
        </div>
        <div className="flex justify-center">
          <button
            type="button"
            onClick={onClick}
            className="text-white border bg-[#84C7AE] hover:bg-[#51b38f] focus:outline-none font-medium rounded-[20px] text-xl mt-10 px-16 py-3 text-center"
          >
            Take me there!
          </button>
        </div>
      </div>
    </div>
  );
}

export default SetupComplete;
