import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });
const people = [
  {
    name: "Joy Neuberger",
    imageUrl: "https://i.imgur.com/vMCTTLA.jpg",
  },
  {
    name: "Francis Durso",
    imageUrl: "https://i.imgur.com/AoKUQXn.png",
  },
  {
    name: "Shalom Cesar",
    imageUrl: "https://i.imgur.com/dW2GVGv.jpg",
  },
  {
    name: "Andy Venancio-Torres",
    imageUrl: "https://i.imgur.com/g3VZrrm.jpg",
  },
  {
    name: "Ireland Parrish",
    imageUrl: "https://i.imgur.com/wDRMIBI.jpg",
  },
  {
    name: "Sky Li",
    imageUrl: "https://i.imgur.com/pansBCx.jpg",
  },
  {
    name: "Yusoo Hwang",
    imageUrl: "https://i.imgur.com/35TId6K.jpg",
  },

  // More people...
];

// Component to show headshots and team info portion of About page
export default function OurTeam() {
  return (
    <div className={inter.className}>
      <div className="py-24 sm:py-32">
        <div className="mx-auto grid max-w-7xl gap-x-8 gap-y-20 px-6 lg:px-8 xl:grid-cols-3">
          <div className="max-w-2xl">
            <h2 className="text-3xl font-bold tracking-tight text-gray-900 sm:text-4xl md:text-4xl lg:text-5xl">
              Meet our team
            </h2>
            <p className="mt-6 text-lg mr-6 leading-8 text-gray-600 md:text-lg lg:text-xl">
              The ReciPlease team consists of seven Johns Hopkins University
              undergraduate students.
            </p>
          </div>
          <ul
            role="list"
            className="grid gap-x-12 gap-y-12 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-3 sm:gap-y-16 xl:col-span-2"
          >
            {people.map((person) => (
              <li key={person.name}>
                <div className="flex items-center gap-x-6">
                  <img
                    className="h-16 w-16 rounded-full"
                    src={person.imageUrl}
                    alt=""
                  />
                  <div>
                    <h3 className="text-lg font-semibold leading-7 tracking-tight text-gray-900">
                      {person.name}
                    </h3>
                  </div>
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
