"use client";
import React, { useState, useEffect } from "react";
import { useSession } from "next-auth/react";
import { Recipe } from "recipe-types";
import { getUser } from "@/pages/api/userAPI";

import RecipesNavbar from "./RecipesNavbar";
import EditableRecipeItem from "./EditableRecipeItem";
import Loading from "@/app/(WithHeader)/loading";

function UserRecipes() {
  const { data: session } = useSession();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [isLoading, setIsLoading] = useState<boolean>(false);

  const handleDelete = (deletedRecipeId: string) => {
    setRecipes(() => recipes.filter((recipe) => recipe.id !== deletedRecipeId));
  };

  useEffect(() => {
    const retrieveUser = async () => {
      if (session) {
        setIsLoading(true);
        const user = await getUser(session.user.id);
        setIsLoading(false);
        return user;
      }
    };
    retrieveUser().then((user) => {
      if (user) {
        setRecipes(user.userRecipes);
      }
    });
  }, [session]);
  return (
    <div>
      <div className="flex flex-col justify-center items-center">
        <RecipesNavbar isRecipes={true} />
        <ul className="max-w-2/5 w-2/5 divide-y divide-gray-200 dark:divide-gray-700 mt-5 block min-w-1/2 p-6 bg-white border border-gray-200 rounded-lg shadow  dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
          {isLoading ? (
            <Loading />
          ) : recipes.length !== 0 ? (
            recipes.map((recipe, index) => (
              <EditableRecipeItem
                recipe={recipe}
                key={index}
                handleDelete={handleDelete}
              />
            ))
          ) : (
            <p className="text-center">
              You haven&apos;t created any recipes yet!
            </p>
          )}
        </ul>
      </div>
    </div>
  );
}

export default UserRecipes;
