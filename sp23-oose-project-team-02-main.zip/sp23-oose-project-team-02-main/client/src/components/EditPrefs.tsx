"use client";
import React, { useState, useEffect } from "react";
import "tailwindcss/tailwind.css";
import { FormikErrors, useFormik } from "formik";
import { updatedUserPreference } from "@/pages/api/userAPI";
import { useSession } from "next-auth/react";
import { Tag, userPreferences } from "user-types";

interface FormValues {
  ingredientsExcluded?: string[];
  difficulty?: number;
  vegan?: boolean;
  vegetarian?: boolean;
  kosher?: boolean;
  halal?: boolean;
  keto?: boolean;
  glutenFree?: boolean;
  nonDairy?: boolean;
  cuisineString: string;
  timeInMins?: number;
}

type editPrefProps = {
  setModalState: React.Dispatch<React.SetStateAction<boolean>>;
  userPreferences: userPreferences | undefined;
  setUserPreferences: React.Dispatch<
    React.SetStateAction<userPreferences | undefined>
  >;
};

export default function EditPrefs(props: editPrefProps) {
  const [error, setError] = useState(false);
  const { setModalState, userPreferences, setUserPreferences } = props;
  const { data: session } = useSession();
  let cuisineTags: Tag[] = [];

  const formik = useFormik({
    initialValues: {
      ingredientsExcluded: userPreferences?.ingredientsExcluded,
      difficulty: userPreferences?.difficulty,
      vegan: userPreferences?.vegan,
      vegetarian: userPreferences?.vegetarian,
      kosher: userPreferences?.kosher,
      halal: userPreferences?.halal,
      nonDairy: userPreferences?.nonDairy,
      glutenFree: userPreferences?.glutenFree,
      keto: userPreferences?.keto,
      cuisineString: userPreferences?.cuisineTags
        ? userPreferences?.cuisineTags.join(",")
        : "",

      timeInMins: userPreferences?.timeInMins,
    },
    validate: (values: FormValues) => {
      let errors = {} as FormikErrors<FormValues>;
      return errors;
    },
    onSubmit,
    enableReinitialize: true,
  });

  function onSubmit(values: FormValues) {
    const cuisineArr = values.cuisineString?.split(",");
    const cuisineTags: Tag[] = cuisineArr.map((cuisine: string) => {
      return {
        name: cuisine,
      } as Tag;
    });
    console.log(cuisineTags);
    updatedUserPreference(session?.user.id, {
      ingredientsExcluded: values.ingredientsExcluded,
      vegan: values.vegan,
      vegetarian: values.vegetarian,
      kosher: values.kosher,
      glutenFree: values.glutenFree,
      nonDairy: values.nonDairy,
      halal: values.halal,
      keto: values.keto,
      difficulty: values.difficulty,
      timeInMins: values.timeInMins,
      cuisineTags: cuisineTags,
    })
      .then((res) => {
        setModalState(false);
        setUserPreferences(res.data);
      })
      .catch((err) => {
        setError(true);
      });
  }

  return (
    <>
      <section className="w-3/4 mx-auto flex flex-col">
        <div className="title">
          <h1 className="text-[#463a55] text-4xl font-bold text-center py-4">
            Edit Preferences
          </h1>
        </div>

        <form className="flex flex-col gap-3" onSubmit={formik.handleSubmit}>
          <div className="text-md text-[#463a55] font-medium">
            Disliked Ingredients:{" "}
          </div>
          <div
            className={`flex border rounded-xl relative ${
              formik.errors.ingredientsExcluded &&
              formik.touched.ingredientsExcluded
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="text"
              placeholder="Disliked Ingredients"
              {...formik.getFieldProps("ingredientsExcluded")}
              className="w-full py-2 px-4 border rounded-xl focus:outline-none border-none"
            />
          </div>
          <div className="text-md text-[#463a55] font-medium">
            Preferred Total Cook Time (Mins):{" "}
          </div>

          <div
            className={`flex border rounded-xl relative ${
              formik.errors.timeInMins && formik.touched.timeInMins
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="number"
              placeholder={formik.initialValues.timeInMins?.toString()}
              {...formik.getFieldProps("timeInMins")}
              className="w-full py-2 px-4 border rounded-xl focus:outline-none border-none"
            />
          </div>
          <div className="text-md text-[#463a55] font-medium">Difficulty: </div>

          <div
            className={`flex border rounded-xl relative ${
              formik.errors.difficulty && formik.touched.difficulty
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              id="steps-range"
              type="range"
              min="1"
              max="5"
              step="1"
              {...formik.getFieldProps("difficulty")}
              className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer dark:bg-gray-700"
            />
          </div>

          <div className="text-md text-[#463a55] font-medium">
            Vegan:
            <input
              id="default-checkbox"
              type="checkbox"
              checked={formik.values.vegan}
              {...formik.getFieldProps("vegan")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.vegan && formik.touched.vegan
                ? "border-rose-600"
                : ""
            }`}
          ></div>

          <div className="text-md text-[#463a55] font-medium">
            Vegetarian:
            <input
              id="default-checkbox"
              type="checkbox"
              checked={formik.values.vegetarian}
              {...formik.getFieldProps("vegetarian")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.vegetarian && formik.touched.vegetarian
                ? "border-rose-600"
                : ""
            }`}
          ></div>

          <div className="text-md text-[#463a55] font-medium">
            Kosher:
            <input
              id="default-checkbox"
              type="checkbox"
              checked={formik.values.kosher}
              {...formik.getFieldProps("kosher")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.kosher && formik.touched.kosher
                ? "border-rose-600"
                : ""
            }`}
          ></div>

          <div className="text-md text-[#463a55] font-medium">
            Halal:
            <input
              id="default-checkbox"
              type="checkbox"
              {...formik.getFieldProps("halal")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.halal && formik.touched.halal
                ? "border-rose-600"
                : ""
            }`}
          ></div>

          <div className="text-md text-[#463a55] font-medium">
            Keto:
            <input
              id="default-checkbox"
              type="checkbox"
              checked={formik.values.keto}
              {...formik.getFieldProps("keto")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 focus:ring-2"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.keto && formik.touched.keto ? "border-rose-600" : ""
            }`}
          ></div>

          <div className="text-md font-medium">
            Gluten-Free:
            <input
              id="default-checkbox"
              type="checkbox"
              checked={formik.values.glutenFree}
              {...formik.getFieldProps("glutenFree")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.glutenFree && formik.touched.glutenFree
                ? "border-rose-600"
                : ""
            }`}
          ></div>
          <div className="text-md font-medium">
            Dairy-Free:
            <input
              id="default-checkbox"
              type="checkbox"
              checked={formik.values.nonDairy}
              {...formik.getFieldProps("nonDairy")}
              className="w-5 h-5 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
            ></input>
          </div>
          <div
            className={`flex relative ${
              formik.errors.nonDairy && formik.touched.nonDairy
                ? "border-rose-600"
                : ""
            }`}
          ></div>
          {/*  <div className="text-md font-medium">Cuisines: </div>
          <div
            className={`flex border rounded-xl relative ${
              formik.errors.cuisineString && formik.touched.cuisineString
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="cuisineTags"
              placeholder="Cuisines"
              {...formik.getFieldProps("cuisineString")}
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
            />
          </div> */}

          <div className="input-button">
            <button
              type="submit"
              className="group mt-3 relative flex w-full justify-center rounded-2xl bg-gradient-to-r from-[#75628e] to-[#907ea7] py-2 px-3 text-lg font-semibold text-white hover:bg-gradient-to-r hover:from-blue-300 hover:to-indigo-300 hover:border-blue-500 hover:text-gray-700 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Save changes
            </button>
          </div>
        </form>
      </section>
    </>
  );
}
