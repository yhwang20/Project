import styles from "../app/page.module.css";

// Title functional component
// returns title card with given text
const Title: React.FC = () => {
  return (
    <div className={styles.center}>
      <a className="block max-w-sm p-6 bg-white border border-gray-200 rounded-lg shadow">
        <h5 className="mb-2 text-2xl font-bold tracking-tight text-gray-800">
          ReciPlease
        </h5>
      </a>
    </div>
  );
};

export default Title;
