"use client";
import "tailwindcss/tailwind.css";
import { useState, useEffect } from "react";
import {
  FormControl,
  InputLabel,
  Select,
  MenuItem,
  SelectChangeEvent,
} from "@mui/material";
import { Inter } from "@next/font/google";

const inter = Inter({ subsets: ["latin"] });

export interface DropdownProps {
  options: string[];
  title: string;
  selectedOption: string;
  setSelectedOption: any;
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 180,
    },
  },
};

// Dropdown component,
// accepts dropdown title, options, parent state variable and setter as props
function Dropdown(props: DropdownProps) {
  const { title, options, selectedOption, setSelectedOption } = props;

  const handleOptionClick = async (event: SelectChangeEvent) => {
    await setSelectedOption(event.target.value);
  };

  return (
    <main className="">
      <div className={inter.className}>
        <FormControl sx={{ m: 1, minWidth: 155 }}>
          <InputLabel id="demo-simple-select-filled-label">{title}</InputLabel>
          <Select
            labelId="demo-simple-select-filled-label"
            id="demo-simple-select-filled"
            value={selectedOption}
            onChange={handleOptionClick}
            className="bg-white"
            MenuProps={MenuProps}
          >
            {options.map((option: string) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
    </main>
  );
}

export default Dropdown;
