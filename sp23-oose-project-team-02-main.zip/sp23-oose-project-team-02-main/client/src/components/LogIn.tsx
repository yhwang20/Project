"use client";
import React, { ReactNode, Component, useState, useEffect } from "react";
import "tailwindcss/tailwind.css";
import { useRouter } from "next/navigation";
import Link from "next/link";
import axios from "axios";
import { useSession, signIn, signOut, SignInResponse } from "next-auth/react";
import { HiFingerPrint, HiAtSymbol } from "react-icons/hi";
import Image from "next/image";
import { FormikErrors, useFormik } from "formik";
import { Session } from "next-auth";

interface FormValues {
  email: string;
  password: string;
}

type LoginProps = {
  setModalState: React.Dispatch<React.SetStateAction<boolean>>;
};

export default function LogIn(props: LoginProps) {
  const [show, setShow] = useState(false);
  const [error, setError] = useState(false);
  const router = useRouter();
  const { setModalState } = props;
  let invalidText = "Invalid email or password";
  const formik = useFormik({
    initialValues: {
      email: "",
      password: "",
    },
    validate: (values: FormValues) => {
      let errors = {} as FormikErrors<FormValues>;

      if (!values.email) {
        errors.email = "Required";
      } else if (
        !/^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,4}$/i.test(values.email)
      ) {
        errors.email = "Invalid email address";
      }

      if (!values.password) {
        errors.password = "Required";
      } else if (values.password.length < 6 || values.password.length > 20) {
        errors.password = "Password must be between 6 and 20 characters";
      } else if (values.password.includes(" ")) {
        errors.password = "Password cannot contain spaces";
      }

      return errors;
    },
    onSubmit,
  });

  async function onSubmit(values: any) {
    const status = await signIn("email-login", {
      redirect: false,
      email: values.email,
      password: values.password,
      callbackUrl: "/",
    });
    if (status && status.ok) {
      setModalState(false);
      router.push("/");
    } else if (status && !status.ok) {
      setError(true);
    }
  }

  function handleGoogleSignin(): void {
    signIn("google", {
      callbackUrl: "/",
    });
  }

  function handleFacebookSignin(): void {
    signIn("facebook", { callbackUrl: "/" });
  }

  return (
    <>
      <section className="w-3/4 mx-auto flex flex-col gap-10">
        <div className="title">
          <h1 className="text-gray-800 text-4xl font-bold text-center py-4">
            Log In
          </h1>
          <p className="mx-auto text-gray-400 text-center">
            Create an account to save your preferences and access your
            dashboard.
          </p>
        </div>

        <form className="flex flex-col gap-5" onSubmit={formik.handleSubmit}>
          {/* <div
            className={`flex border rounded-xl relative ${
              formik.errors.password && formik.touched.password
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type="email"
              placeholder="Email"
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
              {...formik.getFieldProps("email")}
            />
            <span className="icon flex items-center px-4 stroke-cyan-200">
              <HiAtSymbol
                size={25}
                style={{
                  color: "#6366f1",
                }}
              />
            </span>
          </div> */}

          {/* <div
            className={`flex border rounded-xl relative ${
              formik.errors.email && formik.touched.email
                ? "border-rose-600"
                : ""
            }`}
          >
            <input
              type={show ? "text" : "password"}
              placeholder="Password"
              {...formik.getFieldProps("password")}
              className="w-full py-2 px-6 border rounded-xl focus:outline-none border-none"
            />
            <span
              className="icon flex items-center px-4"
              onClick={() => setShow(!show)}
            >
              <HiFingerPrint
                size={25}
                style={{
                  color: show ? "#6366f1" : "#CBD5E1",
                }}
              />
            </span>
          </div> */}
          {/* {error ? (
            <span className="text-center text-rose-600 text-sm">
              {invalidText}
            </span>
          ) : null} */}

          {/* <div className="input-button">
            <button
              type="submit"
              className="group relative flex w-full justify-center rounded-md bg-gradient-to-r from-[#75628e] to-[#907ea7] py-2 px-3 text-lg font-semibold text-white hover:bg-gradient-to-r hover:from-blue-300 hover:to-indigo-300 hover:border-blue-500 hover:text-gray-700 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
            >
              Login
            </button>
          </div> */}
          <div className="input-button">
            <button
              type="button"
              onClick={handleGoogleSignin}
              className="w-full border py-3 flex rounded-md justify-center gap-2 hover:bg-gray-200"
            >
              Sign In with Google{" "}
              <Image src={"/google.svg"} width="20" height={20} alt="google" />
            </button>
          </div>
        </form>
        {/* <p className="text-center text-gray-400">
          Don&apos;t have an account?{" "}
          <Link
            href="/user/createaccount"
            onClick={() => setModalState(false)}
            className="text-blue-400"
          >
            Sign Up
          </Link>
        </p> */}
      </section>
    </>
  );
}
