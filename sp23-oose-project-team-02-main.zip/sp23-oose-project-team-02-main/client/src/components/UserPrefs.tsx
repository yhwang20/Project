"use client";
import React, { useState, useEffect } from "react";
import "tailwindcss/tailwind.css";
import { Inter } from "@next/font/google";
import styles from "../app/page.module.css";
import { HiThumbDown, HiThumbUp } from "react-icons/hi";
const inter = Inter({ subsets: ["latin"] });
import { useSession } from "next-auth/react";
import { getUser } from "@/pages/api/userAPI";
import { userPreferences } from "user-types";
import { Modal } from "flowbite-react";
import EditPrefs from "./EditPrefs";

const difficultyConverter = (difficulty: number | undefined) => {
  switch (difficulty) {
    case 1:
      return "Beginner";
    case 2:
      return "Easy";
    case 3:
      return "Medium";
    case 4:
      return "Hard";
    case 5:
      return "Pro";
    default:
      return "Beginner";
  }
};

export default function UserPrefs() {
  const { data: session } = useSession();
  const [preferences, setPreferences] = useState<userPreferences>();
  const [modalState, setModalState] = useState(false);
  const [isBrowser, setIsBrowser] = useState(false);

  useEffect(() => {
    setIsBrowser(typeof window !== "undefined");
  }, []);

  function clickHandler() {
    setModalState(true);
  }

  const onClose = () => {
    setModalState(false);
  };

  useEffect(() => {
    const retrieveUserPrefs = async () => {
      if (session) {
        const retrievedUser = await getUser(session?.user.id);
        setPreferences(retrievedUser?.userPreferences);
      }
    };
    retrieveUserPrefs();
  }, [session]);

  return (
    <>
      {isBrowser ? (
        <React.Fragment>
          <Modal show={modalState} size="lg" popup={true} onClose={onClose}>
            <Modal.Header />
            <Modal.Body>
              <EditPrefs
                setModalState={setModalState}
                userPreferences={preferences}
                setUserPreferences={setPreferences}
              />
            </Modal.Body>
          </Modal>
        </React.Fragment>
      ) : (
        <> </>
      )}
      <div className={inter.className}>
        <div className="block max-w-xl 2xl:px-28 px-10 rounded-xl bg-white shadow-lg py-0.5">
          <h5 className="mb-10 mt-5 justify-center text-center text-[2rem] font-bold text-[#463a55]">
            Preferences
          </h5>
          {session ? (
            <div>
              <div style={{ display: "flex", justifyContent: "center" }}>
                <span className="icon flex mx-2">
                  <HiThumbDown size={25} style={{ color: "#4C826E" }} />
                  <p className="mb-6 mx-2 text-lg font-normal text-gray-500">
                    <strong className="font-semibold text-[#463a55]">
                      Disliked ingredients: &nbsp;
                    </strong>
                    {preferences?.ingredientsExcluded.length != 0
                      ? preferences?.ingredientsExcluded?.join(", ")
                      : "None"}
                  </p>
                </span>
              </div>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">
                  Preferred Total Cooking Time:{" "}
                </strong>
                {preferences?.timeInMins &&
                preferences?.timeInMins !== 2147483647
                  ? preferences.timeInMins
                  : "No preference"}
              </p>
              <p className="mb-5  text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">
                  Preferred Difficulty:{" "}
                </strong>
                {difficultyConverter(preferences?.difficulty)}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">
                  Vegan:{" "}
                </strong>
                {preferences?.vegan.toString() === "true" ? "True" : "False"}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">
                  Vegetarian:{" "}
                </strong>
                {preferences?.vegetarian.toString() === "true"
                  ? "True"
                  : "False"}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">
                  Kosher:{" "}
                </strong>
                {preferences?.kosher.toString() === "true" ? "True" : "False"}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">
                  Halal:{" "}
                </strong>
                {preferences?.halal.toString() === "true" ? "True" : "False"}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-[#463a55]">Keto: </strong>
                {preferences?.keto.toString() === "true" ? "True" : "False"}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-gray-900">
                  Dairy-Free:{" "}
                </strong>
                {preferences?.nonDairy.toString() === "true" ? "True" : "False"}
              </p>
              <p className="mb-5 text-lg font-normal text-center text-gray-500">
                <strong className="font-semibold text-gray-900">
                  Gluten-Free:{" "}
                </strong>
                {preferences?.glutenFree.toString() === "true"
                  ? "True"
                  : "False"}
              </p>

              <div className={styles.center}>
                <button
                  onClick={clickHandler}
                  type="button"
                  className="text-white w-60 bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl focus:ring-3 focus:outline-none focus:ring-green-200 dark:focus:ring-green-800 font-semibold rounded-2xl text-lg px-5 py-2.5 text-center mb-5"
                >
                  Change Preferences
                </button>
              </div>
            </div>
          ) : (
            <div>
              <div>
                <h1 className="text-center font-semibold text-lg">
                  {" "}
                  Sign in to view preferences
                </h1>
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
}
