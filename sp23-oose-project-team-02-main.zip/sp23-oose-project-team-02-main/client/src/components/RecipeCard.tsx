"use client";
import { Card } from "flowbite-react";
import Image from "next/image";
import Link from "next/link";
import React from "react";
import { Recipe } from "recipe-types";

type RecipeCardProps = {
  recipe: Recipe;
};

function RecipeCard(props: RecipeCardProps) {
  const { recipe } = props;
  return (
    <>
      <div className="m-w-[375px] w-[375px] md:w-[375px]">
        <Link href={`/recipe/${recipe.id}`}>
          <Card className="rounded-xl m-h-[400px] h-[400px] md:h-[400px] m-w-[375px] w-[375px] md:w-[375px]">
            <div className="relative w-[325px] h-[200px]">
              <Image
                style={{ objectFit: "cover" }}
                src={recipe.photo}
                alt="Recipe Picture"
                fill
                className="rounded-xl"
              />
            </div>
            <span className="flex flex-row justify-center">
              <div className="ml-ss4">
                <h6 className="mt-1.5 text-[1rem] justify-center">
                  <div className="flex items-center">
                    <svg
                      aria-hidden="true"
                      className="w-5 h-5 text-yellow-400"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                      xmlns="http://www.w3.org/2000/svg"
                    >
                      <title>Rating star</title>
                      <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path>
                    </svg>
                    <p className="ml-2 text-sm font-bold text-[#463a55] dark:text-white">
                      {Math.round(recipe.avgRating * 10) / 10}
                    </p>
                  </div>
                </h6>
              </div>
              <p className="mt-1 ml-5 text-[#463a55]">
                <b>Time: </b> {recipe.prepTimeInMins + recipe.cookTimeInMins!}{" "}
                minutes
              </p>
              {recipe.difficulty === 1 ? (
                <div className="[word-wrap: break-word] ml-6 justify-center font-semibold flex h-[32px] items-center w-[100px] rounded-[16px] bg-[#a7acd9] text-white">
                  Beginner
                </div>
              ) : recipe.difficulty === 2 ? (
                <div className="[word-wrap: break-word] ml-6 justify-center font-semibold flex h-[32px] items-center w-[100px] rounded-[16px] bg-[#878ecb] text-white">
                  Easy
                </div>
              ) : recipe.difficulty === 3 ? (
                <div className="[word-wrap: break-word] ml-6 justify-center font-semibold flex h-[32px] items-center w-[100px] rounded-[16px] bg-[#5660b6] text-white">
                  Medium
                </div>
              ) : recipe.difficulty === 4 ? (
                <div className="[word-wrap: break-word] ml-6 justify-center font-semibold flex h-[32px] items-center w-[100px] rounded-[16px] bg-[#3c448b] text-white">
                  Hard
                </div>
              ) : (
                <div className="[word-wrap: break-word] ml-6 justify-center font-semibold flex h-[32px] items-center w-[100px] rounded-[16px] bg-[#323974] text-white">
                  Pro
                </div>
              )}
            </span>
            <h5 className="text-xl font-bold text-center tracking-tight text-[#463a55] dark:text-white">
              {recipe.name}
            </h5>
          </Card>
        </Link>
      </div>
    </>
  );
}

export default RecipeCard;
