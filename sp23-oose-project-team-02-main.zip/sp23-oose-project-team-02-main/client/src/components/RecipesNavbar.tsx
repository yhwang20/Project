import Link from "next/link";
import React from "react";

function RecipesNavbar({ isRecipes }: { isRecipes: boolean }) {
  return (
    <div className="flex flex-col justify-center items-center w-full mt-30">
      <div className="w-2/5">
        <div className="mb-sm bg-white sm:rounded-md shadow-xs mt-sm">
          <ul className="justify-center mb-xs py-3 text-12 sm:text--14 text-gray-500 flex  whitespace-nowrap">
            <li
              aria-selected={isRecipes}
              className={
                isRecipes
                  ? `inline-block mr-40 font-semibold text-gray-700 border-b-2 border-[#75628e]`
                  : `inline-block mr-40`
              }
            >
              <Link
                className="tracking-wider block hover:text-gray-700 p-sm xs:p-rg"
                href="/user/me/recipes"
              >
                Your Recipes
              </Link>
            </li>

            <li
              aria-selected={!isRecipes}
              className={
                !isRecipes
                  ? `inline-block font-semibold text-gray-700 border-b-2 border-[#75628e]`
                  : `inline-block`
              }
            >
              <Link
                className="tracking-wider block hover:text-gray-700 p-sm xs:p-rg"
                href="/user/me/favorites"
              >
                Saved
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </div>
  );
}

export default RecipesNavbar;
