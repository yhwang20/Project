import React, { useEffect, useState } from "react";
import "tailwindcss/tailwind.css";
import MultiSelect from "../components/MultiSelect";
import Chrono from "../components/Chrono";
import { AiOutlineClose } from "react-icons/ai";
import { Inter } from "@next/font/google";
import Dropdown from "../components/Dropdown";

const inter = Inter({ subsets: ["latin"] });

export interface MyModalProps {
  visible: boolean;
  includeTags: string[];
  excludeTags: string[];
  includeIngredients: string[];
  excludeIngredients: string[];
  setIncludeTags: Function;
  setExcludeTags: Function;
  setIncludeIngredients: Function;
  setExcludeIngredients: Function;
  currCookingTime: string;
  currPrepTime: string;
  currRating: string;
  currDifficulty: string;
  updateCookingTime: Function;
  updatePrepTime: Function;
  updateRating: Function;
  updateDifficulty: Function;
  onClose: (applyFilter: boolean) => void;
  handleSearch: () => void;
  handleIgnore: Function;
}

// Returns an element that is in one array but not in the other array
function difference(arr1: string[], arr2: string[]) {
  return arr1.filter((x) => !arr2.includes(x));
}

// Component defining advanced filter pane modal, used in results and landing page
export default function MyModal({
  visible,
  includeTags,
  excludeTags,
  includeIngredients,
  excludeIngredients,
  setIncludeTags,
  setExcludeTags,
  setIncludeIngredients,
  setExcludeIngredients,
  currCookingTime,
  currPrepTime,
  currRating,
  currDifficulty,
  updateCookingTime,
  updatePrepTime,
  updateRating,
  updateDifficulty,
  onClose,
  handleSearch,
  handleIgnore,
}: MyModalProps) {
  const [tagInput, setTagInput] = useState("");
  const [ingredientInput, setIngredientInput] = useState("");
  const [isInclude, setIsInclude] = useState<boolean>(true);
  const [prevRegional, updatePrevRegional] = useState<string[]>([]);
  const [prevTaste, updatePrevTaste] = useState<string[]>([]);
  const [prevDietRequirement, updatePrevDietRequirement] = useState<string[]>(
    []
  );
  const [currRegional, updateRegional] = useState<string[]>([]);
  const [currTaste, updateTaste] = useState<string[]>([]);
  const [currDietRequirement, updateDietRequirement] = useState<string[]>([]);

  //regional
  useEffect(() => {
    const diff = difference(prevRegional, currRegional)[0];
    currRegional.map((regional) => {
      if (
        isInclude &&
        !includeTags.includes(regional) &&
        !excludeTags.includes(regional) &&
        regional !== ""
      ) {
        setIncludeTags((tags: any) => [...tags, regional]);
      } else if (
        !isInclude &&
        !excludeTags.includes(regional) &&
        !includeTags.includes(regional) &&
        regional !== ""
      ) {
        setExcludeTags([...excludeTags, regional]);
      }
    });
    if (
      (includeTags.includes(diff) || excludeTags.includes(diff)) &&
      !currRegional.includes(diff)
    ) {
      setIncludeTags(includeTags.filter((t) => t !== diff));
      setExcludeTags(excludeTags.filter((t) => t !== diff));
    }
    updatePrevRegional(currRegional);
  }, [currRegional]);

  //diet requirements
  useEffect(() => {
    const diff = difference(prevDietRequirement, currDietRequirement)[0];
    currDietRequirement.map((dietRequirement) => {
      if (
        isInclude &&
        !includeTags.includes(dietRequirement) &&
        !excludeTags.includes(dietRequirement) &&
        dietRequirement !== ""
      ) {
        setIncludeTags((tags: any) => [...tags, dietRequirement]);
      } else if (
        !isInclude &&
        !excludeTags.includes(dietRequirement) &&
        !includeTags.includes(dietRequirement) &&
        dietRequirement !== ""
      ) {
        setExcludeTags([...excludeTags, dietRequirement]);
      }
    });
    if (
      (includeTags.includes(diff) || excludeTags.includes(diff)) &&
      !currDietRequirement.includes(diff)
    ) {
      setIncludeTags(includeTags.filter((t) => t !== diff));
      setExcludeTags(excludeTags.filter((t) => t !== diff));
    }
    updatePrevDietRequirement(currDietRequirement);
  }, [currDietRequirement]);

  //taste
  useEffect(() => {
    const diff = difference(prevTaste, currTaste)[0];
    currTaste.map((taste) => {
      if (
        isInclude &&
        !includeTags.includes(taste) &&
        !excludeTags.includes(taste) &&
        taste !== ""
      ) {
        setIncludeTags((tags: any) => [...tags, taste]);
      } else if (
        !isInclude &&
        !excludeTags.includes(taste) &&
        !includeTags.includes(taste) &&
        taste !== ""
      ) {
        setExcludeTags([...excludeTags, taste]);
      }
    });
    if (
      (includeTags.includes(diff) || excludeTags.includes(diff)) &&
      !currTaste.includes(diff)
    ) {
      setIncludeTags(includeTags.filter((t) => t !== diff));
      setExcludeTags(excludeTags.filter((t) => t !== diff));
    }
    updatePrevTaste(currTaste);
  }, [currTaste]);

  // Handle filter pane being closed
  const handleClose = () => {
    handleEraseTags();
    onClose(false);
  };

  // Adds tag to include or excludedTags based on mode
  const handleAddTag = () => {
    if (tagInput.trim() !== "") {
      if (isInclude && !includeTags.includes(tagInput.trim())) {
        setIncludeTags((tags: any) => [...tags, tagInput.trim()]);
      } else if (!isInclude && !excludeTags.includes(tagInput.trim())) {
        setExcludeTags([...excludeTags, tagInput.trim()]);
      }
      setTagInput("");
    }
  };

  // Adds ingredient to ingredientsExcluded or included based on mode
  const handleIngredientAdd = () => {
    if (ingredientInput.trim() !== "") {
      if (isInclude && !includeIngredients.includes(ingredientInput.trim())) {
        setIncludeIngredients((ingredients: any) => [
          ...ingredients,
          ingredientInput.trim(),
        ]);
        setIngredientInput("");
      } else if (
        !isInclude &&
        !excludeIngredients.includes(ingredientInput.trim())
      ) {
        setExcludeIngredients([...excludeIngredients, ingredientInput.trim()]);
        setIngredientInput("");
      }
      setIngredientInput("");
    }
  };

  // Removes ingredient from include or excludedIngredients based on mode
  const handleRemoveIngredient = (ingredient: string, which: boolean) => {
    if (which) {
      //include ingredient
      setIncludeIngredients(includeIngredients.filter((t) => t !== ingredient));
    } else {
      //exclude ingredient
      setExcludeIngredients(excludeIngredients.filter((t) => t !== ingredient));
    }
  };

  // Removes tag from include or excludedTags based on mode
  const handleRemoveTag = (tag: string, which: boolean) => {
    if (which) {
      //include tag
      setIncludeTags(includeTags.filter((t) => t !== tag));
      updateRegional(currRegional.filter((t) => t !== tag));
      updateDietRequirement(currDietRequirement.filter((t) => t !== tag));
      updateTaste(currTaste.filter((t) => t !== tag));
    } else {
      //exclude tag
      setExcludeTags(excludeTags.filter((t) => t !== tag));
      updateRegional(currRegional.filter((t) => t !== tag));
      updateDietRequirement(currDietRequirement.filter((t) => t !== tag));
      updateTaste(currTaste.filter((t) => t !== tag));
    }
  };

  // Handles toggling from include to exclude mode or vice versa
  const handleToggle = () => {
    setIsInclude(!isInclude);
  };

  // Key handler so hitting enter adds tag
  const handleEnter = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === "Enter") {
      handleAddTag();
    }
  };

  // Reset all filters to empty when user hits reset tags or exits filter pane
  const handleEraseTags = () => {
    setIncludeTags([]);
    setExcludeTags([]);
    updateRegional([]);
    updateDietRequirement([]);
    updateDifficulty("");
    updateTaste([]);
    updateCookingTime([]);
    updateRating([]);
  };

  function handleOnSubmit() {
    onClose(true);
  }


  function ignoreHandle(ignore: boolean) {
    handleIgnore(ignore);
  }

  // Handles whether advanced filter pane is open
  if (!visible) return null;

  return (
    <div className={inter.className}>
      <div className="z-[100] fixed inset-0 bg-black bg-opacity-25 backdrop-blur-sm flex items-center justify-center">
        <div
          className={`relative ${
            isInclude ? "bg-green-50" : "bg-red-50"
          } rounded-xl max-w-screen-sm max-h-screen-lg w-auto h-auto table`}
        >
          <div className="flex mt-4 justify-center">
            <label className="text-gray-600 text-2xl font-black">
              Advanced Filters
            </label>
            <AiOutlineClose
              className="text-black cursor-pointer absolute right-0 top-1 mr-2 mt-2"
              onClick={handleClose}
            />
          </div>
          <div className="flex justify-center">
            <button
              className={`rounded-lg ${
                isInclude ? "bg-green-400" : "bg-red-500"
              } border-slate-500 text-xl text-white w-[180px] font-bold mr-2`}
              onClick={() => setIsInclude(!isInclude)}
            >
              {isInclude ? " Include Mode " : " Exclude Mode "}
            </button>
          </div>
          <div className="w-full max-w-full my-10 mx-5">
            <div className="grid grid-cols-4">
              <div>
                <MultiSelect
                  selectedOption={currRegional}
                  setSelectedOption={updateRegional}
                  title={"Regional"}
                  options={[
                    "Middle Eastern",
                    "Asian",
                    "South American",
                    "Italian",
                    "Eastern European",
                    "American",
                    "African",
                    "Indian",
                    "Latin American",
                    "Mediterranean",
                  ]}
                ></MultiSelect>
              </div>
              <div className="ml-4">
                <MultiSelect
                  selectedOption={currTaste}
                  setSelectedOption={updateTaste}
                  title={"Taste"}
                  options={["Spicy", "Sweet", "Sour", "Salty", "Umami"]}
                ></MultiSelect>
              </div>

              <div className="col-span-2 ml-[4.6rem] -mt-3">
                {isInclude ? (
                  <Chrono
                    title={"Prep Time"}
                    range={currPrepTime}
                    isUpperBound={true}
                    updateRange={updatePrepTime}
                  ></Chrono>
                ) : null}
              </div>

              <div className="col-span-2 col-start-3 ml-[4.6rem] -mt-3">
                {isInclude ? (
                  <Chrono
                    title={"Cooking Time"}
                    range={currCookingTime}
                    isUpperBound={true}
                    updateRange={updateCookingTime}
                  ></Chrono>
                ) : null}
              </div>
              <div>
                <MultiSelect
                  selectedOption={currDietRequirement}
                  setSelectedOption={updateDietRequirement}
                  title={"Diet"}
                  options={[
                    "Kosher",
                    "Vegan",
                    "Halal",
                    "Vegetarian",
                    "Keto",
                    "Dairy-Free",
                    "Gluten-Free",
                  ]}
                ></MultiSelect>
              </div>
              <div className="ml-4">
                {isInclude && (
                  <Dropdown
                    selectedOption={currDifficulty}
                    setSelectedOption={updateDifficulty}
                    title={"Max Difficulty"}
                    options={["Beginner", "Easy", "Medium", "Hard", "Pro"]}
                  ></Dropdown>
                )}
              </div>

              <div className="col-span-2 ml-[4.6rem] mt-2">
                {isInclude ? (
                  <Chrono
                    title={"Rating"}
                    range={currRating}
                    isUpperBound={false}
                    updateRange={updateRating}
                  ></Chrono>
                ) : null}
              </div>
            </div>
          </div>
          <div>
            <label className="text-gray-700 text-lg font-bold"></label>
          </div>
          <div className="flex mb-10 ml-6">
            <input
              type="text"
              className="border border-gray-400 py-3 px-3 w-[54%] rounded-md ml-1 mr-2"
              placeholder="Ingredient name"
              value={ingredientInput}
              onChange={(e) => setIngredientInput(e.target.value)}
              onKeyDown={handleEnter}
            />
            <button
              className="px-4 h-10 mt-[0.3rem] text-2xl -translate-x-[3.7rem] bg-gray-500 text-white rounded-xl"
              onClick={handleIngredientAdd}
            >
              +
            </button>
            <div className="text-md text-[#463a55] font-large">
              Ignore profile:
              <input
                id="default-checkbox"
                type="checkbox"
                onChange={(e) => ignoreHandle(e.target.checked)}
                className="w-6 h-6 mx-2 text-blue-600 bg-gray-100 border-gray-300 rounded focus:ring-blue-500 dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              ></input>
            </div>
          </div>
          <div className="flex flex-wrap ml-6 max-w-1/4">
            <label className="text-lg font-bold mr-2 mt-[0.1rem] mb-6">
              Tags:{" "}
            </label>
            {includeTags.map((tag, index) => (
              <div
                key={index}
                className="flex items-center bg-green-200 text-green-700 rounded-full px-3 py-1 mr-2 mb-5"
              >
                {tag}
                <button
                  className="ml-2 focus:outline-none"
                  onClick={() => handleRemoveTag(tag, true)}
                >
                  x
                </button>
              </div>
            ))}

            {excludeTags.map((tag, index) => (
              <div
                key={index}
                className="flex items-center bg-red-200 text-red-700 rounded-full px-3 py-1 mr-2 mb-5"
              >
                {tag}
                <button
                  className="ml-2 focus:outline-none"
                  onClick={() => handleRemoveTag(tag, false)}
                >
                  x
                </button>
              </div>
            ))}
            {includeIngredients.map((tag, index) => (
              <div
                key={index}
                className="flex items-center bg-green-200 text-green-700 rounded-full px-3 py-1 mr-2 mb-5"
              >
                {tag}
                <button
                  className="ml-2 focus:outline-none"
                  onClick={() => handleRemoveIngredient(tag, true)}
                >
                  x
                </button>
              </div>
            ))}

            {excludeIngredients.map((tag, index) => (
              <div
                key={index}
                className="flex items-center bg-red-200 text-red-700 rounded-full px-3 py-1 mr-2 mb-5"
              >
                {tag}
                <button
                  className="ml-2 focus:outline-none"
                  onClick={() => handleRemoveIngredient(tag, false)}
                >
                  x
                </button>
              </div>
            ))}
          </div>
          <div className="flex justify-center h-5 "></div>
          <div className="flex justify-center">
            <button
              className={`rounded-lg bg-red-500 border-slate-500 py-2 text-xl text-white w-[180px] font-bold mr-2`}
              onClick={handleEraseTags}
            >
              Reset Tags
            </button>
            <button
              className={`rounded-lg bg-green-400 border-slate-500 py-2 text-xl text-white w-[180px] font-bold mr-2`}
              onClick={handleOnSubmit}
            >
              Apply Filters
            </button>
          </div>
          <div className="flex justify-center h-5 "></div>
        </div>
      </div>
    </div>
  );
}
