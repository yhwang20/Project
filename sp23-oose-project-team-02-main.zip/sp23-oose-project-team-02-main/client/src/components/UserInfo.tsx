"use client";
import React, { useEffect, useRef } from "react";
import useState from "react-usestateref";
import "tailwindcss/tailwind.css";
import { Inter } from "@next/font/google";
import styles from "../app/page.module.css";
import Link from "next/link";
import { HiHeart, HiPencilAlt } from "react-icons/hi";
import { ImImages } from "react-icons/im";
import { useSession } from "next-auth/react";
import { Avatar, Modal } from "flowbite-react";
import { useRouter } from "next/navigation";
import EditProfile from "./EditProfile";
import axios from "axios";
import { updateUser } from "@/pages/api/userAPI";

const inter = Inter({ subsets: ["latin"] });

export default function UserInfo() {
  const [modalState, setModalState] = useState(false);
  const [isBrowser, setIsBrowser] = useState(false);
  const inputFile = useRef<HTMLInputElement>(null);
  const [uploadImage, setUploadedImage] = useState<string>();
  const [image, setImage, imageRef] = useState<string>("");
  const [upload, setUpload] = useState(false);
  const [isEdit, setIsEdit] = useState(false);
  const { data: session, update } = useSession();
  const [username, setUsername, usernameRef] = useState("");
  const router = useRouter();

  useEffect(() => {
    setIsBrowser(typeof window !== "undefined");
  }, []);

  useEffect(() => {
    if (session) {
      setUsername(session.user.username);
    }
  }, [session]);

  function clickHandler() {
    setModalState(true);
  }

  const onClose = () => {
    setModalState(false);
  };

  function uploadHandler(event: any): void {
    setUpload(false);
    event.preventDefault();
    setUploadedImage(URL.createObjectURL(event.target.files[0]));
    const formData = new FormData();
    formData.append("file", event.target.files[0]);
    formData.append("upload_preset", "yhjikef7");
    axios
      .post("https://api.cloudinary.com/v1_1/dlmsjxdmh/image/upload", formData)
      .then((res) => {
        setImage(res.data.url);
        setUpload(true);
      });
  }

  function handleEditClick(event: any) {
    event.preventDefault();
    setIsEdit(!isEdit);
  }

  function handleUsernameChange(event: any) {
    setUsername(event.target.value);
  }

  function handleOnSave(event: any) {
    if (session) {
      updateUser(session?.user.id, {
        username: usernameRef.current,
        image: imageRef.current,
      }).then(() => {
        if (imageRef.current === "" && usernameRef.current !== "") {
          update({ username: usernameRef.current });
        } else if (usernameRef.current === "" && imageRef.current !== "") {
          update({ image: imageRef.current });
        } else if (usernameRef.current !== "" && imageRef.current !== "") {
          update({ username: usernameRef.current, image: imageRef.current });
        }
        console.log("updated");
      });
    }
  }

  return (
    <>
      {isBrowser ? (
        <React.Fragment>
          <Modal show={modalState} size="lg" popup={true} onClose={onClose}>
            <Modal.Header />
            <Modal.Body>
              <EditProfile setModalState={setModalState} />
            </Modal.Body>
          </Modal>
        </React.Fragment>
      ) : (
        <> </>
      )}
      <div className={inter.className}>
        <div className="block max-w-xl px-28 rounded-xl bg-white shadow-lg py-0.5">
          <h5 className="mb-10 mt-5 justify-center text-center text-[2rem] text-[#463a55] font-bold">
            Profile
          </h5>

          <div>
            {session ? (
              <div>
                <div className={styles.center}>
                  <div className="cursor-pointer hover:opacity-70">
                    {uploadImage || session.user.image ? (
                      <Avatar
                        alt="Profile Photo"
                        img={uploadImage || session?.user.image}
                        rounded={true}
                        bordered={true}
                        size="lg"
                        onClick={() => {
                          inputFile.current?.click();
                        }}
                      />
                    ) : (
                      <label htmlFor="file">
                        <ImImages className="w-20 h-20 text-[#463a55] cursor-pointer" />
                      </label>
                    )}
                    <input
                      type="file"
                      id="file"
                      ref={inputFile}
                      accept="image/png, image/jpeg"
                      onChange={uploadHandler}
                      style={{ display: "none" }}
                    />
                  </div>
                </div>
                <div className="flex justify-center mt-10">
                  <p className="translate-y-1.5 mr-2 mb-7 font-normal text-lg text-center text-gray-500">
                    <strong className="font-semibold text-[#463a55]">
                      Username:{" "}
                    </strong>
                  </p>
                  <div className="flex w-3/5">
                    <input
                      type="text"
                      id="usernamein"
                      aria-label="usernamein"
                      className={`mb-6 ${
                        !isEdit ? "bg-gray-100" : "bg-white"
                      } border border-gray-300 text-gray-700 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 w-full p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-gray-400 dark:focus:ring-blue-500 dark:focus:border-blue-500`}
                      value={username}
                      onChange={handleUsernameChange}
                      disabled={!isEdit}
                    />
                    <HiPencilAlt
                      className="translate-x-5 translate-y-1.5 hover:cursor-pointer"
                      size={30}
                      style={{ color: "#598b8f" }}
                      onClick={handleEditClick}
                    />
                  </div>
                </div>

                <p className="mb-7 font-normal text-lg text-center text-gray-500">
                  <strong className="font-semibold text-[#463a55]">
                    Email:{" "}
                  </strong>{" "}
                  {session.user ? session?.user.email : "Email"}
                </p>

                <div style={{ display: "flex", justifyContent: "center" }}>
                  <span className="icon flex mx-2">
                    <HiHeart size={25} style={{ color: "#598b8f" }} />
                    <p className="mb-7 mx-2">
                      <Link
                        href="/user/me/favorites"
                        className="font-semibold text-lg text-center text-[#598b8f]"
                      >
                        Favorited recipes
                      </Link>
                    </p>
                  </span>
                </div>

                <div className={styles.center}>
                  <button
                    onClick={handleOnSave}
                    type="button"
                    className="text-white w-60 mb-5 bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl focus:ring-3 focus:outline-none focus:ring-green-200 dark:focus:ring-green-800 font-semibold rounded-2xl text-lg px-5 py-2.5 text-center"
                  >
                    Save
                  </button>
                </div>
              </div>
            ) : (
              <div>
                <div>
                  <h1 className="text-center font-semibold text-lg">
                    {" "}
                    Not Logged In
                  </h1>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
