import Image from "next/image";
import React, { useRef } from "react";
import useState from "react-usestateref";
import { BiCamera } from "react-icons/bi";
import { ImImages } from "react-icons/im";
import axios from "axios";


type photoProps = {
  setImage: React.Dispatch<React.SetStateAction<string | undefined>>;
  image: string | undefined;
};


// Component to add photo to recipe, used in recipe edit and create
function AddRecipePhoto({ setImage, image }: photoProps) {
  const inputFile = useRef<HTMLInputElement>(null);
  const [file, setFile, fileRef] = useState<File>();
  const [uploadImage, setUploadedImage] = useState<string>();
  const [upload, setUpload] = useState(false);

  const uploadHandler = (event: any) => {
    event.preventDefault();
    setFile(event.target.files[0]);
    setUploadedImage(URL.createObjectURL(fileRef.current!));
  };

  const onUpload = () => {
    setUpload(false);
    const formData = new FormData();
    formData.append("file", fileRef.current!);
    formData.append("upload_preset", "yhjikef7");
    if (formData.get("file") === null) {
      console.log(formData.get("file"));
      return;
    }
    axios
      .post("https://api.cloudinary.com/v1_1/dlmsjxdmh/image/upload", formData)
      .then((res) => {
        setImage(res.data.url);
        setUpload(true);
      });
  };
  return (
    <div>
      <div className="flex flex-col items-center">
        {uploadImage || image ? (
          uploadImage ? (
            <div>
              <div className="relative">
                <Image
                  className="rounded-md border border-b-black w-[65vh]"
                  src={uploadImage}
                  width={800}
                  height={400}
                  alt="recipe image"
                />
                <button
                  className="absolute bottom-1 right-2 opacity-75 w-10 h-10 bg-black rounded-lg flex justify-center items-center"
                  onClick={() => inputFile.current!.click()}
                >
                  <BiCamera className="w-6 h-6 text-white" />
                </button>
              </div>
              <button
                color="#84C7AE"
                className="w-full text-white px-10 py-2 mt-2 rounded-md bg-gradient-to-r from-[#75628e] to-[#907ea7]  hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 text-lg font-medium"
                onClick={onUpload}
              >
                {!upload ? "Upload" : "Uploaded"}
              </button>
            </div>
          ) : (
            <div>
              <div className="relative">
                <Image
                  className="rounded-md border border-b-black w-[65vh]"
                  src={image || ""}
                  width={800}
                  height={400}
                  alt="recipe image"
                />
                <button
                  className="absolute bottom-1 right-2 opacity-75 w-10 h-10 bg-black rounded-lg flex justify-center items-center"
                  onClick={() => inputFile.current!.click()}
                >
                  <BiCamera className="w-6 h-6 text-white" />
                </button>
              </div>
              <button
                color="#84C7AE"
                className="w-full text-white px-10 py-2 mt-2 rounded-md bg-gradient-to-br from-[#75628e] to-[#907ea7]  hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 text-lg font-medium"
                onClick={onUpload}
              >
                {!upload ? "Upload" : "Uploaded"}
              </button>
            </div>
          )
        ) : (
          <label htmlFor="file">
            <ImImages className="w-20 h-20 text-[#5b4b6f] cursor-pointer" />
          </label>
        )}

        <input
          type="file"
          id="file"
          ref={inputFile}
          accept="image/png, image/jpeg"
          onChange={uploadHandler}
          style={{ display: "none" }}
        />
        <h1 className="text-2xl font-semibold text-[#5b4b6f] mt-5">
          Upload recipe photo
        </h1>
      </div>
    </div>
  );
}

export default AddRecipePhoto;
