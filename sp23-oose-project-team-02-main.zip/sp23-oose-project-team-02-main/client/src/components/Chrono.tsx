import "tailwindcss/tailwind.css";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select, { SelectChangeEvent } from "@mui/material/Select";
import { Inter } from "@next/font/google";
import { useState, useEffect } from "react";
const inter = Inter({ subsets: ["latin"] });

export interface ChronoProps {
  range: string;
  title: string;
  isUpperBound: boolean;
  updateRange: Function;
}

// Chrono component,
// accepts a title, range, updatable range, and lower and upper bounds
const Chrono = ({ range, title, isUpperBound, updateRange }: ChronoProps) => {


  const handleOnChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    updateRange(event.target.value);
  };

  return (
    <div className={inter.className}>
      <div className="text-center w-[155px] flex flex-col justify-center items-center">
        <label className="text-gray-600 font-medium pr-2">{title}:</label>
        <div className="flex flex-row justify-center items-center">
          {isUpperBound ? (
            <h1 className="mr-1">&le;</h1>
          ) : (
            <h1 className="mr-1">&ge;</h1>
          )}
          <input
            type="number"
            min="0"
            className="border border-gray-400 p-2 rounded w-14 h-9"
            value={range}
            onChange={handleOnChange}
            data-testid="title"
          />
        </div>
      </div>
    </div>
  );
};

export default Chrono;
