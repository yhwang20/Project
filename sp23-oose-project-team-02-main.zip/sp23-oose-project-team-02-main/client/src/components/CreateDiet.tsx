"use client";
import React, { Component, useEffect, useState } from "react";
import "tailwindcss/tailwind.css";
import styles from "../app/page.module.css";
import { Inter } from "@next/font/google";
import Image from "next/image";
const inter = Inter({ subsets: ["latin"] });
import { useRouter } from "next/navigation";
import axios from "axios";
import ToggleButton from "./ToggleButton";
import { useSession } from "next-auth/react";
import { updatedUserPreference } from "@/pages/api/userAPI";
import Loading from "@/app/(WithoutHeader)/loading";

export default function CreateDiet() {
  const [veganToggled, setVeganToggled] = useState(false);
  const [vegetarianToggled, setVegetarianToggled] = useState(false);
  const [kosherToggled, setKosherToggled] = useState(false);
  const [halalToggled, setHalalToggled] = useState(false);
  const [ketoToggled, setKetoToggled] = useState(false);
  const [dairyFreeToggled, setDairyFreeToggled] = useState(false);
  const [glutenFreeToggled, setGlutenFreeToggled] = useState(false);
  const { data: session } = useSession();
  const [loading, setLoading] = useState(false);

  const [tags, setTags] = useState<string[]>([]);
  const [tagInput, setTagInput] = useState("");
  const [selectedDiets, setSelectedDiets] = useState<string[]>([]);
  const routing = useRouter();

  const handleAddTag = () => {
    if (tagInput.trim() !== "" && !tags.includes(tagInput.trim())) {
      setTags([...tags, tagInput.trim()]);
      setTagInput("");
    }
  };

  useEffect(() => {
    if (session?.user.setupComplete) {
      routing.push("/");
    }
  }, [session]);

  const handleRemoveTag = (index: number) => {
    setTags([...tags.slice(0, index), ...tags.slice(index + 1)]);
  };

  // let listOfExcludes: String[];
  // const excludeIngredient = (ing : String) => listOfExcludes.push(ing);
  // let excludedIngredientString = "";
  const toggleVegan = () => {
    setVeganToggled((t) => !t);
    if (veganToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Vegan"));
    } else {
      setSelectedDiets((diets) => [...diets, "Vegan"]);
    }
  };
  const toggleVegetarian = () => {
    setVegetarianToggled((t) => !t);
    if (vegetarianToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Vegetarian"));
    } else {
      setSelectedDiets((diets) => [...diets, "Vegetarian"]);
    }
  };
  const toggleGlutenFree = () => {
    setGlutenFreeToggled((t) => !t);
    if (glutenFreeToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Gluten-Free"));
    } else {
      setSelectedDiets((diets) => [...diets, "Gluten-Free"]);
    }
  };
  const toggleKosher = () => {
    setKosherToggled((t) => !t);
    if (kosherToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Kosher"));
    } else {
      setSelectedDiets((diets) => [...diets, "Kosher"]);
    }
  };
  const toggleHalal = () => {
    setHalalToggled((t) => !t);
    if (halalToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Halal"));
    } else {
      setSelectedDiets((diets) => [...diets, "Halal"]);
    }
  };

  const toggleKeto = () => {
    setKetoToggled((t) => !t);
    if (ketoToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Keto"));
    } else {
      setSelectedDiets((diets) => [...diets, "Keto"]);
    }
  };

  const toggleDairyFree = () => {
    setDairyFreeToggled((t) => !t);
    if (dairyFreeToggled) {
      setSelectedDiets((diets) => diets.filter((r) => r !== "Dairy-Free"));
    } else {
      setSelectedDiets((diets) => [...diets, "Dairy-Free"]);
    }
  };

  const onClick = async () => {
    const userID = session?.user.id;
    setLoading(true);
    await updatedUserPreference(userID, {
      ingredientsExcluded: tags,
      vegan: veganToggled,
      vegetarian: vegetarianToggled,
      kosher: kosherToggled,
      halal: halalToggled,
      keto: ketoToggled,
      nonDairy: dairyFreeToggled,
      glutenFree: glutenFreeToggled,
    }).then(() => {
      routing.push("/user/setupcomplete");
    });
  };

  if (loading) {
    return <Loading />;
  }
  return (
    <div className={styles.mainSignIn}>
      <div className={styles.squareLeft}></div>
      <div className={styles.squareRight}></div>

      <div className="w-full max-w-xl p-6 bg-white border border-gray-200 rounded-xl shadow dark:bg-gray-800 dark:border-gray-700">
        <div className="title">
          <div className="flex justify-center align-items">
            <Image
              src={"/Logo.svg"}
              width="200"
              height={200}
              alt="logo"
            ></Image>
          </div>
          <h1 className="text-gray-800 text-4xl text-center py-4 font-bold">
            Set Up Your Account
          </h1>
        </div>
        <div>
          <h2 className="text-gray-500 text-center my-5 text-lg">
            What are your dietary restrictions?
          </h2>
          <div className="grid grid-cols-3 mb-10">
            <ToggleButton onClick={toggleVegan} toggled={veganToggled}>
              Vegan
            </ToggleButton>
            <ToggleButton
              onClick={toggleVegetarian}
              toggled={vegetarianToggled}
            >
              Vegetarian
            </ToggleButton>
            <ToggleButton onClick={toggleKosher} toggled={kosherToggled}>
              Kosher
            </ToggleButton>
            <ToggleButton onClick={toggleHalal} toggled={halalToggled}>
              Halal
            </ToggleButton>

            <ToggleButton onClick={toggleKeto} toggled={ketoToggled}>
              Keto
            </ToggleButton>
            <ToggleButton onClick={toggleDairyFree} toggled={dairyFreeToggled}>
              Dairy-Free
            </ToggleButton>
            <ToggleButton
              onClick={toggleGlutenFree}
              toggled={glutenFreeToggled}
            >
              Gluten-Free
            </ToggleButton>
          </div>
        </div>
        <h2 className="text-gray-500 text-center my-5 text-xl">
          {" "}
          Any other ingredients you wish to exclude?{" "}
        </h2>
        <div className=" mb-4 flex justify-center align-items">
          <input
            type="text"
            className="border border-slate-300 px-4 py-2 rounded-full mr-2"
            placeholder="Ingredient"
            value={tagInput}
            onChange={(e) => setTagInput(e.target.value)}
          />
          <button
            className="px-2 py-2 bg-[#84C7AE] text-white rounded-xl"
            onClick={handleAddTag}
          >
            Add
          </button>
        </div>
        <div className="flex flex-wrap mb-4">
          {tags.map((tag, index) => (
            <div
              key={index}
              className="flex items-center bg-red-400 text-slate-50 rounded-full px-3 py-1 mr-2 mb-2"
            >
              {tag}
              <button
                className="ml-2 focus:outline-none"
                onClick={() => handleRemoveTag(index)}
              >
                x
              </button>
            </div>
          ))}
        </div>
        <div className="flex justify-center">
          <button
            type="button"
            onClick={onClick}
            className="text-white border bg-[#84C7AE] hover:bg-[#51b38f] focus:outline-none font-medium rounded-[20px] text-xl mt-10 px-16 py-3 text-center"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
