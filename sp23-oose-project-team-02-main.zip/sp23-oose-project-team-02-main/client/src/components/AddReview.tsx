"use client";
import React, { useState, useEffect } from "react";
import { Recipe } from "recipe-types";
import { addReview } from "@/pages/api/recipeAPI";
import styles from "@/app/page.module.css";
import { useSession } from "next-auth/react";
import Loading from "@/app/(WithHeader)/loading";

type addReviewProps = {
  recipe: Recipe;
};

// Component to allow signed in user to add review, used in RecipeView page
function AddReview({ recipe }: addReviewProps) {
  const recipeId = recipe.id;
  const [comment, setComment] = useState<string>("");
  const [score, setScore] = useState<number>(0);
  const { data: session } = useSession();
  const [loading, setLoading] = useState<boolean>(false);
  const [reviewExist, setReviewExist] = useState<boolean>(false);
  const [reviewAdded, setReviewAdded] = useState<boolean>(false);
  const [authorRecipe, setAuthorRecipe] = useState<boolean>(false);
  const userId = session?.user.id;

  // load reviews and check whether viewer has already given a review
  useEffect(() => {
    if (userId) {
      recipe.reviews.map((review) => {
        if (review.userId === userId) setReviewExist(true);
      });
      if (recipe.authorID === userId) {
        setReviewExist(true);
        setAuthorRecipe(true);
      }
    }
  }, []);

  const onSubmit = () => {
    setLoading(true);
    addReview(recipeId, userId, score, comment)
      .then(() => {
        setReviewAdded(true);
        setLoading(false);
      })
      .catch((err) => {
        console.log(err);
        setReviewExist(true);
        setLoading(false);
      });
  };

  // Doesn't allow user who's not signed in to add review
  if (!session) {
    return (
      <div className="flex flex-col justify-center p-5">
        <h5 className="mb-1 justify-center text-center text-[1.5rem] font-black">
          <span>Please log in to add a review</span>
        </h5>
      </div>
    );
  }


  // Doesn't allow user to add more than 1 review
  if (reviewExist && !authorRecipe) {

    return (
      <div className="flex flex-col justify-center p-5">
        <h5 className="mb-1 justify-center text-red-400 text-center text-[1.5rem]">
          <span>You already added a review for this recipe!</span>
        </h5>
      </div>
    );
  }


  // Shows message saying Review Added after review submitted
  if (authorRecipe) {
    return (
      <div className="flex flex-col justify-center p-5">
        <h5 className="mb-1 justify-center text-red-400 text-center text-[1.5rem]">
          <span>You cannot add a review to your own recipe!</span>
        </h5>
      </div>
    );
  }

  if (reviewAdded) {
    return (
      <div className="flex flex-col justify-center p-5">
        <h5 className="mb-1 justify-center text-green-400 text-center text-[1.5rem]">
          <span>Review added!</span>
        </h5>
      </div>
    );
  }

  if (loading) {
    return <Loading />;
  }
  return (
    <div>
      <div className="flex flex-col justify-center p-5 mb-5">
        <div className="w-full mb-4 border border-gray-200 rounded-lg bg-gray-50 dark:bg-gray-700 dark:border-gray-600">
          <div className="px-4 py-2 bg-white rounded-t-lg dark:bg-gray-800">
            <form>
              <label htmlFor="comment" className="sr-only">
                Your comment
              </label>
              <textarea
                id="comment"
                rows={4}
                className="w-full px-0 text-sm text-gray-900 bg-white border-0 dark:bg-gray-800 focus:ring-0 dark:text-white dark:placeholder-gray-400"
                placeholder="Write a comment..."
                required
                onChange={(e) => setComment(e.target.value)}
              ></textarea>
            </form>
          </div>
          <div className={styles.rate}>
            <input
              type="radio"
              id="star5"
              name="rate"
              value="5"
              onChange={(e) => setScore(parseInt(e.target.value, 10))}
            />
            <label htmlFor="star5" title="text">
              5 stars
            </label>
            <input
              type="radio"
              id="star4"
              name="rate"
              value="4"
              onChange={(e) => setScore(parseInt(e.target.value, 10))}
            />
            <label htmlFor="star4" title="text">
              4 stars
            </label>
            <input
              type="radio"
              id="star3"
              name="rate"
              value="3"
              onChange={(e) => setScore(parseInt(e.target.value, 10))}
            />
            <label htmlFor="star3" title="text">
              3 stars
            </label>
            <input
              type="radio"
              id="star2"
              name="rate"
              value="2"
              onChange={(e) => setScore(parseInt(e.target.value, 10))}
            />
            <label htmlFor="star2" title="text">
              2 stars
            </label>
            <input
              type="radio"
              id="star1"
              name="rate"
              value="1"
              onChange={(e) => setScore(parseInt(e.target.value, 10))}
            />
            <label htmlFor="star1" title="text">
              1 star
            </label>
          </div>
        </div>
        <div className="flex justify-center">
          <button
            type="button"
            className="w-full items-center py-2.5 px-4 text-lg font-medium text-center text-white bg-gradient-to-br from-[#75628e] to-[#907ea7]  hover:bg-gradient-to-bl rounded-lg focus:ring-4 focus:ring-blue-200 dark:focus:ring-blue-900 hover:bg-blue-800"
            onClick={onSubmit}
          >
            Post Review
          </button>
        </div>
      </div>
    </div>
  );
}

export default AddReview;
