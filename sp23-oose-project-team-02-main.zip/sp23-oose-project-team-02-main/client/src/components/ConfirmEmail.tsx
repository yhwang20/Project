"use client";

import { useSearchParams } from "next/navigation";
import React from "react";


// Component to tell user to check email for account confirmation
export default function ConfirmEmail() {
  const searchParams = useSearchParams();

  return (
    <div className="relative bg-background w-full min-h-screen overflow-hidden text-center text-lg text-black font-karla">
      <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2">
        <div className="rounded-[49.09px] bg-form-bg w-full max-w-lg mx-auto mb-10 px-4 py-8">
          <p className="text-lg mb-4">An email has been sent to:</p>
          <p className="text-2xl">
            {searchParams ? searchParams.get("email") : "unknown email"}
          </p>
          <br></br> <br></br>
          <p className="mb-4">Click on the link there to</p>
          <p className="mb-4">continue setting up your account!</p>
        </div>
      </div>
    </div>
  );
}
