"use client";
import React, { useEffect } from "react";
import { AiFillHeart, AiOutlineHeart } from "react-icons/ai";
import { useSession } from "next-auth/react";
import { addFavorite, removeFavorite } from "@/pages/api/recipeAPI";
import { getUser } from "@/pages/api/userAPI";
import useState from "react-usestateref";
import { Recipe } from "recipe-types";

function HeartToggle({ recipe }: { recipe: Recipe }) {
  const [isToggled, setIsToggled, toggleRef] = useState(false);
  const { data: session } = useSession();
  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    const retrieveUser = async () => {
      if (session) {
        const username = session.user.username;
        if (
          recipe.favoritedBy.map((user) => user.username === username)[0] ===
          true
        ) {
          setIsToggled(true);
        }
      }
    };
    retrieveUser();
  }, [session]);

  const onClick = async () => {
    setIsToggled(!isToggled);
    if (session) {
      const userId = session.user.id;
      if (toggleRef.current) {
        setIsLoading(true);
        addFavorite(userId, recipe.id)
          .then(() => setIsLoading(false))
          .catch(() => setIsLoading(false));
      } else {
        setIsLoading(true);
        removeFavorite(userId, recipe.id)
          .then(() => setIsLoading(false))
          .catch(() => setIsLoading(false));
      }
    }
  };
  return (
    <div>
      <button disabled={isLoading} onClick={onClick}>
        {isToggled && session ? (
          <div className="flex">
            <AiFillHeart className="text-red-500 w-5 h-5 mt-1" />
            <h1 className="mt-0.5 ml-1">Added to favorites!</h1>
          </div>
        ) : (
          <div className="flex">
            <AiOutlineHeart className="mt-1 w-5 h-5" />
            <h1 className="mt-0.5 ml-1">Add to favorites</h1>
          </div>
        )}
      </button>
    </div>
  );
}

export default HeartToggle;
