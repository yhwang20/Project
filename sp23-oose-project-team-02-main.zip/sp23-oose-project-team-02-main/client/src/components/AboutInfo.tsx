import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });

// Component to show team story in About page
export default function Info() {
  return (
    <div className={inter.className}>
      <div className="overflow-hidden py-24 sm:py-32">
        <div className="mx-auto max-w-7xl px-6 lg:px-8">
          <div className="mx-auto grid max-w-2xl grid-cols-2 gap-x-20 md:gap-x-20 lg:gap-x-36 gap-y-16 sm:gap-y-20 lg:mx-0 lg:max-w-none lg:grid-cols-2">
            <div className="lg:pr-8 lg:pt-4">
              <div className="lg:max-w-xl md:max-w-lg">
                <p className="mt-2 text-3xl text-center font-bold tracking-tight text-gray-900 sm:text-4xl md:text-4xl lg:text-5xl">
                  Our History
                </p>
                <p className="mt-6 text-lg text-center leading-8 text-gray-600 md:text-lg lg:text-xl">
                  We are a group of Johns Hopkins students who embarked on a
                  mission to help inexperienced and desperate cooks like us. Our
                  journey began in the Hopkins OOSE class, where we were tasked
                  with creating a software application that could solve a
                  real-world problem. After much brainstorming, we realized that
                  cooking was a struggle for many of us, and we wanted to change
                  that. Over the course of a semester, we designed, developed,
                  and tested the Reciplease app, pouring all our creativity and
                  passion into making it user-friendly and efficient.
                  <br></br> Today, we continue to innovate and improve the app,
                  always with a focus on our mission to help beginner,
                  untalented, and desperate cooks everywhere. Join us on our
                  journey, and let&apos;s make cooking fun and easy for everyone!

         
                </p>
              </div>
            </div>
            <div className="lg:pr-8 lg:pt-4">
              <div className="lg:max-w-lg">
                <p className="mt-2 text-3xl text-center font-bold tracking-tight text-gray-900 sm:text-4xl md:text-4xl lg:text-5xl">
                  Acknowledgements
                </p>
                <p className="mt-6 text-center text-lg leading-8 text-gray-600 md:text-lg lg:text-xl">
                  We’d like to acknowledge Will Tong, who was with us every step
                  of the way and helped make our app what it is. Thanks also go
                  to Josh Nakka, who answered our Slack queries at odd hours,
                  and to Professor Ali Madooei, for his always helpful, often
                  painful feedback and random participation in our chat.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
