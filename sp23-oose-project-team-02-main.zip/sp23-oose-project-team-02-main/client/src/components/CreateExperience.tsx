"use client";
import React, { useEffect, useState } from "react";
import styles from "../app/page.module.css";
import { Inter } from "@next/font/google";
import { useRouter } from "next/navigation";
import Image from "next/image";
import ToggleButton from "./ToggleButton";
import { useSession } from "next-auth/react";
import {
  createUserPreference,
  updatedUserPreference,
} from "@/pages/api/userAPI";
import { Tag } from "user-types";
import Loading from "@/app/(WithoutHeader)/loading";

export default function CreateExperience() {
  const [hydrated, setHydrated] = useState(false);
  const [experience, setExperience] = useState(0);
  const [americanToggled, setAmericanToggled] = useState(false);
  const [latinAmericanToggled, setLatinAmericanToggled] = useState(false);
  const [southAsianToggled, setSouthAsianToggled] = useState(false);
  const [eastAsianToggled, setEastAsianToggled] = useState(false);
  const [southEastAsianToggled, setSouthEastAsianToggled] = useState(false);
  const [subsaharanAfricanToggled, setSubsaharanAfricanToggled] =
    useState(false);
  const [westEuropeanToggled, setWestEuropeanToggled] = useState(false);
  const [eastEuropeanToggled, setEastEuropeanToggled] = useState(false);
  const [northAfricanToggled, setNorthAfricanToggled] = useState(false);
  const [middleEasternToggled, setMiddleEasternToggled] = useState(false);
  const [caribbeanToggled, setcaribbeanToggled] = useState(false);
  const [selectedRegions, setSelectedRegions] = useState<Tag[]>([]);
  const [loading, setLoading] = useState(false);
  const { data: session } = useSession();
  const routing = useRouter();

  useEffect(() => {
    if (session?.user.setupComplete) {
      routing.push("/");
    }
  }, [session]);

  const toggleAmerican = () => {
    const american = {
      name: "American",
    };
    setAmericanToggled((t) => !t);
    if (americanToggled) {
      setSelectedRegions((regions) => regions.filter((r) => r !== american));
    } else {
      setSelectedRegions((regions) => [...regions, american]);
    }
  };
  const toggleEastAsian = () => {
    const eastAsian = {
      name: "East Asian",
    };
    setEastAsianToggled((t) => !t);
    if (eastAsianToggled) {
      setSelectedRegions((regions) => regions.filter((r) => r !== eastAsian));
    } else {
      setSelectedRegions((regions) => [...regions, eastAsian]);
    }
  };
  const toggleSouthAsian = () => {
    const southAsian = {
      name: "South Asian",
    };
    setSouthAsianToggled((t) => !t);
    if (southAsianToggled) {
      setSelectedRegions((regions) => regions.filter((r) => r !== southAsian));
    } else {
      setSelectedRegions((regions) => [...regions, southAsian]);
    }
  };
  const toggleLatinAmerican = () => {
    const latinAmerican = {
      name: "Latin American",
    };
    setLatinAmericanToggled((t) => !t);
    if (latinAmericanToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== latinAmerican)
      );
    } else {
      setSelectedRegions((regions) => [...regions, latinAmerican]);
    }
  };
  const toggleWestEuropean = () => {
    const westEuropean = {
      name: "Western European",
    };
    setWestEuropeanToggled((t) => !t);
    if (westEuropeanToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== westEuropean)
      );
    } else {
      setSelectedRegions((regions) => [...regions, westEuropean]);
    }
  };
  const toggleEastEuropean = () => {
    const eastEuropean = {
      name: "Eastern European",
    };
    setEastEuropeanToggled((t) => !t);
    if (eastEuropeanToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== eastEuropean)
      );
    } else {
      setSelectedRegions((regions) => [...regions, eastEuropean]);
    }
  };
  const toggleNorthAfrican = () => {
    const northAfrican = {
      name: "North African",
    };
    setNorthAfricanToggled((t) => !t);
    if (northAfricanToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== northAfrican)
      );
    } else {
      setSelectedRegions((regions) => [...regions, northAfrican]);
    }
  };
  const toggleMiddleEastern = () => {
    const middleEastern = {
      name: "Middle Eastern",
    };
    setMiddleEasternToggled((t) => !t);
    if (middleEasternToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== middleEastern)
      );
    } else {
      setSelectedRegions((regions) => [...regions, middleEastern]);
    }
  };
  const togglecaribbean = () => {
    const caribbean = {
      name: "caribbean",
    };
    setcaribbeanToggled((t) => !t);
    if (caribbeanToggled) {
      setSelectedRegions((regions) => regions.filter((r) => r !== caribbean));
    } else {
      setSelectedRegions((regions) => [...regions, caribbean]);
    }
  };
  const toggleSouthEastAsian = () => {
    const southEastAsian = {
      name: "South-East Asian",
    };
    setSouthEastAsianToggled((t) => !t);
    if (southEastAsianToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== southEastAsian)
      );
    } else {
      setSelectedRegions((regions) => [...regions, southEastAsian]);
    }
  };
  const toggleSubsaharanAfrica = () => {
    const subsaharanAfrican = {
      name: "Subsaharan African",
    };
    setSubsaharanAfricanToggled((t) => !t);
    if (subsaharanAfricanToggled) {
      setSelectedRegions((regions) =>
        regions.filter((r) => r !== subsaharanAfrican)
      );
    } else {
      setSelectedRegions((regions) => [...regions, subsaharanAfrican]);
    }
  };

  const onClick = async () => {
    setLoading(true);
    const userPrefs = await updatedUserPreference(session?.user.id, {
      difficulty: experience,
      cuisineTags: selectedRegions,
    }).then(() => {
      routing.push("/user/setdiet");
    });
  };
  if (loading) {
    return <Loading />;
  }
  return (
    <div className={styles.mainSignIn}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>

      <div className="w-full max-w-xl p-6 bg-white border border-gray-200 rounded-xl shadow dark:bg-gray-800 dark:border-gray-700 -translate-y-20">
        <div className="title">
          <div className="flex justify-center align-items">
            <Image
              src={"/Logo.svg"}
              width={200}
              height={200}
              alt="logo"
            ></Image>
          </div>
          <h1 className="text-gray-800 text-4xl text-center py-4 font-bold">
            Set Up Your Account
          </h1>
        </div>
        <div>
          <h2 className="text-gray-500 text-center my-10 text-lg">
            What is your existing cooking experience?
          </h2>
          <div className="flex justify-center">
            <div className="flex flex-col items-center mr-3">
              <input
                id="inline-radio"
                type="radio"
                value="1"
                name="inline-radio-group"
                onChange={(e) => {
                  const value = parseInt(e.target.value, 10);
                  setExperience(value);
                }}
                className="w-4 h-4 text-[#84C7AE] bg-gray-100 border-gray-300 focus:ring-[#84C7AE] dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              />
              <label
                htmlFor="inline-radio"
                className="ml-3 my-2 text-sm font-medium text-gray-400 dark:text-gray-300"
              >
                Little: Can Boil Water, Open Cans, and Fry Eggs
              </label>
            </div>
            <div className="flex flex-col items-center mr-3">
              <input
                id="inline-2-radio"
                type="radio"
                value="3"
                name="inline-radio-group"
                onChange={(e) => {
                  const value = parseInt(e.target.value, 10);
                  setExperience(value);
                }}
                className="w-4 h-4 text-[#84C7AE] bg-gray-100 border-gray-300 focus:ring-[#84C7AE] dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              />
              <label
                htmlFor="inline-2-radio"
                className="ml-3 my-2 text-sm font-medium text-gray-400 dark:text-gray-300"
              >
                Moderate: Can Bake, Roast, Fry, and Sauté
              </label>
            </div>
            <div className="flex flex-col items-center mr-3">
              <input
                id="inline-3-radio"
                type="radio"
                value="5"
                onChange={(e) => {
                  const value = parseInt(e.target.value, 10);
                  setExperience(value);
                }}
                name="inline-radio-group"
                className="w-4 h-4 text-[#84C7AE] bg-gray-100 border-gray-300 focus:ring-[#84C7AE] dark:focus:ring-blue-600 dark:ring-offset-gray-800 focus:ring-2 dark:bg-gray-700 dark:border-gray-600"
              />
              <label
                htmlFor="inline-3-radio"
                className="mx-2 my-2 text-sm font-medium text-gray-400 dark:text-gray-300"
              >
                Experienced: Have cooked full meals before
              </label>
            </div>
          </div>
        </div>
        <h2 className="text-gray-500 text-center text-lg mt-5">
          What types of cuisine do you enjoy?
        </h2>
        <div className="w-full max-w-xl mb-10">
          <div className="grid grid-cols-3">
            <ToggleButton onClick={toggleAmerican} toggled={americanToggled}>
              American
            </ToggleButton>
            <ToggleButton
              onClick={toggleLatinAmerican}
              toggled={latinAmericanToggled}
            >
              Latin-American
            </ToggleButton>
            <ToggleButton onClick={togglecaribbean} toggled={caribbeanToggled}>
              Caribbean
            </ToggleButton>
            <ToggleButton
              onClick={toggleWestEuropean}
              toggled={westEuropeanToggled}
            >
              West-European
            </ToggleButton>
            <ToggleButton
              onClick={toggleEastEuropean}
              toggled={eastEuropeanToggled}
            >
              East-European
            </ToggleButton>
            <ToggleButton
              onClick={toggleNorthAfrican}
              toggled={northAfricanToggled}
            >
              North-African
            </ToggleButton>
            <ToggleButton
              onClick={toggleSubsaharanAfrica}
              toggled={subsaharanAfricanToggled}
            >
              Subsaharan-African
            </ToggleButton>
            <ToggleButton
              onClick={toggleMiddleEastern}
              toggled={middleEasternToggled}
            >
              Middle-Eastern
            </ToggleButton>
            <ToggleButton
              onClick={toggleSouthAsian}
              toggled={southAsianToggled}
            >
              South-Asian
            </ToggleButton>
            <ToggleButton onClick={toggleEastAsian} toggled={eastAsianToggled}>
              East-Asian
            </ToggleButton>
            <ToggleButton
              onClick={toggleSouthEastAsian}
              toggled={southEastAsianToggled}
            >
              Southeast-Asian
            </ToggleButton>
          </div>
        </div>
        <div className="flex justify-center">
          <button
            type="button"
            onClick={onClick}
            className="text-white border bg-[#84C7AE] hover:bg-[#51b38f] focus:outline-none font-medium rounded-[20px] text-xl px-16 py-3 text-center"
          >
            Next
          </button>
        </div>
      </div>
    </div>
  );
}
