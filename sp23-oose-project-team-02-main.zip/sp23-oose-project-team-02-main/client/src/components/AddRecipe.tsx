"use client";
import React, { useEffect, useState } from "react";
import styles from "@/app/page.module.css";
import { Inter } from "@next/font/google";
import AddRecipePhoto from "./AddRecipePhoto";
import { useForm, useFieldArray } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";
import { addRecipe, getRecipe, updateRecipe } from "@/pages/api/recipeAPI";
import { useSession } from "next-auth/react";
import { useRouter } from "next/navigation";
import { Tag } from "user-types";

const inter = Inter({ subsets: ["latin"] });

type RecipeFormValues = {
  title: string;
  background: string;
  ingredients: { name: string; quantity: string }[];
  instructions: { step: string }[];
  tools: { tool: string }[];
  prepTime: number;
  cookTime: number;
  difficulty: number;
  servings: number;
  image: string;
  tags: { name: string }[];
  nutrition?: {
    Calories: number;
    Fat: string;
    Carbs: string;
    Protein: string;
  };
};


// Defines schema and required fields for form
const schema = yup.object().shape({
  title: yup.string().required(),
  background: yup.string().optional(),
  ingredients: yup.array().of(
    yup.object({
      name: yup.string().required(),
      quantity: yup.string().required(),
    })
  ),
  instructions: yup.array().of(
    yup.object({
      step: yup.string().required(),
    })
  ),
  tools: yup.array().of(
    yup.object({
      tool: yup.string().required(),
    })
  ),
  prepTime: yup.number().required(),
  cookTime: yup.number().optional(),
  servings: yup.number().required(),
  difficulty: yup.string().required(),
  nutrition: yup
    .object({
      Calories: yup.string().optional().nullable(),
      Fat: yup.string().optional(),
      Carbs: yup.string().optional(),
      Protein: yup.string().optional(),
    })
    .optional(),
  tags: yup.array().of(
    yup.object({
      name: yup.string().optional(),
    })
  ),
});

// Component to allow users to edit/create recipe
function AddRecipe({ recipeId }: { recipeId?: string }) {
  const [image, setImage] = useState<string>();
  const [tagInput, setTagInput] = useState<string>("");
  const [success, onSuccess] = useState<boolean>(false);
  const router = useRouter();
  const { data: session } = useSession();
  const {
    register,
    handleSubmit,
    control,
    reset,
    formState: { errors },
  } = useForm<RecipeFormValues>({
    resolver: yupResolver(schema),
    // Set default form values
    defaultValues: {
      title: "",
      background: "",
      difficulty: 2,
      ingredients: [{ name: "", quantity: "" }],
      instructions: [{ step: "" }],
      tools: [{ tool: "" }],
      nutrition: {},
    },
  });

  useEffect(() => {
    if (recipeId) {
      // Handles getting recipe info if are editing recipe instead of adding new recipe
      getRecipe(recipeId).then((recipe) => {
        setImage(recipe.photo);
        reset({
          title: recipe.name,
          background: recipe.background,
          difficulty: recipe.difficulty,
          prepTime: recipe.prepTimeInMins,
          cookTime: recipe.cookTimeInMins || 0,
          servings: recipe.servings,
          ingredients: recipe.ingredients.map((ingredient: string) => {
            const [name, quantity] = ingredient.split(":");
            return { name: name, quantity: quantity };
          }),
          instructions: recipe.procedure.map((instruction: string) => {
            return { step: instruction };
          }),
          tools: recipe.tools.map((tool: string) => {
            return { tool: tool };
          }),
          tags: recipe.tags.map((tag: Tag) => {
            return { name: tag.name };
          }),
          nutrition: recipe.nutrition,
        });
      });
    }
  }, [recipeId, reset]);

  // Define difficulty dropdown options
  const options = [
    { value: 1, label: "Beginner" },
    { value: 2, label: "Easy" },
    { value: 3, label: "Medium" },
    { value: 4, label: "Hard" },
    { value: 5, label: "Pro" },
  ];

  const {
    fields: ingredientFields,
    append: appendIngredient,
    remove: removeIngredient,
  } = useFieldArray({
    control,
    name: "ingredients",
  });

  const {
    fields: instructionsField,
    append: appendInstruction,
    remove: removeInstruction,
  } = useFieldArray({
    control,
    name: "instructions",
  });

  const {
    fields: toolsField,
    append: appendTools,
    remove: removeTools,
  } = useFieldArray({
    control,
    name: "tools",
  });

  const {
    fields: tagsField,
    append: appendTags,
    remove: removeTags,
  } = useFieldArray({
    control,
    name: "tags",
  });

  const submitForm = async (data: RecipeFormValues) => {
    const instructionsArr = data.instructions.map((instruction) => {
      return instruction.step.trim();
    });
    const toolsArr = data.tools.map((toolItem) => {
      return toolItem.tool.trim();
    });
    // Map two part ingredient name and quantity format
    // to colon separated, single string per ingredient format
    const ingredientsArr = data.ingredients.map((ingredient) => {
      return ingredient.name + ": " + ingredient.quantity;
    });
    if (session?.user) {
      const userId = session.user.id;
      if (!recipeId) { // if aren't editing recipe, use api function to create recipe
        await addRecipe(
          data.title,
          userId,
          ingredientsArr,
          instructionsArr,
          toolsArr,
          data.prepTime,
          data.servings,
          data.difficulty,
          data.cookTime,
          data.background,
          data.nutrition,
          data.tags,
          image
        ).then(() => {
          router.push("/");
        });
      } else if (recipeId) { // if editing recipe not creating, use api function to upload updated values
        await updateRecipe(recipeId, {
          name: data.title,
          ingredients: ingredientsArr,
          procedure: instructionsArr,
          tools: toolsArr,
          prepTimeInMins: data.prepTime,
          servings: data.servings,
          difficulty: data.difficulty,
          cookTimeInMins: data.cookTime,
          background: data.background,
          nutrition: data.nutrition,
          tags: data.tags,
          photo: image,
        }).then(() => {
          router.push(`/recipe/${recipeId}`); // go to recipe page of newly updated recipe
        });
      }
    }
  };

  // Handle adding tag to array of tags
  const handleAddTag = () => {
    // Trim tag name and check that isn't duplicate of already added tag
    let hasDupe = tagsField
      .map((tag) => tag.name.toLowerCase())
      .includes(tagInput.trim().toLowerCase());
    if (tagInput.trim() !== "" && !hasDupe) {
      appendTags({ name: tagInput.trim() });
      setTagInput("");
    }
  };

  return (
    <div className={inter.className}>
      <div className={styles.bgcmain}>
        <div className={styles.squareRight}></div>
        <div className={styles.squareLeft}></div>
        <div className="flex flex-col items-center justify-center w-full mt-10">
          <AddRecipePhoto setImage={setImage} image={image} />
          <div className="w-full flex flex-col justify-center items-center">
            <form
              className="flex flex-col justify-center items-center w-full"
              onSubmit={handleSubmit(submitForm)}
            >
              <div className="mt-5 block min-w-1/2 w-1/2 p-6 bg-white border border-gray-200 rounded-2xl shadow  dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                <div className="mb-6">
                  <input
                    type="text"
                    {...register("title")}
                    placeholder="Title"
                    className="block w-full p-2 text-gray-900 border border-gray-300 rounded-lg bg-gray-50 sm:text-xl focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  />
                  {errors.title?.type === "required" && (
                    <p className="text-red-500" role="alert">
                      Title is required
                    </p>
                  )}
                </div>
                <div className="mb-6">
                  <textarea
                    {...register("background")}
                    rows={4}
                    className="block p-2.5 w-full text-md text-gray-900 bg-gray-50 rounded-lg border border-gray-300 focus:ring-blue-500 focus:border-blue-500 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                    placeholder="Share a little more about this dish"
                  ></textarea>
                </div>
                <div className="flex items-center justify-between mb-6">
                  <label className="block mt-2 text-md text-gray-900 dark:text-white">
                    Servings
                  </label>
                  <input
                    type="number"
                    min="0"
                    {...register("servings")}
                    placeholder="# of people"
                    className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  />
                  {errors.servings?.type === "required" && (
                    <p className="text-red-500" role="alert">
                      Required
                    </p>
                  )}
                </div>
                <div className="flex items-center justify-between mb-6">
                  <label className="block mt-2 text-md text-gray-900 dark:text-white">
                    Prep Time (In minutes)
                  </label>
                  <input
                    type="number"
                    min="0"
                    {...register("prepTime")}
                    placeholder="# of minutes"
                    className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  />
                  {errors.prepTime?.type === "required" && (
                    <p className="text-red-500" role="alert">
                      Required
                    </p>
                  )}
                </div>
                <div className="flex items-center justify-between mb-6">
                  <label className="block mt-2 text-md text-gray-900 dark:text-white">
                    Cook Time (In minutes)
                  </label>
                  <input
                    type="number"
                    min="0"
                    {...register("cookTime")}
                    placeholder="# of minutes"
                    className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  />
                </div>
                <div className="flex items-center justify-between mb-6">
                  <label
                    htmlFor="difficulty"
                    className="block mt-2 mr-5 text-md font-medium text-gray-900 dark:text-white"
                  >
                    Difficulty
                  </label>
                  <select
                    {...register("difficulty")}
                    id="difficulty"
                    className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  >
                    {options.map((option) => (
                      <option key={option.value} value={option.value}>
                        {option.label}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
              <div className="relative mt-2 block min-w-1/2 w-1/2 p-6 bg-white border border-gray-200 rounded-2xl shadow dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                <h1 className="text-2xl font-semibold">Ingredients</h1>
                <div>
                  <ol className="mt-4">
                    {ingredientFields.map((item, index) => (
                      <div key={item.id}>
                        <li className="flex gap-2 mb-6">
                          <label
                            htmlFor="name"
                            className="block text-sm mt-3 font-medium text-gray-700 dark:text-white"
                          >
                            Name:
                          </label>
                          <input
                            type="string"
                            {...register(`ingredients.${index}.name` as const, {
                              required: index === 0,
                            })}
                            placeholder="Ingredient name"
                            className="w-1/3 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                          />
                          <label
                            htmlFor="quantity"
                            className="block text-sm font-medium text-gray-700 mt-3 dark:text-white"
                          >
                            Quantity:
                          </label>
                          <input
                            type="string"
                            {...register(
                              `ingredients.${index}.quantity` as const,
                              {
                                required: index === 0,
                              }
                            )}
                            placeholder="Quantity"
                            className="w-1/3 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                          />
                          <button
                            type="button"
                            className="text-red-400"
                            onClick={() =>
                              ingredientFields.length !== 1
                                ? removeIngredient(index)
                                : null
                            }
                          >
                            Delete
                          </button>
                        </li>
                      </div>
                    ))}
                  </ol>
                  <div className="w-full flex justify-center items-center mt-10 -mb-5">
                    <button
                      type="button"
                      onClick={() => {
                        appendIngredient({
                          name: "",
                          quantity: "",
                        });
                      }}
                    >
                      + Ingredient
                    </button>
                  </div>
                </div>
              </div>
              <div className="relative mt-2 block min-w-1/2 w-1/2 p-6 bg-white border border-gray-200 rounded-2xl shadow dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                <h1 className="text-2xl font-semibold">Tools Used</h1>
                <div>
                  <ol className="mt-4">
                    {toolsField.map((item, index) => (
                      <li className="flex justify-between mb-6" key={index}>
                        <input
                          type="string"
                          {...register(`tools.${index}.tool` as const, {
                            required: index === 0,
                          })}
                          placeholder="ex. Sauce pan"
                          className="w-1/3 mr-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        />
                        <button
                          type="button"
                          className="text-red-400"
                          onClick={() =>
                            toolsField.length !== 1 ? removeTools(index) : null
                          }
                        >
                          Delete
                        </button>
                      </li>
                    ))}
                  </ol>
                  <div className="w-full flex justify-center items-center mt-10 -mb-5">
                    <button
                      type="button"
                      onClick={() => {
                        appendTools({
                          tool: "",
                        });
                      }}
                    >
                      + Tool
                    </button>
                  </div>
                </div>
              </div>
              <div className="relative mt-2 block min-w-1/2 w-1/2 p-6 bg-white border border-gray-200 rounded-2xl shadow dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                <h1 className="text-2xl font-semibold">Steps</h1>
                <div>
                  <ol className="mt-4">
                    {instructionsField.map((item, index) => (
                      <li className="flex mb-6" key={index}>
                        <h1 className="mt-2 mx-2">{index + 1}</h1>
                        <input
                          type="string"
                          {...register(`instructions.${index}.step` as const, {
                            required: index === 0,
                          })}
                          placeholder="Instruction"
                          className="w-full mr-2 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                        />
                        <button
                          type="button"
                          className="text-red-400"
                          onClick={() =>
                            instructionsField.length !== 1
                              ? removeInstruction(index)
                              : null
                          }
                        >
                          Delete
                        </button>
                      </li>
                    ))}
                  </ol>
                  <div className="w-full flex justify-center items-center mt-10 -mb-5">
                    <button
                      type="button"
                      onClick={() => {
                        appendInstruction({
                          step: "",
                        });
                      }}
                    >
                      + Step
                    </button>
                  </div>
                </div>
              </div>
              <div className="relative mt-2 block min-w-1/2 w-1/2 p-6 bg-white border border-gray-200 rounded-2xl shadow dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                <h1 className="text-2xl font-semibold">Nutrition Info</h1>
                <p className="text-gray-500">Optional</p>

                <div>
                  <ul className="mt-4">
                    <li className="flex items-center justify-between mb-6">
                      <label className="block mt-2 text-md text-gray-900 dark:text-white">
                        Calories
                      </label>
                      <input
                        type="number"
                        min="0"
                        {...register("nutrition.Calories")}
                        placeholder="Number of calories"
                        className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      />
                    </li>
                    <li className="flex items-center justify-between mb-6">
                      <label className="block mt-2 text-md text-gray-900 dark:text-white">
                        Fat (g)
                      </label>
                      <input
                        type="number"
                        min="0"
                        {...register("nutrition.Fat")}
                        placeholder="Number of grams of fat"
                        className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      />
                    </li>
                    <li className="flex items-center justify-between mb-6">
                      <label className="block mt-2 text-md text-gray-900 dark:text-white">
                        Carbs (g)
                      </label>
                      <input
                        type="number"
                        min="0"
                        {...register("nutrition.Carbs")}
                        placeholder="Number of grams of carbs"
                        className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      />
                    </li>
                    <li className="flex items-center justify-between mb-6">
                      <label className="block mt-2 text-md text-gray-900 dark:text-white">
                        Protein (g)
                      </label>
                      <input
                        type="number"
                        min="0"
                        {...register("nutrition.Protein")}
                        placeholder="Number of grams of protein"
                        className="w-1/4 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                      />
                    </li>
                  </ul>
                </div>
              </div>
              <div className="relative mt-2 block min-w-1/2 w-1/2 p-6 bg-white border border-gray-200 rounded-2xl shadow dark:bg-gray-800 dark:border-gray-700 dark:hover:bg-gray-700">
                <h1 className="text-2xl font-semibold">Tags</h1>
                <p className="text-gray-500 text-sm">
                  Add some tags to help people find your recipe more easily!
                </p>

                <div className="flex items-center justify-between mb-6">
                  <input
                    type="text"
                    placeholder="ex. Keto"
                    value={tagInput}
                    onChange={(e) => setTagInput(e.target.value)}
                    className="w-2/3 bg-gray-50 border border-gray-300 text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block p-2.5 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
                  />
                  <button type="button" onClick={handleAddTag}>
                    Add
                  </button>
                </div>
                <div className="flex flex-wrap -mb-4">
                  {tagsField.map((tag, index) => (
                    <div
                      key={index}
                      {...register(`tags.${index}.name`)}
                      className="flex items-center bg-red-400 text-slate-50 rounded-full px-3 py-1 mr-2 mb-2"
                    >
                      {tag.name}
                      <button
                        className="ml-2 focus:outline-none"
                        onClick={() => removeTags(index)}
                      >
                        x
                      </button>
                    </div>
                  ))}
                </div>
              </div>
              <button
                color="#84C7AE"
                className="w-1/2 text-white px-10 py-5 mt-5 mb-10 rounded-xl bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 text-xl font-medium"
                type="submit"
              >
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AddRecipe;
