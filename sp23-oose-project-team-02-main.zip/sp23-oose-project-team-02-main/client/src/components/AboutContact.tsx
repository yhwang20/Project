import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });


// Component to show ContactUs portion of About page
export default function ContactUs() {
  return (
    <div className={inter.className}>
      <div className="overflow-hidden py-24 sm:py-32">
        <p className="mt-2 text-3xl text-center font-bold tracking-tight text-gray-900 sm:text-4xl md:text-4xl lg:text-5xl">
          Contact Us
        </p>
        <p className="mt-6 text-lg text-center leading-8 text-gray-600 md:text-lg lg:text-xl">
          To contact the Reciplease team, email us at ooseteam2@gmail.com
        </p>
      </div>
    </div>
  );
}
