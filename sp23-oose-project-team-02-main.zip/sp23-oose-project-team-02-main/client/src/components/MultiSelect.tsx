import "tailwindcss/tailwind.css";
import {
  SelectChangeEvent,
  FormControl,
  Select,
  MenuItem,
  InputLabel,
  OutlinedInput,
} from "@mui/material";
import { Inter } from "@next/font/google";

const inter = Inter({ subsets: ["latin"] });

export interface MultiSelectProps {
  options: string[];
  title: string;
  selectedOption: string[];
  setSelectedOption: any;
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;

const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 180,
    },
  },
};

// Dropdown component,
// accepts dropdown title, options, parent state variable and setter as props
function MultiSelect(props: MultiSelectProps) {
  const { title, options, selectedOption, setSelectedOption } = props;
  const handleChange = (event: SelectChangeEvent<typeof selectedOption>) => {
    const {
      target: { value },
    } = event;
    setSelectedOption(typeof value === "string" ? value.split(",") : value);
  };
  return (
    <main>
      <div className={inter.className}>
        <FormControl sx={{ m: 1, width: 155 }}>
          <InputLabel id="demo-multiple-name-label">{title}</InputLabel>
          <Select
            labelId="demo-multiple-name-label"
            id="demo-multiple-name"
            multiple
            value={selectedOption}
            onChange={handleChange}
            input={<OutlinedInput label="options" />}
            MenuProps={MenuProps}
            className="bg-white"
            data-testid="combobox"
          >
            {options.map((option) => (
              <MenuItem key={option} value={option}>
                {option}
              </MenuItem>
            ))}
          </Select>
        </FormControl>
      </div>
    </main>
  );
}

export default MultiSelect;
