"use client";
import { Avatar, Dropdown, Navbar, Modal } from "flowbite-react";
import React, { useState, useEffect } from "react";
import LogIn from "./LogIn";
import { useSession, signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function Header() {
  const { data: session } = useSession();
  const [modalState, setModalState] = useState(false);
  const [isBrowser, setIsBrowser] = useState(false);
  const routing = useRouter();
  useEffect(() => {
    setIsBrowser(typeof window !== "undefined");
  }, []);

  useEffect(() => {
    if (session?.user && !session.user.setupComplete) {
      routing.push("/user/setexperience");
    }
  }, [session]);

  const onClick = () => {
    setModalState(true);
  };

  const onClose = () => {
    setModalState(false);
  };

  function handleSignOut(): void {
    signOut();
  }

  function handleClickSettings() {
    routing.push("/user/profile");
  }
  function handleClickRecipes() {
    routing.push("/user/me/recipes");
  }
  function handleClickAbout() {
    routing.push("/about");
  }

  return (
    <>
      {isBrowser ? (
        <React.Fragment>
          <Modal show={modalState} size="lg" popup={true} onClose={onClose}>
            <Modal.Header />
            <Modal.Body>
              <LogIn setModalState={setModalState} />
            </Modal.Body>
          </Modal>
        </React.Fragment>
      ) : (
        <> </>
      )}
      <Navbar fluid={true} rounded={true} className="navbar">
        <Link href="/">
          <img
            src="/Logo.svg"
            className="mr-3 h-6 sm:h-9"
            alt="ReciPlease Logo"
          />
        </Link>
        {session?.user ? (
          <div className="flex md:order-3">
            <button
              type="button"
              onClick={() => routing.push("/recipe/new")}
              color="#84C7AE"
              className="text-white px-10 mr-10 rounded-xl bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 text-md font-medium"
            >
              New
            </button>
            <Dropdown
              arrowIcon={false}
              inline={true}
              label={
                <Avatar
                  alt="User settings"
                  img={session.user ? session.user.image : ""}
                  rounded={true}
                />
              }
            >
              <Dropdown.Header>
                <span className="block text-sm">
                  {session.user ? session.user.username : " "}
                </span>
                <span className="block truncate text-sm font-medium">
                  {session.user ? session.user.email : " "}
                </span>
              </Dropdown.Header>
              <Dropdown.Item onClick={handleClickRecipes}>
                My Recipes
              </Dropdown.Item>
              <Dropdown.Item onClick={handleClickSettings}>
                Settings
              </Dropdown.Item>
              <Dropdown.Item onClick={handleClickAbout}>About Us</Dropdown.Item>
              <Dropdown.Divider />
              <Dropdown.Item color="red" onClick={handleSignOut}>
                Sign out
              </Dropdown.Item>
            </Dropdown>
          </div>
        ) : (
          <div className="flex md:order-3">
            <Navbar.Collapse>
              <>
                <div className="cursor-pointer" onClick={onClick}>
                  Login
                </div>
              </>
            </Navbar.Collapse>
          </div>
        )}
      </Navbar>
    </>
  );
}
