"use client";
import "tailwindcss/tailwind.css";
import styles from "@/app/page.module.css";
import AboutHero from "../../../components/AboutHero";
import OurTeam from "../../../components/AboutOurTeam";
import Info from "../../../components/AboutInfo";
import ContactUs from "../../../components/AboutContact";

// About Us page including info on team members, mission, and story
export default function Profile() {
  return (
    <div className={styles.bgc}>
      <AboutHero></AboutHero>
      <hr className="my-12 h-px border-t-0 bg-transparent bg-gradient-to-r from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100" />
      <OurTeam></OurTeam>
      <hr className="my-12 h-px border-t-0 bg-transparent bg-gradient-to-r from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100" />
      <Info></Info>
      <hr className="my-12 h-px border-t-0 bg-transparent bg-gradient-to-r from-transparent via-neutral-500 to-transparent opacity-25 dark:opacity-100" />
      <ContactUs></ContactUs>
    </div>
  );
}
