import React from "react";

// Used to display Loading icon
export default function Loading() {
  return <>{/* <div className={styles.loader}></div> */}</>;
}
