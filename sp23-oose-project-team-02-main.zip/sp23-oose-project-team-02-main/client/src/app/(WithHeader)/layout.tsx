"use client";
import Header from "../../components/Header";
import "../../styles/index.css";
import { SessionProvider } from "next-auth/react";

// Layout for all pages with Header
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>
        <SessionProvider>
          <Header />
          {children}
        </SessionProvider>
      </body>
    </html>
  );
}
