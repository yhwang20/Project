import AddRecipe from "@/components/AddRecipe";
import React from "react";
type Params = {
  params: {
    recipeId: string;
  };
};
// Page to allow user to edit a recipe they've created
function editRecipeView({ params: { recipeId } }: Params) {
  return (
    <div>
      <AddRecipe recipeId={recipeId} />
    </div>
  );
}

export default editRecipeView;
