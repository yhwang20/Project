"use client";
import "tailwindcss/tailwind.css";
import styles from "@/app/page.module.css";
import RecipeDisplay from "../../../../components/RecipeDisplay";
import { Recipe } from "recipe-types";
import { getRecipe } from "@/pages/api/recipeAPI";
import { useEffect, useState } from "react";

type Params = {
  params: {
    recipeId: string;
  };
};
// Page to allow user to view single recipe
export default function RecipeView({ params: { recipeId } }: Params) {
  /* uses styles.main to display recipe centered in the window */
  const [recipe, setRecipe] = useState<Recipe | undefined>();
  useEffect(() => {
    const retrieveRecipe = async () => {
      const retrievedRecipe = await getRecipe(recipeId);
      if (!retrievedRecipe) {
        window.location.href = "/404";
      }
      setRecipe(retrievedRecipe);
    };
    retrieveRecipe();
  }, [recipeId]);
  return (
    <>
      <RecipeDisplay recipe={recipe}></RecipeDisplay>
    </>
  );
}
