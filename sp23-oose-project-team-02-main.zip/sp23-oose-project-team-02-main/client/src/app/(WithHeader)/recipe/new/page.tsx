"use client";
import "tailwindcss/tailwind.css";
import AddRecipe from "@/components/AddRecipe";

// Page to allow user to create new recipe
export default function AddRecipeView() {
  return (
    <main>
      <div>
        <AddRecipe></AddRecipe>
      </div>
    </main>
  );
}
