"use client";
import React, { useState, useEffect } from "react";
import { usePathname, useSearchParams } from "next/navigation";
import { searchRecipes } from "@/pages/api/recipeAPI";
import SearchBar from "@/components/SearchBar";
import styles from "@/app/page.module.css";
import RecipeCardGrid from "@/components/RecipeCardGrid";
import { useRouter } from "next/navigation";
import { Recipe } from "recipe-types";
import MyModal from "@/components/AdvancedFilter";
import Loading from "@/app/(WithoutHeader)/loading";
import { useSession } from "next-auth/react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

// Search results page, also contains search bar, advanced filter pane, and sorting
export default function SearchView() {
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [query, setQuery] = useState<string>("");
  const [includedTags, setIncludedTags] = useState<string[]>([]);
  const [excludedTags, setExcludedTags] = useState<string[]>([]);
  const [includeIngredients, setIncludeIngredients] = useState<string[]>([]);
  const [excludeIngredients, setExcludeIngredients] = useState<string[]>([]);
  const searchParams = useSearchParams();
  const pathname = usePathname();
  const [loading, setLoading] = useState<boolean>(false);
  const [currCookingTime, updateCookingTime] = useState<string>("");
  const [currRating, updateRating] = useState<string>("");
  const [currPrepTime, updatePrepTime] = useState<string>("");
  const [currDifficulty, updateDifficulty] = useState<string>("");
  const [advancedSearch, setAdvancedSearch] = useState<boolean>(false);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [currSort, updateSort] = useState<string>("relevance");
  const { data: session } = useSession();
  const router = useRouter();
  const [includeUserParam, setIncludeUserParam] =  useState<boolean>(true); //to include user id in search params


  useEffect(() => {
    const retrieveRecipesAdvanced = async () => {
      if (searchParams) {
        setQuery(searchParams.get("query")!);
        const cookingParams = searchParams.get("cookingTime");
        const ratingParams = searchParams.get("rating");
        const prepParams = searchParams.get("prepTime");
        const includedTagParams = searchParams.get("includedTags");
        const excludedTagParams = searchParams.get("excludedTags");
        const includedIngredientsParams =
          searchParams.get("includeIngredients");
        const excludedIngredientsParams =
          searchParams.get("excludeIngredients");
        const difficultyParams = searchParams.get("maxDifficulty");
        const userIdParams = searchParams.get("userId");
        const sort = searchParams.get("sort");
        let includedTagsArr = [] as string[];
        let excludedTagsArr = [] as string[];
        let includedIngredientsArr = [] as string[];
        let excludedIngredientsArr = [] as string[];
        if (includedTagParams) {
          includedTagParams.split(",").forEach((tag: string) => {
            includedTagsArr.push(tag);
          });
        }
        if (excludedTagParams) {
          excludedTagParams.split(",").forEach((tag: string) => {
            excludedTagsArr.push(tag);
          });
        }
        if (includedIngredientsParams) {
          includedIngredientsParams.split(",").forEach((ingredient: string) => {
            includedIngredientsArr.push(ingredient);
          });
        }
        if (excludedIngredientsParams) {
          excludedIngredientsParams.split(",").forEach((ingredient: string) => {
            excludedIngredientsArr.push(ingredient);
          });
        }
        setLoading(true);
        const returnedRecipesAdvanced = await searchRecipes(
          searchParams.get("query")!,
          includedTagsArr,
          excludedTagsArr,
          prepParams ? prepParams : "",
          cookingParams ? cookingParams : "",
          ratingParams ? ratingParams : "",
          includedIngredientsArr,
          excludedIngredientsArr,
          difficultyParams ? difficultyParams : "",
          userIdParams as string | undefined
        );
        setLoading(false);
        return returnedRecipesAdvanced;
      }
    };

    retrieveRecipesAdvanced().then((recipe) => {
      setRecipes(recipe);
    });
  }, [searchParams, pathname]);


  const handleIgnore = (ignore: boolean) => {
    setIncludeUserParam(!ignore);
  }


  // Construct urlString based on which parameters are defined and trigger new search
  const handleSearch = () => {
    let urlString = "/results?";
    if (!query) {
      urlString += "query=";
    } else {
      urlString += "query=" + query;
    }
    if (session?.user.id && includeUserParam) {
      urlString += `&userId=${session.user.id}`;
    }


      if (includedTags && includedTags.length != 0) {

        urlString += "&includedTags=" + includedTags.join(",");
      }
      if (excludedTags && excludedTags.length != 0) {
        urlString += "&excludedTags=" + excludedTags.join(",");
      }
      if (currCookingTime != "") {
        urlString += "&cookingTime=" + currCookingTime;
      }
      if (currPrepTime != "") {
        urlString += "&prepTime=" + currPrepTime;
      }
      if (currRating != "") {
        urlString += `&rating=${currRating}`;
      }

      if (includeIngredients && includeIngredients.length != 0) {
        urlString += "&includeIngredients=" + includeIngredients.join(",");
      }
      if (excludeIngredients && excludeIngredients.length != 0) {
        urlString += "&excludeIngredients=" + excludeIngredients.join(",");
      }


      // Converts string difficulty to number
      if (currDifficulty != "") {
        let difficultyInt = 0;
        switch (currDifficulty) {
          case "Beginner":
            difficultyInt = 1;
            break;
          case "Easy":
            difficultyInt = 2;
            break;
          case "Medium":
            difficultyInt = 3;
            break;
          case "Hard":
            difficultyInt = 4;
            break;
          case "Pro":
            difficultyInt = 5;
            break;
          default:
            difficultyInt = 5;
            break;
        }
        urlString += `&maxDifficulty=${difficultyInt}`;
      }
    setAdvancedSearch(!advancedSearch);
    router.push(urlString);
  };

  // Comparator for difficulties, used in sorting ascending
  const compdiffAsc = (a: any, b: any) => {
    if (a.difficulty < b.difficulty) {
      return -1;
    } else if (a.difficulty > b.difficulty) {
      return 1;
    } else {
      return 0;
    }
  };

  // Comparator for difficulties, used in sorting descending
  const compdiffDesc = (a: any, b: any) => {
    if (a.difficulty < b.difficulty) {
      return 1;
    } else if (a.difficulty > b.difficulty) {
      return -1;
    } else {
      return 0;
    }
  };

  // Comparator for times, used in sorting
  const compdiffTime = (a: any, b: any) => {
    if (
      a.cookTimeInMins + a.prepTimeInMins <
      b.cookTimeInMins + b.prepTimeInMins
    ) {
      return -1;
    } else if (
      a.cookTimeInMins + a.prepTimeInMins >
      b.cookTimeInMins + b.prepTimeInMins
    ) {
      return 1;
    } else {
      return 0;
    }
  };

  // Comparator for ratings, used in sorting
  const compRating = (a: any, b: any) => {
    if (a.avgRating > b.avgRating) {
      return -1;
    } else if (a.avgRating < b.avgRating) {
      return 1;
    } else {
      return 0;
    }
  };

  // Resorts recipes if sort value is changed
  const handleSortChange = (e: React.ChangeEvent<HTMLSelectElement>) => {
    updateSort(e.target.value);
    if (e.target.value === "rating") {
      const sortedRecipes = [...recipes].sort(compRating);
      setRecipes(sortedRecipes);
    } else if (e.target.value === "time") {
      const sortedByTime = [...recipes].sort(compdiffTime);
      setRecipes(sortedByTime);
    } else if (e.target.value === "difficulty-low") {
      const sortedByDifficultyLow = [...recipes].sort(compdiffAsc);
      setRecipes(sortedByDifficultyLow);
    } else if (e.target.value === "difficulty-high") {
      const sortedByDifficultyHigh = [...recipes].sort(compdiffDesc);
      setRecipes(sortedByDifficultyHigh);
    }
  };

  // Handle closing advanced filter pane
  const handleClose = (applyFilter: boolean) => {
    if (applyFilter) {
      toast.success("Filters applied! Click search to see results", {
        autoClose: 2000,
      });
    }
    setShowAdvanced(false);
  };
  

  return (
    <div className={styles.bgcmain}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>
      <div className="mt-5 flex flex-row justify-center">
        <form>
          <label
            form="recipe-search"
            className="mt-2 text-sm font-medium text-gray-900 sr-only dark:text-white "
          >
            Search
          </label>
          <div className="relative">
            <SearchBar
              query={query}
              updateQuery={setQuery}
              handleSearch={handleSearch}
            ></SearchBar>
            <button
              type="button"
              onClick={handleSearch}
              className="text-white absolute left-[33rem] bottom-2.5 rounded-xl bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium text-md px-6 py-2"
            >
              Search
            </button>
          </div>
        </form>
        <select
          id="sorting"
          className="bg-white-100 shadow text-center border-white text-gray-900 text-sm rounded-lg focus:ring-blue-500 focus:border-blue-500 block w-1/6 p-2 ml-6 dark:bg-gray-700 dark:border-gray-600 dark:placeholder-gray-400 dark:text-white dark:focus:ring-blue-500 dark:focus:border-blue-500"
          value={currSort}
          onChange={handleSortChange}
        >
          <option disabled selected defaultValue="">
            Sort by
          </option>
          <option value="rating">Rating</option>
          <option value="time">Time</option>
          <option value="difficulty-low">Difficulty (Low to High)</option>
          <option value="difficulty-high">Difficulty (High to Low)</option>
        </select>
        <button
          type="button"
          onClick={() => setShowAdvanced(true)}
          className="flex w-1/6 ml-6 justify-center rounded-2xl  bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl py-4 px-3 text-lg font-semibold text-white hover:border-green-500 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        >
          Filters
        </button>
      </div>
      <MyModal
        onClose={handleClose}
        visible={showAdvanced}
        includeTags={includedTags}
        excludeTags={excludedTags}
        includeIngredients={includeIngredients}
        excludeIngredients={excludeIngredients}
        setIncludeTags={setIncludedTags}
        setExcludeTags={setExcludedTags}
        setIncludeIngredients={setIncludeIngredients}
        setExcludeIngredients={setExcludeIngredients}
        currCookingTime={currCookingTime}
        updateCookingTime={updateCookingTime}
        currRating={currRating}
        updateRating={updateRating}
        currPrepTime={currPrepTime}
        currDifficulty={currDifficulty}
        updateDifficulty={updateDifficulty}
        updatePrepTime={updatePrepTime}
        handleSearch={handleSearch}
        handleIgnore={handleIgnore}
      />
      <ToastContainer position="bottom-right" theme="colored" />
      <div className="flex flex-row justify-center my-10 ml-10">
        {loading ? <Loading /> : <RecipeCardGrid recipes={recipes} />}
      </div>
    </div>
  );
}
