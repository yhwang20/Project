"use client";
import React, { Suspense, use, useState, useEffect } from "react";
import { useSearchParams } from "next/navigation";
import { getRecipes, searchRecipes } from "@/pages/api/recipeAPI";
import SearchBar from "@/components/SearchBar";
import styles from "@/app/page.module.css";
import { useRouter } from "next/navigation";
import { Recipe } from "recipe-types";
import Loading from "./loading";
import MyModal from "@/components/AdvancedFilter";
import { Carousel } from "flowbite-react";
import RecipeCard from "@/components/RecipeCard";
import { Inter } from "@next/font/google";
const inter = Inter({ subsets: ["latin"] });
import { useSession } from "next-auth/react";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";

//Weighted rating function based on IMDB's weighted rating formula
function weightedRating(rating: number, numRatings: number) {
  const R = rating;
  const v = numRatings;
  const m = 1;
  const C = 2.5;
  return (v / (v + m)) * R + (m / (v + m)) * C;
}

//Compares two weighted ratings
// Used as passed comparator in calculating recipes with highest ratings
function compareRating(a: Recipe, b: Recipe) {
  const aRating = weightedRating(a.avgRating, a.reviews.length);
  const bRating = weightedRating(b.avgRating, b.reviews.length);

  if (aRating > bRating) {
    return -1;
  }
  if (aRating < bRating) {
    return 1;
  }
  return 0;
}

// Compares times two recipes were created at
// Used as passed comparator in calculating most recently created recipes
function compareCreatedTime(a: Recipe, b: Recipe) {
  const aCreatedTime = a.createdAt;
  const bCreatedTime = b.createdAt;

  if (aCreatedTime > bCreatedTime) {
    return -1;
  }
  if (aCreatedTime < bCreatedTime) {
    return 1;
  }
  return 0;
}

// Compares number of views of two recipes
// Used as passed comparator in calculating most viewed recipes
function compareViews(a: Recipe, b: Recipe) {
  const aViews = a.views;
  const bViews = b.views;

  if (aViews > bViews) {
    return -1;
  }
  if (aViews < bViews) {
    return 1;
  }
  return 0;
}

// Compares number of favorites of two recipes
// Used as passed comparator in calculating most favorited recipes
function compareFavorites(a: Recipe, b: Recipe) {
  const aFavorites = a.favoritedBy ? a.favoritedBy.length : 0;
  const bFavorites = b.favoritedBy ? b.favoritedBy.length : 0;

  if (aFavorites > bFavorites) {
    return -1;
  }
  if (aFavorites < bFavorites) {
    return 1;
  }
  return 0;
}

// App's home page
export default function SearchView() {
  const [currQuery, updateQuery] = useState<string>("");
  const searchParams = useSearchParams();
  const [recipes, setRecipes] = useState<Recipe[]>([]);
  const [recipesByRating, setRecipesByRating] = useState<Recipe[]>([]);
  const [recipesByViews, setRecipesByViews] = useState<Recipe[]>([]);
  const [recipesByFavorites, setRecipesByFavorites] = useState<Recipe[]>([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [includedTags, setIncludedTags] = useState<string[]>([]);
  const [excludedTags, setExcludedTags] = useState<string[]>([]);
  const [includeIngredients, setIncludeIngredients] = useState<string[]>([]);
  const [excludeIngredients, setExcludeIngredients] = useState<string[]>([]);
  const [showAdvanced, setShowAdvanced] = useState(false);
  const [currCookingTime, updateCookingTime] = useState<string>("");
  const [currRating, updateRating] = useState<string>("");
  const [currPrepTime, updatePrepTime] = useState<string>("");
  const [currDifficulty, updateDifficulty] = useState<string>("");
  const router = useRouter();
  const [width, setWidth] = useState<number>(0);
  const [includeUserParam, setIncludeUserParam] = useState<boolean>(true);

  const { data: session } = useSession();

  // Handle close of advanced filter pane
  const handleClose = (applyFilter: boolean) => {

    if (applyFilter) { // if user applied filter, show message saying so
      toast.success("Filters applied! Click search to see results", {
        autoClose: 2000,
      });


    }
    setShowAdvanced(false);
  };
  const handleResize = () => setWidth(window.innerWidth);
  useEffect(() => {
    window.addEventListener("resize", handleResize);
    return () => window.removeEventListener("resize", handleResize);
  }, [width]);

  // Set parameter determining whether userPreferences filters are applied
  const handleIgnore = (ignore: boolean) => {
    setIncludeUserParam(!ignore);
  };

  useEffect(() => {
    // Get all recipes
    const retrieveRecipes = async () => {
      setLoading(true);
      const returnedRecipes = await getRecipes();
      setLoading(false);
      return returnedRecipes;
    };
    retrieveRecipes().then((recipe) => {
      // Calculate most recent recipes
      const earliestRecipes = recipe.sort(compareCreatedTime);
      const slicedRecipes = earliestRecipes.slice(0, 4);
      setRecipes(slicedRecipes);
      // Calculate most highly rated recipes
      const sortedRecipesByRating = recipe.sort(compareRating);
      const top5RecipesByRating = sortedRecipesByRating.slice(0, 5);
      setRecipesByRating(top5RecipesByRating);
      // Calculate most viewed recipes
      const sortedRecipesByViews = recipe.sort(compareViews);
      const top4RecipesByViews = sortedRecipesByViews.slice(0, 4);
      setRecipesByViews(top4RecipesByViews);
      // Calculate most favorited recipes
      const sortedRecipesByFavorites = recipe.sort(compareFavorites);
      const top4RecipesByFavorites = sortedRecipesByFavorites.slice(0, 4);
      setRecipesByFavorites(top4RecipesByFavorites);
    });
  }, []);

  // Handles chatbot search button being clicked
  const handleChatbot = () => {
    router.push("/chatbot");
  };

  // Construct url from defined search parameters and trigger search by going to results page
  const handleSearch = () => {
    let urlString = "/results?";
    if (!currQuery) {
      urlString += "query=";
    } else {
      urlString += "query=" + currQuery;
    }
    if (session?.user.id && includeUserParam) {
      urlString += `&userId=${session.user.id}`;
    }

    if (includedTags && includedTags.length != 0) {
      urlString += "&includedTags=" + includedTags.join(",");
    }
    if (excludedTags && excludedTags.length != 0) {
      urlString += "&excludedTags=" + excludedTags.join(",");
    }
    if (currCookingTime != "") {
      urlString += "&cookingTime=" + currCookingTime;
    }
    if (currPrepTime != "") {
      urlString += "&prepTime=" + currPrepTime;
    }
    if (currRating != "") {
      urlString += `&rating=${currRating}`;
    }
    if (includeIngredients && includeIngredients.length != 0) {
      urlString += "&includeIngredients=" + includeIngredients.join(",");
    }
    if (excludeIngredients && excludeIngredients.length != 0) {
      urlString += "&excludeIngredients=" + excludeIngredients.join(",");
    }
    // Converts string difficulty to number
    if (currDifficulty != "") {
      let difficultyInt = 0;
      switch (currDifficulty) {
        case "Beginner":
          difficultyInt = 1;
          break;
        case "Easy":
          difficultyInt = 2;
          break;
        case "Medium":
          difficultyInt = 3;
          break;
        case "Hard":
          difficultyInt = 4;
          break;
        case "Pro":
          difficultyInt = 5;
          break;
        default:
          difficultyInt = 5;
          break;
      }
      urlString += `&maxDifficulty=${difficultyInt}`;
    }
    router.push(urlString);
  };

  return (
    <div className={styles.bgcmain}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>
      <div className="-mt-2 md:mt-5 flex flex-row justify-center">
        <form>
          <label
            form="recipe-search"
            className="mt-2 text-sm font-medium text-gray-700 sr-only dark:text-white "
          >
            Search
          </label>
          <div className="relative">
            <SearchBar
              query={currQuery}
              updateQuery={updateQuery}
              handleSearch={handleSearch}
            ></SearchBar>
            <button
              type="button"
              onClick={handleSearch}
              className="text-white absolute left-[11.6rem] md:left-[33rem] bottom-[0.05rem] md:bottom-2 rounded-lg md:rounded-xl bg-gradient-to-br from-[#75628e] to-[#907ea7]  hover:bg-gradient-to-bl focus:ring-4 focus:outline-none focus:ring-blue-300 font-medium text-xs md:text-lg md:px-6 px-1 py-5 md:py-2"
            >
              Search
            </button>
          </div>
        </form>
        <button
          type="button"
          onClick={() => setShowAdvanced(true)}
          className="text-xs md:text-lg w-1/6 md:ml-6 rounded-md md:rounded-xl  bg-gradient-to-br from-[#75628e] to-[#907ea7] hover:bg-gradient-to-bl md:py-4 md:px-3 font-semibold text-white hover:border-green-500 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        >
          Filters
        </button>
        <button
          type="button"
          disabled={true}
          onClick={() => handleChatbot()}
          className="text-xs md:text-lg w-1/6 md:ml-6 rounded-md md:rounded-xl bg-gray-500 hover:bg-gradient-to-bl md:py-4 md:px-3 font-semibold text-white hover:border-green-500 hover:borderfocus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-indigo-600"
        >
          AI Search
        </button>
      </div>
      {loading ? (
        <div className="mt-60">
          <Loading />
        </div>
      ) : (
        <div className={inter.className}>
          <div className="block">
            <div className="flex flex-col md:ml-3">
              <h1 className="ml-8 text-3xl text-[#5b4b6f] font-bold mt-10">
                Latest Recipes
              </h1>
              <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 xl:grid-cols-3 2xl:grid-cols-4 gap-1 max-w-full md:max-w-full mt-2 ml-6">
                {recipes
                  .slice(0, width >= 1536 ? 4 : 3)
                  .map((recipe, index) => (
                    <RecipeCard recipe={recipe} key={index} />
                  ))}
              </div>
            </div>
          </div>

          <div className="flex flex-col md:ml-3">
            <h1 className="ml-8 text-3xl text-[#5b4b6f] font-bold mt-10">
              Most Viewed Recipes
            </h1>
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 2xl:grid-cols-4 gap-1 max-w-full md:max-w-full mt-2 ml-6">
              {recipesByViews
                .slice(0, width >= 1536 ? 4 : 3)
                .map((recipe, index) => (
                  <RecipeCard recipe={recipe} key={index} />
                ))}

            </div>
          </div>

          <div className="flex flex-col md:ml-3">
            <h1 className="ml-8 text-3xl text-[#5b4b6f] font-bold mt-10">
              Most Favorited Recipes
            </h1>

 
            <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-3 2xl:grid-cols-4 gap-1 max-w-full md:max-w-full mt-2 ml-6 ">
              {recipesByFavorites
                .slice(0, width >= 1536 ? 4 : 3)
                .map((recipe, index) => (
                  <RecipeCard recipe={recipe} key={index} />
                ))}
            </div>
          </div>
          <div className="flex flex-col md:ml-5">
            <h1 className="ml-6 text-3xl text-[#5b4b6f] font-bold mt-10">
              Highest Rated Recipes
            </h1>
            <div className="max-w-sm min-w-sm ml-4 mt-2 h-[30rem] max-h-[35rem] flex align-items justify-center">
              <Carousel>
                {recipesByRating.map((recipe, index) => (
                  <RecipeCard recipe={recipe} key={index} />
                ))}
              </Carousel>
            </div>
          </div>

        </div>
      )}
      <MyModal
        onClose={handleClose}
        visible={showAdvanced}
        includeTags={includedTags}
        excludeTags={excludedTags}
        includeIngredients={includeIngredients}
        excludeIngredients={excludeIngredients}
        setIncludeTags={setIncludedTags}
        setExcludeTags={setExcludedTags}
        setIncludeIngredients={setIncludeIngredients}
        setExcludeIngredients={setExcludeIngredients}
        currCookingTime={currCookingTime}
        updateCookingTime={updateCookingTime}
        currRating={currRating}
        updateRating={updateRating}
        currPrepTime={currPrepTime}
        updatePrepTime={updatePrepTime}
        currDifficulty={currDifficulty}
        updateDifficulty={updateDifficulty}
        handleSearch={handleSearch}
        handleIgnore={handleIgnore}
      />
      <ToastContainer position="bottom-right" theme="colored" />
    </div>
  );
}
