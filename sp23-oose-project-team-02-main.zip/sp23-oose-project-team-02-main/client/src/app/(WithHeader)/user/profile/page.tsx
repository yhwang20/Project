import "tailwindcss/tailwind.css";
import styles from "@/app/page.module.css";
import UserInfo from "../../../../components/UserInfo";
import UserPrefs from "../../../../components/UserPrefs";

// Page to allow users to view their account settings
export default function Profile() {
  return (
    <div className={styles.mainSignIn}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>
      <div className="container lg:m-auto grid grid-cols-2 place-items-center justify-center">
        <UserInfo></UserInfo>
        <UserPrefs></UserPrefs>
      </div>
    </div>
  );
}
