import { useSession } from "next-auth/react";
import "tailwindcss/tailwind.css";
import styles from "@/app/page.module.css";
import UserInfo from "../../../../../components/UserInfo";
import UserPrefs from "../../../../../components/UserPrefs";
import UserRecipes from "@/components/UserRecipes";

// Page to allow users to view a list of recipes they've created
export default function savedRecipes() {
  return (
    <div className={styles.bgcmain}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>
      <UserRecipes />
    </div>
  );
}
