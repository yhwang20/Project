import React from "react";
import styles from "@/app/page.module.css";
import UserFavorites from "@/components/UserFavorites";

// Page to allow users to view a list of recipes they've favorited
function favoritesPage() {
  return (
    <div className={styles.bgcmain}>
      <div className={styles.squareRight}></div>
      <div className={styles.squareLeft}></div>
      <UserFavorites />
    </div>
  );
}

export default favoritesPage;
