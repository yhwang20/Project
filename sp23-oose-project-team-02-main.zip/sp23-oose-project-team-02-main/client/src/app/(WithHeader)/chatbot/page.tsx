"use client";
import "tailwindcss/tailwind.css";
import Chatbot from "@/components/Chatbot";
// AI powered natural language search page
export default function AddRecipeView() {
  return (
    <main>
      <div>
        <Chatbot></Chatbot>
      </div>
    </main>
  );
}
