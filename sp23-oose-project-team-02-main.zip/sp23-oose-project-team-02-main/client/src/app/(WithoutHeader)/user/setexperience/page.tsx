"use client";
import CreateExperience from "../../../../components/CreateExperience";

// Page to allow user to set their experience and cuisine preferences, post account creation
export default function CreateExperienceView() {
  return (
    <main>
      <div>
        <CreateExperience></CreateExperience>
      </div>
    </main>
  );
}
