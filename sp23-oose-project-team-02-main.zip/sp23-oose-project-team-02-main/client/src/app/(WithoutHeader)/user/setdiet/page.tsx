"use client";
import CreateDiet from "../../../../components/CreateDiet";

// Page to allow user to set diet preferences, post account creation
export default function LogInView() {
  return (
    <main>
      <div>
        <CreateDiet></CreateDiet>
      </div>
    </main>
  );
}
