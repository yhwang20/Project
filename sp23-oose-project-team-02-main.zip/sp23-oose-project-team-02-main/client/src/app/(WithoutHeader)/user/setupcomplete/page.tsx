"use client";
import SetupComplete from "@/components/SetupComplete";

// Page displayed at end of account setup, allows user to redirect to home
function SetupPage() {
  return <SetupComplete></SetupComplete>;
}

export default SetupPage;
