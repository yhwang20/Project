import "tailwindcss/tailwind.css";
import ConfirmEmail from "../../../../components/ConfirmEmail";

// Page telling user to check their email to confirm account
export default function ConfirmEmailView() {
  return (
    <main>
      <div>
        <ConfirmEmail></ConfirmEmail>
      </div>
    </main>
  );
}
