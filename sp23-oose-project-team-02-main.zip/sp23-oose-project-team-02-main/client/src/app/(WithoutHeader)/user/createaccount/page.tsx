"use client";
import CreateAccount from "../../../../components/CreateAccount";

// Page to allow user to log in
export default function LogInView() {
  return (
    <main>
      <div>
        <CreateAccount></CreateAccount>
      </div>
    </main>
  );
}
