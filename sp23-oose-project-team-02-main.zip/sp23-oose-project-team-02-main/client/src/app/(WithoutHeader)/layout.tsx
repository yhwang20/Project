"use client";
import "../../styles/index.css";
import { SessionProvider } from "next-auth/react";
// Layout for pages without header
export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html>
      <head />
      <body>
        <SessionProvider>{children}</SessionProvider>
      </body>
    </html>
  );
}
