import React from "react";
import styles from "@/app/page.module.css";
// Displays whirling circle icon
export default function Loading() {
  return (
    <>
      <div className={styles.loader}></div>
    </>
  );
}
