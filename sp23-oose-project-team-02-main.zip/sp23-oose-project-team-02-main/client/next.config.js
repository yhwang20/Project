/** @type {import('next').NextConfig} */
const nextConfig = {
  experimental: {
    appDir: true,
  },
  images: {
    domains: [
      "res.cloudinary.com",
      "www.simplyrecipes.com",
      "lh3.googleusercontent.com",
      "img.freepik.com",
    ],
  },
};

module.exports = nextConfig; /* {
  preset: 'ts-jest',
  testEnvironment: 'jsdom',
  // other configurations
  transform: {
    "^.+\\.tsx?$": "babel-jest",
  },
  testRegex: "(/__tests__/.*|(\\.|/)(test|spec))\\.(jsx?|tsx?)$",
};

*/
