import React from "react";
import { render } from "@testing-library/react";
import Review from "../src/components/Review";
import "@testing-library/jest-dom";

describe("Review", () => {
  const review = {
    score: 3,
    user: {
      username: "Alice",
    },
    comment: "This is a review",
  };

  it("renders the user's username and avatar", () => {
    const { getByText } = render(<Review review={review} />);
    expect(getByText("Alice")).toBeInTheDocument();
  });

  it("renders the correct number of filled and empty stars", () => {
    const { getByText } = render(<Review review={review} />);
    expect(getByText("Fifth star")).toBeInTheDocument();
  });
});
