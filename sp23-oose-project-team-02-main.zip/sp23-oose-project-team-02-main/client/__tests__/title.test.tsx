import React from "react";
import { render, screen } from "@testing-library/react";
import Title from "../src/components/Title";
import "@testing-library/jest-dom";

describe("Title", () => {
  it("renders the title card with the correct text", () => {
    render(<Title />);
    const titleElement = screen.getByText("ReciPlease");
    expect(titleElement).toBeInTheDocument();
  });
});
