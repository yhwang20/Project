import React from "react";
import { render, fireEvent, screen } from "@testing-library/react";
import Dropdown, { DropdownProps } from "../src/components/Dropdown";
import "@testing-library/jest-dom";

describe("Dropdown", () => {
  const options = ["Option 1", "Option 2", "Option 3"];
  const title = "Select an option";
  const selectedOption = "Option 2";
  const setSelectedOption = jest.fn();

  const props: DropdownProps = {
    options,
    title,
    selectedOption,
    setSelectedOption,
  };

  it("should render the title and options", () => {
    const { getByText } = render(<Dropdown {...props} />);
    expect(getByText(title)).toBeInTheDocument();

    expect(getByText("Option 2")).toBeInTheDocument();
  });

  it("renders with default props", () => {
    render(<Dropdown {...props} />);
    expect(screen.getByText(title)).toBeInTheDocument();
    expect(screen.getByText(selectedOption)).toBeInTheDocument();
    expect(screen.queryAllByRole("option")).toHaveLength(0);
  });
});
