import { render, screen } from "@testing-library/react";
import RecipeCardGrid from "../src/components/RecipeCardGrid";
import { Recipe } from "recipe-types";
import "@testing-library/jest-dom";

const dateString: string = "2023-04-07T10:30:00Z";
const date1: Date = new Date(dateString);

const dateString2: string = "2023-04-08T10:30:00Z";
const date2: Date = new Date(dateString2);

const a: Recipe = {
  id: "1",
  name: "Spaghetti Carbonara",
  photo: "/spaghetti-carbonara.jpg",
  prepTimeInMins: 10,
  cookTimeInMins: 20,
  difficulty: 2,
  avgRating: 4.5,
  author: undefined,
  ingredients: [],
  procedure: [],
  tools: [],
  servings: 0,
  nutrition: undefined,
  authorID: "",
  views: 0,
  createdAt: date1,
  updatedAt: date2,
  tags: [],
  reviews: [],
  favoritedBy: [],
};

const b: Recipe = {
  id: "2",
  name: "Pad Thai",
  photo: "/pad-thai.jpg",
  prepTimeInMins: 15,
  cookTimeInMins: 25,
  difficulty: 2,
  avgRating: 4,
  author: undefined,
  ingredients: [],
  procedure: [],
  tools: [],
  servings: 0,
  nutrition: undefined,
  createdAt: date1,
  updatedAt: date2,
  authorID: "",
  views: 0,
  tags: [],
  reviews: [],
  favoritedBy: [],
};

const mockRecipes = [a, b];

describe("RecipeCardGrid component", () => {
  it("renders a list of recipe cards", () => {
    render(<RecipeCardGrid recipes={mockRecipes} />);

    // Check that each recipe card is rendered
    mockRecipes.forEach((recipe) => {
      const recipeCard = screen.getByText(recipe.name);
      expect(recipeCard).toBeInTheDocument();
    });
  });
});
