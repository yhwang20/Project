import { render, fireEvent } from "@testing-library/react";
import RecipesNavbar from "../src/components/RecipesNavbar";
import React from "react";
import "@testing-library/jest-dom";

test("renders two navigation links", () => {
  const { getByText } = render(<RecipesNavbar isRecipes={true} />);
  const yourRecipesLink = getByText("Your Recipes");
  const savedLink = getByText("Saved");
  expect(yourRecipesLink).toBeInTheDocument();
  expect(savedLink).toBeInTheDocument();
});

test("applies active class to the correct link", () => {
  const { getByText } = render(<RecipesNavbar isRecipes={false} />);
  const yourRecipesLink = getByText("Your Recipes");
  const savedLink = getByText("Saved");
  expect(yourRecipesLink).not.toHaveClass("border-orange-500");
  expect(savedLink).toHaveClass(
    "tracking-wider block hover:text-gray-700 p-sm xs:p-rg"
  );
});

test("changes active link when clicked", () => {
  const { getByText } = render(<RecipesNavbar isRecipes={true} />);
  const yourRecipesLink = getByText("Your Recipes");
  const savedLink = getByText("Saved");
  fireEvent.click(savedLink);
  expect(yourRecipesLink).not.toHaveClass("border-orange-500");
  expect(savedLink).toHaveClass(
    "tracking-wider block hover:text-gray-700 p-sm xs:p-rg"
  );
});
