import { render, screen, fireEvent } from "@testing-library/react";
import AddRecipePhoto from "../src/components/AddRecipePhoto";
import "@testing-library/jest-dom";

test("it should upload a file when the user selects an image", async () => {
  const setImage = jest.fn();
  const image = "";
  render(<AddRecipePhoto setImage={setImage} image={image} />);

  // Mock file object
  const file = new File(["test-image"], "test.png", { type: "image/png" });

  // Get input element and trigger onChange event with the mock file
  const input = screen.getByText("Upload recipe photo");
  fireEvent.change(input, { target: { files: [file] } });
});
