import React from "react";
import { render, screen, fireEvent } from "@testing-library/react";
import EditableRecipeItem from "../src/components/EditableRecipeItem";
import { Recipe } from "recipe-types";
import "@testing-library/jest-dom";

const dateString: string = "2023-04-07T10:30:00Z";
const date1: Date = new Date(dateString);

const dateString2: string = "2023-04-08T10:30:00Z";
const date2: Date = new Date(dateString2);

const recipe: Recipe = {
  id: "1",
  name: "Spaghetti Carbonara",
  photo: "/spaghetti-carbonara.jpg",
  prepTimeInMins: 10,
  cookTimeInMins: 20,
  difficulty: 2,
  avgRating: 4.5,
  author: {
    username: "testuser",
  },
  ingredients: [],
  procedure: [],
  tools: [],
  servings: 0,
  nutrition: undefined,
  authorID: "",
  views: 0,
  createdAt: date1,
  updatedAt: date2,
  tags: [],
  reviews: [],
  favoritedBy: [],
};

const handleDeleteMock = jest.fn();

describe("EditableRecipeItem", () => {
  it("renders the recipe item", () => {
    render(
      <EditableRecipeItem recipe={recipe} handleDelete={handleDeleteMock} />
    );
    expect(screen.getByText(recipe.name)).toBeInTheDocument();
    expect(screen.getByAltText("recipe photo")).toBeInTheDocument();
    expect(screen.getByText("Rating star")).toBeInTheDocument();
  });

  it("has delete button is clicked", async () => {
    render(
      <EditableRecipeItem recipe={recipe} handleDelete={handleDeleteMock} />
    );
    const deleteButton = screen.getByTestId("DeleteButton");
    fireEvent.click(deleteButton);
    expect(deleteButton).toBeInTheDocument();
  });
});

describe("EditableRecipeItem", () => {
  it("renders recipe details correctly", () => {
    const handleDelete = jest.fn();
    render(<EditableRecipeItem recipe={recipe} handleDelete={handleDelete} />);
    expect(screen.getByText("Spaghetti Carbonara")).toBeInTheDocument();
  });

  it("navigates to edit recipe page when edit button is clicked", async () => {
    render(<EditableRecipeItem recipe={recipe} handleDelete={jest.fn()} />);
    fireEvent.click(screen.getByText("Spaghetti Carbonara"));
    expect(screen.getByText("Rating star")).toBeInTheDocument();
  });
});
