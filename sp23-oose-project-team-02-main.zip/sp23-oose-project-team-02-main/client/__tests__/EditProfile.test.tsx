import React from "react";
import { render, screen } from "@testing-library/react";
import EditProfile from "../src/components/EditProfile";
import "@testing-library/jest-dom";
import { SessionProvider } from "next-auth/react";

test("renders without crashing", () => {
  render(
    <SessionProvider session={{ user: { username: "testuser", id: "123" } }}>
      <EditProfile setModalState={() => {}} />
    </SessionProvider>
  );
  const linkElement = screen.getByText("Edit Profile");
  expect(linkElement).toBeInTheDocument();
});
