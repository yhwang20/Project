import React from "react";
import { render, fireEvent } from "@testing-library/react";
import ToggleButton from "../src/components/ToggleButton";
import "@testing-library/jest-dom";

describe("ToggleButton", () => {
  it("renders correctly", () => {
    const { getByText } = render(
      <ToggleButton onClick={() => {}} toggled={false}>
        Toggle me
      </ToggleButton>
    );
    expect(getByText("Toggle me")).toBeInTheDocument();
  });

  it("calls onClick handler when clicked", () => {
    const handleClick = jest.fn();
    const { getByRole } = render(
      <ToggleButton onClick={handleClick} toggled={false}>
        Click me
      </ToggleButton>
    );
    fireEvent.click(getByRole("button"));
    expect(handleClick).toHaveBeenCalled();
  });

  it("sets correct background and text colors based on toggled prop", () => {
    const { rerender, getByRole } = render(
      <ToggleButton onClick={() => {}} toggled={false}>
        Toggle me
      </ToggleButton>
    );
    const button = getByRole("button");
    expect(button).toHaveStyle({ backgroundColor: "#f2f2f2", color: "#000" });

    rerender(
      <ToggleButton onClick={() => {}} toggled={true}>
        Toggle me
      </ToggleButton>
    );
    expect(button).toHaveStyle({ backgroundColor: "#84C7AE", color: "#fff" });
  });
});
