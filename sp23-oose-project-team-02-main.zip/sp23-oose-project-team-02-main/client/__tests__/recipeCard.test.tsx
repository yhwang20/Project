import { render, screen } from "@testing-library/react";
import React from "react";
import RecipeCard from "../src/components/RecipeCard";
import "@testing-library/jest-dom";
import { Recipe } from "recipe-types";
import Image from "next/image";

const dateString: string = "2023-04-07T10:30:00Z";
const date1: Date = new Date(dateString);

const dateString2: string = "2023-04-08T10:30:00Z";
const date2: Date = new Date(dateString2);

const recipe = {
  id: "2",
  name: "Pad Thai",
  photo: "/pad-thai.jpg",
  prepTimeInMins: 15,
  cookTimeInMins: 25,
  difficulty: 2,
  avgRating: 4,
  author: undefined,
  ingredients: [],
  procedure: [],
  tools: [],
  servings: 0,
  nutrition: undefined,
  createdAt: date1,
  updatedAt: date2,
  authorID: "",
  views: 0,
  tags: [],
  reviews: [],
  favoritedBy: [],
};

describe("RecipeCard", () => {
  test("renders recipe name", () => {
    render(<RecipeCard recipe={recipe} />);
    const recipeName = screen.getByText(recipe.name);
    expect(recipeName).toBeInTheDocument();
  });

  test("renders recipe rating", () => {
    render(<RecipeCard recipe={recipe} />);
    const recipeRating = screen.getByText(`Rating star`);
    expect(recipeRating).toBeInTheDocument();
  });

  test("renders recipe time", () => {
    render(<RecipeCard recipe={recipe} />);
    const recipeTime = screen.getByText(
      `${recipe.prepTimeInMins + recipe.cookTimeInMins} minutes`
    );
    expect(recipeTime).toBeInTheDocument();
  });

  test("renders recipe difficulty", () => {
    render(<RecipeCard recipe={recipe} />);
    const recipeDifficulty = screen.getByText("Easy"); //level 2 = easy
    expect(recipeDifficulty).toBeInTheDocument();
  });

  test("renders recipe image", () => {
    render(<RecipeCard recipe={recipe} />);
    const recipeImage = screen.getByAltText("Recipe Picture");
    expect(recipeImage).toBeInTheDocument();
  });
});
