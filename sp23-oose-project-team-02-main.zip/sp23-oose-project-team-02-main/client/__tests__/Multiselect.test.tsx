import { render, screen, fireEvent } from "@testing-library/react";
import MultiSelect from "../src/components/MultiSelect";
import "@testing-library/jest-dom";

describe("MultiSelect", () => {
  const options = ["Option 1", "Option 2", "Option 3"];
  const title = "Select Options";
  const setSelectedOption = jest.fn();

  beforeEach(() => {
    render(
      <MultiSelect
        title={title}
        options={options}
        selectedOption={[]}
        setSelectedOption={setSelectedOption}
      />
    );
  });

  it("should render the dropdown with given options and title", () => {
    const dropdown = screen.getByTestId("combobox");
    expect(dropdown).toBeInTheDocument();
  });

  it("should update selected option when an option is clicked", () => {
    const dropdown = screen.getByText("options");
    fireEvent.mouseDown(dropdown);
    expect(screen.getByText("options")).toBeInTheDocument();
  });
});
