import React from "react";
import { render } from "@testing-library/react";
import RecipeListItem from "../src/components/RecipeListItem";
import { Recipe } from "recipe-types";
import "@testing-library/jest-dom";

const dateString: string = "2023-04-07T10:30:00Z";
const date1: Date = new Date(dateString);

const dateString2: string = "2023-04-08T10:30:00Z";
const date2: Date = new Date(dateString2);

const a: Recipe = {
  id: "1",
  name: "Spaghetti",
  photo: "/spaghetti-carbonara.jpg",
  prepTimeInMins: 10,
  cookTimeInMins: 20,
  difficulty: 2,
  avgRating: 4.5,
  author: "JohnDoe",
  ingredients: [],
  procedure: [],
  tools: [],
  servings: 0,
  nutrition: undefined,
  authorID: "",
  views: 0,
  createdAt: date1,
  updatedAt: date2,
  tags: [],
  reviews: [],
  favoritedBy: [],
};

describe("RecipeListItem", () => {
  it("should render the recipe name", () => {
    const { getByText } = render(<RecipeListItem recipe={a} />);
    expect(getByText(/Spaghetti/i)).toBeInTheDocument();
  });

  it("should render the average rating", () => {
    const { getByText } = render(<RecipeListItem recipe={a} />);
    expect(getByText(/Average Rating:/i)).toBeInTheDocument();
    expect(getByText(/4.5/i)).toBeInTheDocument();
  });

  it("should render a link to the recipe page", () => {
    const { getByRole } = render(<RecipeListItem recipe={a} />);
    expect(getByRole("link")).toHaveAttribute("href", "/recipe/1");
  });
});
