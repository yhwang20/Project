import { render, screen, fireEvent, getByTestId } from "@testing-library/react";
import Chrono, { ChronoProps } from "../src/components/Chrono";
import "@testing-library/jest-dom";

describe("Chrono component", () => {
  const mockUpdateRange = jest.fn();

  it("should render correctly with given props", () => {
    const { getByLabelText } = render(
      <Chrono
        range="10"
        title="Test Title"
        isUpperBound={true}
        updateRange={mockUpdateRange}
      />
    );
    const title = screen.getByTestId("title");
    expect(title).toBeInTheDocument();
    expect(title).toHaveAttribute("value", "10");
    expect(title).toHaveAttribute("type", "number");
  });

  it("should call updateRange function on input change", () => {
    const { getByLabelText } = render(
      <Chrono
        range="10"
        title="Test Title"
        isUpperBound={true}
        updateRange={mockUpdateRange}
      />
    );
    const title = screen.getByTestId("title");
    fireEvent.change(title, { target: { value: "20" } });

    expect(mockUpdateRange).toHaveBeenCalledTimes(1);
    expect(mockUpdateRange).toHaveBeenCalledWith("20");
  });
});
