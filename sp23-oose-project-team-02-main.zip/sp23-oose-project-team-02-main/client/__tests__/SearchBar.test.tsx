import "@testing-library/jest-dom";
import { render, fireEvent } from "@testing-library/react";
import SearchBar, { SearchBarProps } from "../src/components/SearchBar";

describe("SearchBar", () => {
  const query = "test query";
  const updateQuery = jest.fn();
  const props: SearchBarProps = { query, updateQuery };

  it("should render correctly", () => {
    const { getByPlaceholderText } = render(<SearchBar {...props} />);

    expect(getByPlaceholderText("Search recipes")).toBeInTheDocument();
  });

  it("should call updateQuery function on input change", () => {
    const { getByPlaceholderText } = render(<SearchBar {...props} />);
    const input = getByPlaceholderText("Search recipes");

    fireEvent.change(input, { target: { value: "new query" } });

    expect(updateQuery).toHaveBeenCalledWith("new query");
  });
});
