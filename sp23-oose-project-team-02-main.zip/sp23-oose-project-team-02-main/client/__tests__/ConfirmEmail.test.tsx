import { render } from "@testing-library/react";
import ConfirmEmail from "../src/components/ConfirmEmail";
import "@testing-library/jest-dom";

// Mock the useSearchParams hook
jest.mock("next/navigation", () => ({
  useSearchParams: () => ({
    get: jest.fn().mockReturnValue("test@example.com"),
  }),
}));

describe("ConfirmEmail", () => {
  test("displays email address", () => {
    const { getByText } = render(<ConfirmEmail />);
    expect(getByText("test@example.com")).toBeInTheDocument();
  });

  test("displays confirmation message", () => {
    const { getByText } = render(<ConfirmEmail />);
    expect(getByText("An email has been sent to:")).toBeInTheDocument();
    expect(getByText("Click on the link there to")).toBeInTheDocument();
    expect(getByText("continue setting up your account!")).toBeInTheDocument();
  });
});
